<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-11 00:01:41 --> Could not find the language line "recommended"
ERROR - 2025-11-11 00:23:21 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-11 00:23:21 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-11 00:28:32 --> Could not find the language line "recommended"
ERROR - 2025-11-11 00:42:37 --> Could not find the language line "recommended"
ERROR - 2025-11-11 01:19:14 --> Could not find the language line "email_us"
ERROR - 2025-11-11 01:25:06 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 01:25:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 01:25:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 01:55:29 --> Could not find the language line "recommended"
ERROR - 2025-11-11 02:35:59 --> Could not find the language line "recommended"
ERROR - 2025-11-11 02:50:11 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 02:50:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 02:50:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 03:14:09 --> Could not find the language line "recommended"
ERROR - 2025-11-11 03:49:11 --> Could not find the language line "recommended"
ERROR - 2025-11-11 04:30:31 --> Could not find the language line "recommended"
ERROR - 2025-11-11 04:32:13 --> Could not find the language line "recommended"
ERROR - 2025-11-11 05:12:59 --> Could not find the language line "email_us"
ERROR - 2025-11-11 05:35:25 --> Could not find the language line "email_us"
ERROR - 2025-11-11 05:52:33 --> Could not find the language line "recommended"
ERROR - 2025-11-11 06:02:10 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 06:02:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 06:02:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 06:08:50 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 06:08:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 06:08:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 06:35:54 --> Could not find the language line "recommended"
ERROR - 2025-11-11 07:13:14 --> Could not find the language line "recommended"
ERROR - 2025-11-11 07:25:34 --> Could not find the language line "email_us"
ERROR - 2025-11-11 07:25:36 --> Could not find the language line "recommended"
ERROR - 2025-11-11 07:26:50 --> Could not find the language line "recommended"
ERROR - 2025-11-11 07:50:52 --> Could not find the language line "recommended"
ERROR - 2025-11-11 08:07:24 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 08:07:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 08:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 08:29:31 --> Could not find the language line "recommended"
ERROR - 2025-11-11 09:07:02 --> Could not find the language line "email_us"
ERROR - 2025-11-11 09:41:18 --> Could not find the language line "recommended"
ERROR - 2025-11-11 10:16:16 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 10:16:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 10:16:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 10:19:47 --> Could not find the language line "recommended"
ERROR - 2025-11-11 10:33:56 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 10:33:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 10:33:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 10:38:11 --> Could not find the language line "recommended"
ERROR - 2025-11-11 11:00:40 --> Could not find the language line "recommended"
ERROR - 2025-11-11 11:40:58 --> Could not find the language line "email_us"
ERROR - 2025-11-11 11:44:12 --> Could not find the language line "recommended"
ERROR - 2025-11-11 12:19:58 --> Could not find the language line "recommended"
ERROR - 2025-11-11 12:37:03 --> Could not find the language line "recommended"
ERROR - 2025-11-11 12:59:13 --> Could not find the language line "email_us"
ERROR - 2025-11-11 13:05:04 --> Could not find the language line "recommended"
ERROR - 2025-11-11 13:33:30 --> Could not find the language line "recommended"
ERROR - 2025-11-11 14:08:47 --> Could not find the language line "recommended"
ERROR - 2025-11-11 14:36:39 --> Could not find the language line "return_policy"
ERROR - 2025-11-11 14:36:39 --> Could not find the language line "return_policy"
ERROR - 2025-11-11 14:50:12 --> Could not find the language line "recommended"
ERROR - 2025-11-11 16:01:17 --> Could not find the language line "recommended"
ERROR - 2025-11-11 16:42:04 --> Could not find the language line "recommended"
ERROR - 2025-11-11 17:10:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 17:10:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 17:10:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 17:19:21 --> Could not find the language line "email_us"
ERROR - 2025-11-11 17:54:12 --> Could not find the language line "recommended"
ERROR - 2025-11-11 18:34:10 --> Could not find the language line "recommended"
ERROR - 2025-11-11 18:44:31 --> Could not find the language line "compare"
ERROR - 2025-11-11 19:09:48 --> Could not find the language line "recommended"
ERROR - 2025-11-11 19:10:51 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 19:10:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 19:43:30 --> Could not find the language line "recommended"
ERROR - 2025-11-11 19:44:38 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 19:44:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 19:44:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 20:17:17 --> Could not find the language line "recommended"
ERROR - 2025-11-11 20:56:41 --> Could not find the language line "recommended"
ERROR - 2025-11-11 21:31:07 --> Could not find the language line "recommended"
ERROR - 2025-11-11 21:51:37 --> Could not find the language line "recommended"
ERROR - 2025-11-11 22:03:53 --> Could not find the language line "recommended"
ERROR - 2025-11-11 22:29:00 --> Could not find the language line "recommended"
ERROR - 2025-11-11 22:29:07 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 22:29:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 22:29:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 22:29:18 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 22:41:58 --> Could not find the language line "recommended"
ERROR - 2025-11-11 22:51:00 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 22:51:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 22:51:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 22:56:44 --> Could not find the language line "recommended"
ERROR - 2025-11-11 22:57:24 --> Could not find the language line "recommended"
ERROR - 2025-11-11 22:57:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 22:59:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:00:09 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:00:16 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:00:29 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:01:49 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:01:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:01:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:03:12 --> Could not find the language line "login_heading"
ERROR - 2025-11-11 23:03:12 --> Could not find the language line "login_password_label"
ERROR - 2025-11-11 23:04:08 --> Could not find the language line "section"
ERROR - 2025-11-11 23:04:08 --> Could not find the language line "search"
ERROR - 2025-11-11 23:04:08 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:04:14 --> Could not find the language line "section"
ERROR - 2025-11-11 23:04:14 --> Could not find the language line "search"
ERROR - 2025-11-11 23:04:14 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:04:33 --> Could not find the language line "section"
ERROR - 2025-11-11 23:04:33 --> Could not find the language line "search"
ERROR - 2025-11-11 23:04:33 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:05:25 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:05:29 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:05:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:05:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:05:40 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:05:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:05:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:05:49 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:05:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:05:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:06:13 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:06:27 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:06:40 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:07:13 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:07:18 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:07:24 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:07:27 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:07:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:07:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:13:45 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:13:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:13:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:15:15 --> Could not find the language line "section"
ERROR - 2025-11-11 23:15:15 --> Could not find the language line "search"
ERROR - 2025-11-11 23:15:15 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:16:08 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:25:02 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:25:18 --> Could not find the language line "recommended"
ERROR - 2025-11-11 23:25:21 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:34:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:34:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:34:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-11 23:36:08 --> Could not find the language line "return_policy"
ERROR - 2025-11-11 23:36:08 --> Could not find the language line "return_policy"
ERROR - 2025-11-11 23:36:17 --> Could not find the language line "compare"
ERROR - 2025-11-11 23:43:07 --> Could not find the language line "compare"
ERROR - 2025-11-11 23:43:08 --> Could not find the language line "return_policy"
ERROR - 2025-11-11 23:43:08 --> Could not find the language line "return_policy"
ERROR - 2025-11-11 23:43:27 --> Could not find the language line "check_availability"
ERROR - 2025-11-11 23:48:14 --> Could not find the language line "recommended"
