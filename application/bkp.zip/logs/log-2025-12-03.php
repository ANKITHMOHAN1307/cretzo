<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-03 00:06:13 --> Could not find the language line "recommended"
ERROR - 2025-12-03 00:24:50 --> Could not find the language line "recommended"
ERROR - 2025-12-03 00:41:53 --> Could not find the language line "recommended"
ERROR - 2025-12-03 00:58:05 --> Could not find the language line "recommended"
ERROR - 2025-12-03 01:06:17 --> Could not find the language line "email_us"
ERROR - 2025-12-03 01:07:03 --> Could not find the language line "recommended"
ERROR - 2025-12-03 01:14:13 --> Could not find the language line "recommended"
ERROR - 2025-12-03 01:32:08 --> Could not find the language line "recommended"
ERROR - 2025-12-03 01:47:47 --> Could not find the language line "recommended"
ERROR - 2025-12-03 02:01:24 --> Could not find the language line "recommended"
ERROR - 2025-12-03 02:15:03 --> Could not find the language line "recommended"
ERROR - 2025-12-03 02:17:49 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 02:28:30 --> Could not find the language line "recommended"
ERROR - 2025-12-03 02:42:24 --> Could not find the language line "recommended"
ERROR - 2025-12-03 02:55:24 --> Could not find the language line "recommended"
ERROR - 2025-12-03 03:07:28 --> Could not find the language line "recommended"
ERROR - 2025-12-03 03:24:17 --> Could not find the language line "recommended"
ERROR - 2025-12-03 03:38:30 --> Could not find the language line "recommended"
ERROR - 2025-12-03 03:50:46 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:02:40 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:09:54 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:15:29 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:28:11 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:31:20 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-03 04:31:20 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-03 04:31:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 04:31:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 04:31:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 04:33:23 --> Could not find the language line "email_us"
ERROR - 2025-12-03 04:33:24 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:33:24 --> Could not find the language line "return_policy"
ERROR - 2025-12-03 04:33:24 --> Could not find the language line "return_policy"
ERROR - 2025-12-03 04:33:24 --> Could not find the language line "compare"
ERROR - 2025-12-03 04:33:24 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-03 04:33:24 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-03 04:47:14 --> Could not find the language line "email_us"
ERROR - 2025-12-03 04:47:15 --> Could not find the language line "recommended"
ERROR - 2025-12-03 04:47:15 --> Could not find the language line "return_policy"
ERROR - 2025-12-03 04:47:15 --> Could not find the language line "return_policy"
ERROR - 2025-12-03 04:47:15 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-03 04:47:15 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-03 04:47:16 --> Could not find the language line "compare"
ERROR - 2025-12-03 04:52:45 --> Could not find the language line "recommended"
ERROR - 2025-12-03 05:04:47 --> Could not find the language line "recommended"
ERROR - 2025-12-03 05:11:51 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 05:11:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 05:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 05:18:44 --> Could not find the language line "recommended"
ERROR - 2025-12-03 05:33:31 --> Could not find the language line "recommended"
ERROR - 2025-12-03 05:45:55 --> Could not find the language line "recommended"
ERROR - 2025-12-03 05:58:14 --> Could not find the language line "recommended"
ERROR - 2025-12-03 06:09:36 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 06:09:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 06:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 06:11:27 --> Could not find the language line "recommended"
ERROR - 2025-12-03 06:14:42 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 06:14:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 06:14:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 06:35:32 --> Could not find the language line "email_us"
ERROR - 2025-12-03 07:17:04 --> Could not find the language line "recommended"
ERROR - 2025-12-03 07:32:14 --> Could not find the language line "recommended"
ERROR - 2025-12-03 07:46:13 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 07:56:03 --> Could not find the language line "recommended"
ERROR - 2025-12-03 08:13:45 --> Could not find the language line "recommended"
ERROR - 2025-12-03 08:27:19 --> Could not find the language line "compare"
ERROR - 2025-12-03 08:41:05 --> Could not find the language line "recommended"
ERROR - 2025-12-03 08:51:35 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 08:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 08:51:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 08:55:51 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 08:55:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 08:55:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 08:56:43 --> Could not find the language line "recommended"
ERROR - 2025-12-03 09:42:24 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 09:42:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 09:42:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 09:57:08 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 09:57:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 09:57:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 10:12:37 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 10:27:41 --> Could not find the language line "recommended"
ERROR - 2025-12-03 10:40:05 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 10:40:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 10:40:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 10:41:37 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 10:41:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 10:41:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 10:56:28 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 10:56:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 10:56:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:12:44 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 11:12:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:12:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:13:49 --> Could not find the language line "recommended"
ERROR - 2025-12-03 11:16:16 --> Could not find the language line "email_us"
ERROR - 2025-12-03 11:28:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-03 11:28:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-03 11:28:10 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 11:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:28:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:42:57 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 11:42:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:42:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:57:31 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 11:57:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 11:57:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:00:51 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-03 12:00:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-03 12:00:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-03 12:00:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-03 12:00:53 --> Could not find the language line "recommended"
ERROR - 2025-12-03 12:25:29 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 12:25:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:25:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:35:26 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 12:35:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:35:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:39:08 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 12:39:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:39:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 12:50:42 --> Could not find the language line "recommended"
ERROR - 2025-12-03 13:08:21 --> Could not find the language line "recommended"
ERROR - 2025-12-03 13:37:06 --> Could not find the language line "recommended"
ERROR - 2025-12-03 13:50:19 --> Could not find the language line "recommended"
ERROR - 2025-12-03 13:57:28 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 13:57:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 13:57:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 14:31:37 --> Could not find the language line "recommended"
ERROR - 2025-12-03 14:48:18 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:00:55 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:13:23 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:14:07 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:14:39 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:15:05 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:15:33 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:16:18 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:17:09 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:18:06 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 15:18:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 15:18:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 15:29:56 --> Could not find the language line "recommended"
ERROR - 2025-12-03 15:47:47 --> Could not find the language line "recommended"
ERROR - 2025-12-03 16:01:47 --> Could not find the language line "email_us"
ERROR - 2025-12-03 16:15:35 --> Could not find the language line "recommended"
ERROR - 2025-12-03 16:30:50 --> Could not find the language line "recommended"
ERROR - 2025-12-03 16:46:29 --> Could not find the language line "recommended"
ERROR - 2025-12-03 16:47:06 --> Could not find the language line "recommended"
ERROR - 2025-12-03 16:59:54 --> Could not find the language line "recommended"
ERROR - 2025-12-03 17:16:55 --> Could not find the language line "recommended"
ERROR - 2025-12-03 17:33:06 --> Could not find the language line "recommended"
ERROR - 2025-12-03 17:48:55 --> Could not find the language line "recommended"
ERROR - 2025-12-03 18:02:47 --> Could not find the language line "recommended"
ERROR - 2025-12-03 18:07:10 --> Could not find the language line "recommended"
ERROR - 2025-12-03 18:17:24 --> Could not find the language line "recommended"
ERROR - 2025-12-03 18:31:43 --> Could not find the language line "recommended"
ERROR - 2025-12-03 18:46:13 --> Could not find the language line "email_us"
ERROR - 2025-12-03 18:59:59 --> Could not find the language line "recommended"
ERROR - 2025-12-03 19:05:33 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 19:05:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 19:05:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 19:15:48 --> Could not find the language line "recommended"
ERROR - 2025-12-03 19:17:46 --> Could not find the language line "recommended"
ERROR - 2025-12-03 19:34:37 --> Could not find the language line "recommended"
ERROR - 2025-12-03 19:49:38 --> Could not find the language line "recommended"
ERROR - 2025-12-03 20:03:57 --> Could not find the language line "recommended"
ERROR - 2025-12-03 20:18:35 --> Could not find the language line "recommended"
ERROR - 2025-12-03 20:40:32 --> Could not find the language line "recommended"
ERROR - 2025-12-03 20:47:09 --> Could not find the language line "recommended"
ERROR - 2025-12-03 20:57:55 --> Could not find the language line "login_heading"
ERROR - 2025-12-03 20:57:55 --> Could not find the language line "login_password_label"
ERROR - 2025-12-03 20:58:00 --> Could not find the language line "login_heading"
ERROR - 2025-12-03 20:58:00 --> Could not find the language line "login_password_label"
ERROR - 2025-12-03 20:58:05 --> Could not find the language line "login_heading"
ERROR - 2025-12-03 20:58:05 --> Could not find the language line "login_password_label"
ERROR - 2025-12-03 20:59:01 --> Could not find the language line "email_us"
ERROR - 2025-12-03 21:01:20 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:04:00 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:19:27 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:27 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:27 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:19:37 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:19:37 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:19:42 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:42 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:42 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:19:52 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:52 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:52 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:19:58 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:58 --> Could not find the language line "section"
ERROR - 2025-12-03 21:19:58 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:20:08 --> Could not find the language line "section"
ERROR - 2025-12-03 21:20:08 --> Could not find the language line "section"
ERROR - 2025-12-03 21:20:08 --> Could not find the language line "recommended"
ERROR - 2025-12-03 21:20:34 --> Could not find the language line "login_heading"
ERROR - 2025-12-03 21:20:34 --> Could not find the language line "login_password_label"
ERROR - 2025-12-03 21:20:35 --> Could not find the language line "login_heading"
ERROR - 2025-12-03 21:20:35 --> Could not find the language line "login_password_label"
ERROR - 2025-12-03 21:21:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 21:21:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 21:21:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 21:22:43 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 21:22:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 21:22:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:01:03 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 22:01:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:01:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:06:59 --> Could not find the language line "recommended"
ERROR - 2025-12-03 22:16:08 --> Could not find the language line "email_us"
ERROR - 2025-12-03 22:18:29 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 22:18:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:21:31 --> Could not find the language line "recommended"
ERROR - 2025-12-03 22:29:13 --> Could not find the language line "check_availability"
ERROR - 2025-12-03 22:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:29:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-03 22:35:40 --> Could not find the language line "recommended"
ERROR - 2025-12-03 22:49:20 --> Could not find the language line "recommended"
ERROR - 2025-12-03 23:05:17 --> Could not find the language line "recommended"
ERROR - 2025-12-03 23:26:10 --> Could not find the language line "recommended"
ERROR - 2025-12-03 23:43:45 --> Could not find the language line "recommended"
