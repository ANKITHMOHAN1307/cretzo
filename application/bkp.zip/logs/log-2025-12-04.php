<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-04 00:01:21 --> Could not find the language line "recommended"
ERROR - 2025-12-04 00:19:00 --> Could not find the language line "recommended"
ERROR - 2025-12-04 00:36:01 --> Could not find the language line "recommended"
ERROR - 2025-12-04 00:52:42 --> Could not find the language line "recommended"
ERROR - 2025-12-04 01:38:35 --> Could not find the language line "recommended"
ERROR - 2025-12-04 02:01:02 --> Could not find the language line "recommended"
ERROR - 2025-12-04 02:22:55 --> Could not find the language line "recommended"
ERROR - 2025-12-04 02:44:49 --> Could not find the language line "recommended"
ERROR - 2025-12-04 03:34:17 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:21:01 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:43:45 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:23 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:25 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:26 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:26 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:26 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:26 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:26 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:28 --> Could not find the language line "email_us"
ERROR - 2025-12-04 04:48:28 --> Could not find the language line "recommended"
ERROR - 2025-12-04 04:48:28 --> Could not find the language line "email_us"
ERROR - 2025-12-04 04:48:28 --> Could not find the language line "recommended"
ERROR - 2025-12-04 05:07:19 --> Could not find the language line "recommended"
ERROR - 2025-12-04 05:44:41 --> Could not find the language line "recommended"
ERROR - 2025-12-04 05:54:08 --> Could not find the language line "recommended"
ERROR - 2025-12-04 06:18:38 --> Could not find the language line "recommended"
ERROR - 2025-12-04 06:56:45 --> Could not find the language line "recommended"
ERROR - 2025-12-04 07:31:38 --> Could not find the language line "recommended"
ERROR - 2025-12-04 08:28:09 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 08:28:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 08:28:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 08:32:47 --> Could not find the language line "recommended"
ERROR - 2025-12-04 09:02:29 --> Could not find the language line "recommended"
ERROR - 2025-12-04 09:38:24 --> Could not find the language line "recommended"
ERROR - 2025-12-04 09:51:47 --> Could not find the language line "email_us"
ERROR - 2025-12-04 10:05:45 --> Could not find the language line "recommended"
ERROR - 2025-12-04 10:29:09 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 10:29:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 10:29:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 10:32:31 --> Could not find the language line "recommended"
ERROR - 2025-12-04 10:48:16 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 10:48:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 10:48:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 11:24:06 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 11:43:53 --> Could not find the language line "recommended"
ERROR - 2025-12-04 12:03:15 --> Could not find the language line "recommended"
ERROR - 2025-12-04 12:23:26 --> Could not find the language line "recommended"
ERROR - 2025-12-04 12:59:44 --> Could not find the language line "recommended"
ERROR - 2025-12-04 13:01:45 --> Could not find the language line "recommended"
ERROR - 2025-12-04 13:44:02 --> Could not find the language line "recommended"
ERROR - 2025-12-04 13:52:46 --> Could not find the language line "email_us"
ERROR - 2025-12-04 14:03:05 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 14:03:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 14:03:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 14:21:47 --> Could not find the language line "recommended"
ERROR - 2025-12-04 14:56:39 --> Could not find the language line "recommended"
ERROR - 2025-12-04 15:17:09 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-04 15:17:09 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-04 15:45:10 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 15:45:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 15:45:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 16:13:10 --> Could not find the language line "recommended"
ERROR - 2025-12-04 16:38:37 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 16:38:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 16:38:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 17:07:20 --> Could not find the language line "compare"
ERROR - 2025-12-04 17:17:31 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 17:17:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 17:17:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 17:39:32 --> Could not find the language line "recommended"
ERROR - 2025-12-04 18:08:08 --> Could not find the language line "recommended"
ERROR - 2025-12-04 18:37:54 --> Could not find the language line "return_policy"
ERROR - 2025-12-04 18:37:54 --> Could not find the language line "return_policy"
ERROR - 2025-12-04 19:02:08 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 19:02:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 19:02:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 19:10:49 --> Could not find the language line "recommended"
ERROR - 2025-12-04 19:48:08 --> Could not find the language line "recommended"
ERROR - 2025-12-04 20:23:53 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 20:59:13 --> Could not find the language line "recommended"
ERROR - 2025-12-04 21:35:21 --> Could not find the language line "recommended"
ERROR - 2025-12-04 22:08:22 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 22:08:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 22:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 22:08:50 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 22:08:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 22:08:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 22:24:24 --> Could not find the language line "check_availability"
ERROR - 2025-12-04 22:24:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 22:24:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-04 23:41:57 --> Could not find the language line "recommended"
