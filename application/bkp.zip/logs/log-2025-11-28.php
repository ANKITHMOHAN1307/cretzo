<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-28 01:02:34 --> Could not find the language line "recommended"
ERROR - 2025-11-28 01:31:13 --> Could not find the language line "recommended"
ERROR - 2025-11-28 02:00:22 --> Could not find the language line "recommended"
ERROR - 2025-11-28 02:30:49 --> Could not find the language line "recommended"
ERROR - 2025-11-28 03:20:26 --> Could not find the language line "recommended"
ERROR - 2025-11-28 04:05:25 --> Could not find the language line "recommended"
ERROR - 2025-11-28 05:45:03 --> Could not find the language line "recommended"
ERROR - 2025-11-28 05:54:43 --> Could not find the language line "email_us"
ERROR - 2025-11-28 07:34:28 --> Could not find the language line "recommended"
ERROR - 2025-11-28 08:31:24 --> Could not find the language line "recommended"
ERROR - 2025-11-28 09:53:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-28 09:53:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 09:53:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 09:58:42 --> Could not find the language line "recommended"
ERROR - 2025-11-28 11:26:34 --> Could not find the language line "recommended"
ERROR - 2025-11-28 11:32:02 --> Could not find the language line "recommended"
ERROR - 2025-11-28 13:49:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-28 13:49:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 13:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 13:55:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-11-28 13:55:40 --> Could not find the language line "recommended"
ERROR - 2025-11-28 14:35:54 --> Could not find the language line "recommended"
ERROR - 2025-11-28 15:31:09 --> Could not find the language line "recommended"
ERROR - 2025-11-28 16:01:57 --> Could not find the language line "recommended"
ERROR - 2025-11-28 17:16:59 --> Could not find the language line "email_us"
ERROR - 2025-11-28 18:03:50 --> Could not find the language line "recommended"
ERROR - 2025-11-28 18:16:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-28 18:16:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 18:16:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 19:01:24 --> Could not find the language line "recommended"
ERROR - 2025-11-28 20:35:26 --> Could not find the language line "check_availability"
ERROR - 2025-11-28 20:35:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 20:35:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 20:37:04 --> Could not find the language line "check_availability"
ERROR - 2025-11-28 20:37:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 20:37:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-28 21:03:42 --> Could not find the language line "recommended"
ERROR - 2025-11-28 21:21:54 --> Could not find the language line "recommended"
ERROR - 2025-11-28 22:17:16 --> Could not find the language line "recommended"
ERROR - 2025-11-28 22:22:52 --> Could not find the language line "recommended"
ERROR - 2025-11-28 22:24:40 --> Could not find the language line "recommended"
ERROR - 2025-11-28 23:28:34 --> Could not find the language line "recommended"
