<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-14 03:28:43 --> Could not find the language line "recommended"
ERROR - 2025-09-14 06:24:31 --> Could not find the language line "recommended"
ERROR - 2025-09-14 09:56:14 --> Could not find the language line "check_availability"
ERROR - 2025-09-14 09:56:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-14 09:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-14 09:56:19 --> Could not find the language line "check_availability"
ERROR - 2025-09-14 09:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-14 09:56:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-14 09:56:22 --> Could not find the language line "recommended"
ERROR - 2025-09-14 12:26:36 --> Could not find the language line "email_us"
ERROR - 2025-09-14 12:26:49 --> Could not find the language line "email_us"
ERROR - 2025-09-14 12:35:40 --> Could not find the language line "recommended"
ERROR - 2025-09-14 17:32:57 --> Could not find the language line "recommended"
ERROR - 2025-09-14 20:49:54 --> Could not find the language line "recommended"
ERROR - 2025-09-14 21:23:40 --> Could not find the language line "recommended"
ERROR - 2025-09-14 21:45:24 --> Could not find the language line "recommended"
ERROR - 2025-09-14 22:45:12 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-14 22:45:12 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-14 22:45:12 --> Could not find the language line "check_availability"
ERROR - 2025-09-14 22:45:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-14 22:45:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
