<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-15 00:00:30 --> Could not find the language line "recommended"
ERROR - 2025-11-15 00:55:50 --> Could not find the language line "recommended"
ERROR - 2025-11-15 01:22:39 --> Could not find the language line "recommended"
ERROR - 2025-11-15 01:25:48 --> Could not find the language line "recommended"
ERROR - 2025-11-15 01:44:09 --> Could not find the language line "recommended"
ERROR - 2025-11-15 01:52:16 --> Could not find the language line "email_us"
ERROR - 2025-11-15 02:38:38 --> Could not find the language line "recommended"
ERROR - 2025-11-15 03:03:50 --> Could not find the language line "recommended"
ERROR - 2025-11-15 03:27:42 --> Could not find the language line "recommended"
ERROR - 2025-11-15 04:46:09 --> Could not find the language line "compare"
ERROR - 2025-11-15 05:11:12 --> Could not find the language line "recommended"
ERROR - 2025-11-15 05:34:37 --> Could not find the language line "recommended"
ERROR - 2025-11-15 05:47:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 05:47:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 05:47:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 06:50:29 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 06:50:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 06:50:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 06:52:56 --> Could not find the language line "recommended"
ERROR - 2025-11-15 07:46:04 --> Could not find the language line "recommended"
ERROR - 2025-11-15 07:59:39 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 07:59:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 07:59:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 08:13:20 --> Could not find the language line "recommended"
ERROR - 2025-11-15 09:06:49 --> Could not find the language line "recommended"
ERROR - 2025-11-15 09:53:16 --> Could not find the language line "section"
ERROR - 2025-11-15 09:53:16 --> Could not find the language line "section"
ERROR - 2025-11-15 09:53:16 --> Could not find the language line "recommended"
ERROR - 2025-11-15 10:44:06 --> Could not find the language line "recommended"
ERROR - 2025-11-15 11:06:26 --> Could not find the language line "recommended"
ERROR - 2025-11-15 11:29:31 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-15 11:29:31 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-15 11:46:08 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 11:46:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 11:46:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 11:51:51 --> Could not find the language line "recommended"
ERROR - 2025-11-15 12:01:53 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 12:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 12:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 12:14:13 --> Could not find the language line "compare"
ERROR - 2025-11-15 13:05:09 --> Could not find the language line "recommended"
ERROR - 2025-11-15 13:22:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 13:22:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 13:22:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 13:27:07 --> Could not find the language line "return_policy"
ERROR - 2025-11-15 13:27:07 --> Could not find the language line "return_policy"
ERROR - 2025-11-15 13:46:41 --> Could not find the language line "recommended"
ERROR - 2025-11-15 14:09:34 --> Could not find the language line "recommended"
ERROR - 2025-11-15 14:35:56 --> Could not find the language line "recommended"
ERROR - 2025-11-15 15:20:47 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 15:20:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 15:20:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 16:02:17 --> Could not find the language line "section"
ERROR - 2025-11-15 16:02:17 --> Could not find the language line "section"
ERROR - 2025-11-15 16:02:17 --> Could not find the language line "recommended"
ERROR - 2025-11-15 16:25:45 --> Could not find the language line "recommended"
ERROR - 2025-11-15 16:47:39 --> Could not find the language line "recommended"
ERROR - 2025-11-15 17:07:44 --> Could not find the language line "recommended"
ERROR - 2025-11-15 17:27:29 --> Could not find the language line "recommended"
ERROR - 2025-11-15 17:30:27 --> Could not find the language line "recommended"
ERROR - 2025-11-15 18:04:35 --> Could not find the language line "recommended"
ERROR - 2025-11-15 18:26:27 --> Could not find the language line "recommended"
ERROR - 2025-11-15 18:47:51 --> Could not find the language line "recommended"
ERROR - 2025-11-15 19:07:00 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 19:07:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 19:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 19:24:09 --> Could not find the language line "recommended"
ERROR - 2025-11-15 19:41:18 --> Could not find the language line "recommended"
ERROR - 2025-11-15 19:58:50 --> Could not find the language line "recommended"
ERROR - 2025-11-15 20:20:23 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 20:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 20:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 20:40:09 --> Could not find the language line "recommended"
ERROR - 2025-11-15 20:40:20 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 20:40:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 20:40:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-15 20:57:09 --> Could not find the language line "recommended"
ERROR - 2025-11-15 20:58:02 --> Could not find the language line "recommended"
ERROR - 2025-11-15 21:15:12 --> Could not find the language line "recommended"
ERROR - 2025-11-15 21:31:52 --> Could not find the language line "recommended"
ERROR - 2025-11-15 22:07:38 --> Could not find the language line "recommended"
ERROR - 2025-11-15 22:29:55 --> Could not find the language line "recommended"
ERROR - 2025-11-15 22:48:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-15 23:41:04 --> Could not find the language line "recommended"
