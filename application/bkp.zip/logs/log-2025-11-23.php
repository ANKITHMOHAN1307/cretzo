<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-23 00:45:20 --> Could not find the language line "recommended"
ERROR - 2025-11-23 01:12:27 --> Could not find the language line "recommended"
ERROR - 2025-11-23 01:26:10 --> Could not find the language line "recommended"
ERROR - 2025-11-23 01:36:39 --> Could not find the language line "recommended"
ERROR - 2025-11-23 01:40:40 --> Could not find the language line "recommended"
ERROR - 2025-11-23 01:41:29 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 01:41:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 01:41:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 01:46:10 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 01:46:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 01:46:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 01:59:49 --> Could not find the language line "email_us"
ERROR - 2025-11-23 02:24:02 --> Could not find the language line "recommended"
ERROR - 2025-11-23 02:55:19 --> Could not find the language line "recommended"
ERROR - 2025-11-23 03:20:47 --> Could not find the language line "recommended"
ERROR - 2025-11-23 03:44:45 --> Could not find the language line "recommended"
ERROR - 2025-11-23 04:09:38 --> Could not find the language line "recommended"
ERROR - 2025-11-23 04:39:24 --> Could not find the language line "email_us"
ERROR - 2025-11-23 05:05:19 --> Could not find the language line "recommended"
ERROR - 2025-11-23 05:09:45 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 05:09:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 05:09:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 05:19:01 --> Could not find the language line "recommended"
ERROR - 2025-11-23 05:19:05 --> Could not find the language line "recommended"
ERROR - 2025-11-23 05:19:08 --> Could not find the language line "recommended"
ERROR - 2025-11-23 05:19:11 --> Could not find the language line "recommended"
ERROR - 2025-11-23 05:28:57 --> Could not find the language line "recommended"
ERROR - 2025-11-23 05:51:19 --> Could not find the language line "recommended"
ERROR - 2025-11-23 06:15:07 --> Could not find the language line "recommended"
ERROR - 2025-11-23 06:44:08 --> Could not find the language line "recommended"
ERROR - 2025-11-23 07:10:37 --> Could not find the language line "recommended"
ERROR - 2025-11-23 07:35:23 --> Could not find the language line "recommended"
ERROR - 2025-11-23 08:02:10 --> Could not find the language line "recommended"
ERROR - 2025-11-23 08:31:05 --> Could not find the language line "recommended"
ERROR - 2025-11-23 08:57:15 --> Could not find the language line "recommended"
ERROR - 2025-11-23 09:12:03 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-23 09:12:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-23 09:12:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-23 09:12:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-23 09:12:04 --> Could not find the language line "recommended"
ERROR - 2025-11-23 09:21:45 --> Could not find the language line "recommended"
ERROR - 2025-11-23 09:46:06 --> Could not find the language line "recommended"
ERROR - 2025-11-23 10:10:16 --> Could not find the language line "recommended"
ERROR - 2025-11-23 10:37:12 --> Could not find the language line "recommended"
ERROR - 2025-11-23 10:59:45 --> Could not find the language line "email_us"
ERROR - 2025-11-23 11:37:47 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 11:37:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 11:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 11:41:42 --> Could not find the language line "recommended"
ERROR - 2025-11-23 11:58:01 --> Could not find the language line "recommended"
ERROR - 2025-11-23 12:02:45 --> Could not find the language line "recommended"
ERROR - 2025-11-23 12:27:53 --> Could not find the language line "recommended"
ERROR - 2025-11-23 12:50:36 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 12:50:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 12:50:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 13:16:55 --> Could not find the language line "recommended"
ERROR - 2025-11-23 13:19:26 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 13:19:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 13:19:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 13:32:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 13:32:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 13:32:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 13:51:48 --> Could not find the language line "recommended"
ERROR - 2025-11-23 14:11:43 --> Could not find the language line "section"
ERROR - 2025-11-23 14:11:43 --> Could not find the language line "section"
ERROR - 2025-11-23 14:11:44 --> Could not find the language line "recommended"
ERROR - 2025-11-23 14:35:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 14:57:40 --> Could not find the language line "recommended"
ERROR - 2025-11-23 15:17:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 15:37:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 15:37:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 15:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 15:57:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 15:57:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 15:57:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 16:15:52 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 16:15:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 16:15:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 16:38:00 --> Could not find the language line "email_us"
ERROR - 2025-11-23 16:38:11 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 16:57:57 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 16:57:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 16:57:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 17:17:20 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 17:17:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 17:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 17:36:16 --> Could not find the language line "recommended"
ERROR - 2025-11-23 17:55:21 --> Could not find the language line "return_policy"
ERROR - 2025-11-23 17:55:21 --> Could not find the language line "return_policy"
ERROR - 2025-11-23 18:14:17 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-23 18:14:17 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-23 18:36:13 --> Could not find the language line "recommended"
ERROR - 2025-11-23 18:36:26 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 18:36:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 18:36:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 18:55:47 --> Could not find the language line "section"
ERROR - 2025-11-23 18:55:47 --> Could not find the language line "section"
ERROR - 2025-11-23 18:55:47 --> Could not find the language line "recommended"
ERROR - 2025-11-23 19:47:10 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 19:47:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 19:47:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 20:04:13 --> Could not find the language line "recommended"
ERROR - 2025-11-23 20:41:38 --> Could not find the language line "recommended"
ERROR - 2025-11-23 20:59:21 --> Could not find the language line "recommended"
ERROR - 2025-11-23 21:15:21 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 21:48:15 --> Could not find the language line "recommended"
ERROR - 2025-11-23 22:05:12 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 22:05:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 22:05:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 22:21:30 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-23 22:21:30 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-23 22:21:30 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 22:21:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 22:21:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 22:42:33 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-23 22:42:33 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-23 22:42:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 22:42:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 22:42:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 23:01:13 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 23:01:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 23:01:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 23:18:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-23 23:18:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 23:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-23 23:34:38 --> Could not find the language line "recommended"
ERROR - 2025-11-23 23:50:53 --> Could not find the language line "recommended"
