<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-02 01:48:37 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 01:48:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 01:48:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 03:32:29 --> Could not find the language line "recommended"
ERROR - 2025-12-02 03:57:29 --> Could not find the language line "recommended"
ERROR - 2025-12-02 06:16:06 --> Could not find the language line "recommended"
ERROR - 2025-12-02 06:32:36 --> Could not find the language line "recommended"
ERROR - 2025-12-02 06:40:02 --> Could not find the language line "email_us"
ERROR - 2025-12-02 06:49:08 --> Could not find the language line "recommended"
ERROR - 2025-12-02 07:18:06 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 07:18:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 07:18:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 07:57:26 --> Could not find the language line "recommended"
ERROR - 2025-12-02 08:19:37 --> Could not find the language line "recommended"
ERROR - 2025-12-02 09:04:17 --> Could not find the language line "email_us"
ERROR - 2025-12-02 09:30:32 --> Could not find the language line "recommended"
ERROR - 2025-12-02 09:42:34 --> Could not find the language line "email_us"
ERROR - 2025-12-02 09:42:35 --> Could not find the language line "recommended"
ERROR - 2025-12-02 10:10:57 --> Could not find the language line "recommended"
ERROR - 2025-12-02 10:29:49 --> Could not find the language line "section"
ERROR - 2025-12-02 10:29:49 --> Could not find the language line "section"
ERROR - 2025-12-02 10:29:50 --> Could not find the language line "recommended"
ERROR - 2025-12-02 10:49:13 --> Could not find the language line "section"
ERROR - 2025-12-02 10:49:13 --> Could not find the language line "section"
ERROR - 2025-12-02 10:49:13 --> Could not find the language line "recommended"
ERROR - 2025-12-02 11:11:40 --> Could not find the language line "section"
ERROR - 2025-12-02 11:11:40 --> Could not find the language line "section"
ERROR - 2025-12-02 11:11:41 --> Could not find the language line "recommended"
ERROR - 2025-12-02 11:19:14 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 11:19:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 11:19:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 11:31:42 --> Could not find the language line "section"
ERROR - 2025-12-02 11:31:42 --> Could not find the language line "section"
ERROR - 2025-12-02 11:31:42 --> Could not find the language line "recommended"
ERROR - 2025-12-02 11:50:08 --> Could not find the language line "section"
ERROR - 2025-12-02 11:50:08 --> Could not find the language line "section"
ERROR - 2025-12-02 11:50:08 --> Could not find the language line "recommended"
ERROR - 2025-12-02 12:08:05 --> Could not find the language line "recommended"
ERROR - 2025-12-02 12:15:42 --> Could not find the language line "email_us"
ERROR - 2025-12-02 12:25:47 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 12:25:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 12:25:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 12:34:11 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 12:34:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 12:34:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 12:44:13 --> Could not find the language line "recommended"
ERROR - 2025-12-02 13:05:55 --> Could not find the language line "recommended"
ERROR - 2025-12-02 13:25:26 --> Could not find the language line "recommended"
ERROR - 2025-12-02 13:59:20 --> Could not find the language line "recommended"
ERROR - 2025-12-02 14:12:23 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 14:12:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 14:12:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 14:15:36 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-02 14:15:36 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-02 14:32:18 --> Could not find the language line "recommended"
ERROR - 2025-12-02 14:48:19 --> Could not find the language line "return_policy"
ERROR - 2025-12-02 14:48:19 --> Could not find the language line "return_policy"
ERROR - 2025-12-02 15:02:21 --> Could not find the language line "recommended"
ERROR - 2025-12-02 15:23:22 --> Could not find the language line "recommended"
ERROR - 2025-12-02 15:33:47 --> Could not find the language line "recommended"
ERROR - 2025-12-02 15:55:26 --> Could not find the language line "recommended"
ERROR - 2025-12-02 16:10:22 --> Could not find the language line "recommended"
ERROR - 2025-12-02 16:26:09 --> Could not find the language line "recommended"
ERROR - 2025-12-02 16:57:08 --> Could not find the language line "recommended"
ERROR - 2025-12-02 17:13:56 --> Could not find the language line "recommended"
ERROR - 2025-12-02 17:30:45 --> Could not find the language line "recommended"
ERROR - 2025-12-02 17:54:39 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 17:54:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 17:54:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 17:58:24 --> Could not find the language line "recommended"
ERROR - 2025-12-02 18:12:00 --> Could not find the language line "recommended"
ERROR - 2025-12-02 18:52:29 --> Could not find the language line "recommended"
ERROR - 2025-12-02 19:06:12 --> Could not find the language line "recommended"
ERROR - 2025-12-02 19:32:53 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 19:32:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 19:32:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 19:37:54 --> Could not find the language line "recommended"
ERROR - 2025-12-02 19:51:54 --> Could not find the language line "recommended"
ERROR - 2025-12-02 20:05:25 --> Could not find the language line "recommended"
ERROR - 2025-12-02 20:20:17 --> Could not find the language line "recommended"
ERROR - 2025-12-02 20:33:57 --> Could not find the language line "recommended"
ERROR - 2025-12-02 20:48:27 --> Could not find the language line "recommended"
ERROR - 2025-12-02 21:03:05 --> Could not find the language line "recommended"
ERROR - 2025-12-02 21:19:43 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 21:19:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 21:19:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 21:20:26 --> Could not find the language line "recommended"
ERROR - 2025-12-02 21:35:52 --> Could not find the language line "recommended"
ERROR - 2025-12-02 21:48:39 --> Could not find the language line "recommended"
ERROR - 2025-12-02 22:01:05 --> Could not find the language line "recommended"
ERROR - 2025-12-02 22:14:45 --> Could not find the language line "recommended"
ERROR - 2025-12-02 22:40:47 --> Could not find the language line "recommended"
ERROR - 2025-12-02 22:53:56 --> Could not find the language line "recommended"
ERROR - 2025-12-02 23:05:01 --> Could not find the language line "check_availability"
ERROR - 2025-12-02 23:05:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 23:05:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-02 23:06:16 --> Could not find the language line "recommended"
ERROR - 2025-12-02 23:22:29 --> Could not find the language line "recommended"
ERROR - 2025-12-02 23:38:53 --> Could not find the language line "recommended"
ERROR - 2025-12-02 23:54:09 --> Could not find the language line "recommended"
