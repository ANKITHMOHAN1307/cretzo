<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-12 02:43:04 --> Could not find the language line "recommended"
ERROR - 2025-09-12 05:14:45 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-12 05:14:45 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-12 05:14:45 --> Could not find the language line "check_availability"
ERROR - 2025-09-12 05:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-12 05:14:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-12 05:41:49 --> Could not find the language line "recommended"
ERROR - 2025-09-12 06:25:27 --> Could not find the language line "check_availability"
ERROR - 2025-09-12 06:25:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-12 06:25:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-12 12:22:14 --> Could not find the language line "email_us"
ERROR - 2025-09-12 12:22:20 --> Could not find the language line "email_us"
ERROR - 2025-09-12 13:17:10 --> Could not find the language line "recommended"
ERROR - 2025-09-12 16:32:01 --> Could not find the language line "recommended"
ERROR - 2025-09-12 17:00:29 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:16 --> Could not find the language line "email_us"
ERROR - 2025-09-12 18:11:20 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:21 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:25 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:26 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:27 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:29 --> Could not find the language line "section"
ERROR - 2025-09-12 18:11:29 --> Could not find the language line "section"
ERROR - 2025-09-12 18:11:29 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:30 --> Could not find the language line "section"
ERROR - 2025-09-12 18:11:30 --> Could not find the language line "section"
ERROR - 2025-09-12 18:11:30 --> Could not find the language line "recommended"
ERROR - 2025-09-12 18:11:31 --> Could not find the language line "email_us"
ERROR - 2025-09-12 18:55:58 --> Could not find the language line "compare"
