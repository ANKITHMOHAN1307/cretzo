<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-29 00:28:11 --> Could not find the language line "recommended"
ERROR - 2025-10-29 00:35:15 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 00:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 00:35:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 00:52:01 --> Could not find the language line "recommended"
ERROR - 2025-10-29 01:35:38 --> Could not find the language line "recommended"
ERROR - 2025-10-29 01:57:10 --> Could not find the language line "recommended"
ERROR - 2025-10-29 02:23:29 --> Could not find the language line "recommended"
ERROR - 2025-10-29 02:45:46 --> Could not find the language line "recommended"
ERROR - 2025-10-29 02:59:56 --> Could not find the language line "recommended"
ERROR - 2025-10-29 03:07:27 --> Could not find the language line "recommended"
ERROR - 2025-10-29 03:28:53 --> Could not find the language line "recommended"
ERROR - 2025-10-29 03:30:07 --> Could not find the language line "email_us"
ERROR - 2025-10-29 03:30:08 --> Could not find the language line "recommended"
ERROR - 2025-10-29 03:30:09 --> Could not find the language line "return_policy"
ERROR - 2025-10-29 03:30:09 --> Could not find the language line "return_policy"
ERROR - 2025-10-29 03:30:09 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-29 03:30:09 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-29 03:30:09 --> Could not find the language line "compare"
ERROR - 2025-10-29 03:31:14 --> Could not find the language line "email_us"
ERROR - 2025-10-29 03:50:02 --> Could not find the language line "recommended"
ERROR - 2025-10-29 04:07:02 --> Could not find the language line "recommended"
ERROR - 2025-10-29 04:14:55 --> Could not find the language line "recommended"
ERROR - 2025-10-29 04:21:41 --> Could not find the language line "recommended"
ERROR - 2025-10-29 04:33:19 --> Could not find the language line "recommended"
ERROR - 2025-10-29 04:40:40 --> Could not find the language line "recommended"
ERROR - 2025-10-29 05:07:00 --> Could not find the language line "recommended"
ERROR - 2025-10-29 05:13:16 --> Could not find the language line "recommended"
ERROR - 2025-10-29 05:27:34 --> Could not find the language line "recommended"
ERROR - 2025-10-29 05:39:46 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 05:39:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 05:39:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 05:51:49 --> Could not find the language line "recommended"
ERROR - 2025-10-29 06:01:18 --> Could not find the language line "recommended"
ERROR - 2025-10-29 06:20:46 --> Could not find the language line "recommended"
ERROR - 2025-10-29 06:47:25 --> Could not find the language line "recommended"
ERROR - 2025-10-29 07:12:30 --> Could not find the language line "recommended"
ERROR - 2025-10-29 07:37:39 --> Could not find the language line "recommended"
ERROR - 2025-10-29 08:03:47 --> Could not find the language line "recommended"
ERROR - 2025-10-29 08:32:31 --> Could not find the language line "recommended"
ERROR - 2025-10-29 08:59:46 --> Could not find the language line "recommended"
ERROR - 2025-10-29 09:52:13 --> Could not find the language line "recommended"
ERROR - 2025-10-29 10:19:06 --> Could not find the language line "recommended"
ERROR - 2025-10-29 10:24:03 --> Could not find the language line "section"
ERROR - 2025-10-29 10:24:03 --> Could not find the language line "tags"
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $total_rows /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-29 10:24:03 --> Could not find the language line "recommended"
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-10-29 10:24:03 --> Severity: Warning --> Undefined variable $num_pages /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-10-29 10:46:20 --> Could not find the language line "recommended"
ERROR - 2025-10-29 10:55:09 --> Could not find the language line "email_us"
ERROR - 2025-10-29 10:55:09 --> Could not find the language line "recommended"
ERROR - 2025-10-29 10:55:10 --> Could not find the language line "return_policy"
ERROR - 2025-10-29 10:55:10 --> Could not find the language line "return_policy"
ERROR - 2025-10-29 10:55:10 --> Could not find the language line "compare"
ERROR - 2025-10-29 10:55:11 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-29 10:55:11 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-29 11:13:10 --> Could not find the language line "recommended"
ERROR - 2025-10-29 11:39:51 --> Could not find the language line "recommended"
ERROR - 2025-10-29 12:13:01 --> Could not find the language line "recommended"
ERROR - 2025-10-29 12:41:22 --> Could not find the language line "recommended"
ERROR - 2025-10-29 12:49:17 --> Could not find the language line "recommended"
ERROR - 2025-10-29 13:34:31 --> Could not find the language line "recommended"
ERROR - 2025-10-29 13:59:24 --> Could not find the language line "recommended"
ERROR - 2025-10-29 14:15:54 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 14:15:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 14:15:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 14:28:07 --> Could not find the language line "recommended"
ERROR - 2025-10-29 14:55:14 --> Could not find the language line "recommended"
ERROR - 2025-10-29 15:04:30 --> Could not find the language line "recommended"
ERROR - 2025-10-29 15:18:53 --> Could not find the language line "recommended"
ERROR - 2025-10-29 15:35:40 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 15:35:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 15:35:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 15:44:21 --> Could not find the language line "recommended"
ERROR - 2025-10-29 16:09:55 --> Could not find the language line "recommended"
ERROR - 2025-10-29 16:38:27 --> Could not find the language line "recommended"
ERROR - 2025-10-29 17:03:41 --> Could not find the language line "recommended"
ERROR - 2025-10-29 17:26:14 --> Could not find the language line "email_us"
ERROR - 2025-10-29 17:28:31 --> Could not find the language line "recommended"
ERROR - 2025-10-29 18:06:04 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 18:06:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 18:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 18:24:30 --> Could not find the language line "recommended"
ERROR - 2025-10-29 18:51:08 --> Could not find the language line "recommended"
ERROR - 2025-10-29 19:18:03 --> Could not find the language line "recommended"
ERROR - 2025-10-29 19:45:12 --> Could not find the language line "recommended"
ERROR - 2025-10-29 20:11:57 --> Could not find the language line "recommended"
ERROR - 2025-10-29 20:42:48 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:04:40 --> Could not find the language line "login_heading"
ERROR - 2025-10-29 21:04:40 --> Could not find the language line "login_password_label"
ERROR - 2025-10-29 21:04:45 --> Could not find the language line "login_heading"
ERROR - 2025-10-29 21:04:45 --> Could not find the language line "login_password_label"
ERROR - 2025-10-29 21:04:50 --> Could not find the language line "login_heading"
ERROR - 2025-10-29 21:04:50 --> Could not find the language line "login_password_label"
ERROR - 2025-10-29 21:05:21 --> Could not find the language line "section"
ERROR - 2025-10-29 21:05:21 --> Could not find the language line "section"
ERROR - 2025-10-29 21:05:21 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:05:44 --> Could not find the language line "email_us"
ERROR - 2025-10-29 21:06:07 --> Could not find the language line "email_us"
ERROR - 2025-10-29 21:06:14 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:06:21 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:06:28 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:06:35 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:06:42 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:06:51 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:07:08 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:07:15 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 21:07:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 21:07:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 21:07:23 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 21:07:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 21:07:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 21:07:29 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:07:36 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:07:41 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:07:48 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:07:56 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:08:17 --> Could not find the language line "recommended"
ERROR - 2025-10-29 21:34:45 --> Could not find the language line "recommended"
ERROR - 2025-10-29 22:25:41 --> Could not find the language line "email_us"
ERROR - 2025-10-29 22:25:43 --> Could not find the language line "recommended"
ERROR - 2025-10-29 22:30:10 --> Could not find the language line "recommended"
ERROR - 2025-10-29 22:56:04 --> Could not find the language line "recommended"
ERROR - 2025-10-29 23:02:42 --> Could not find the language line "check_availability"
ERROR - 2025-10-29 23:02:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 23:02:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-29 23:23:37 --> Could not find the language line "recommended"
ERROR - 2025-10-29 23:48:51 --> Could not find the language line "recommended"
