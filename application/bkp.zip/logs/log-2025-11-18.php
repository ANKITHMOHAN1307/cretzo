<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-18 00:08:58 --> Could not find the language line "recommended"
ERROR - 2025-11-18 00:51:38 --> Could not find the language line "email_us"
ERROR - 2025-11-18 00:51:38 --> Could not find the language line "email_us"
ERROR - 2025-11-18 00:51:42 --> Could not find the language line "email_us"
ERROR - 2025-11-18 00:51:44 --> Could not find the language line "email_us"
ERROR - 2025-11-18 00:51:45 --> Could not find the language line "email_us"
ERROR - 2025-11-18 00:58:31 --> Could not find the language line "recommended"
ERROR - 2025-11-18 02:09:49 --> Could not find the language line "section"
ERROR - 2025-11-18 02:09:49 --> Could not find the language line "section"
ERROR - 2025-11-18 02:09:49 --> Could not find the language line "recommended"
ERROR - 2025-11-18 02:35:43 --> Could not find the language line "recommended"
ERROR - 2025-11-18 02:58:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 02:58:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 02:58:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 03:44:16 --> Could not find the language line "section"
ERROR - 2025-11-18 03:44:16 --> Could not find the language line "tags"
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $total_rows /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-18 03:44:16 --> Could not find the language line "recommended"
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-11-18 03:44:16 --> Severity: Warning --> Undefined variable $num_pages /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-11-18 03:59:16 --> Could not find the language line "recommended"
ERROR - 2025-11-18 05:18:17 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:42:52 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:43:47 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:44:15 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:48:02 --> Could not find the language line "section"
ERROR - 2025-11-18 06:48:02 --> Could not find the language line "section"
ERROR - 2025-11-18 06:48:02 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:48:49 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:56:15 --> Could not find the language line "recommended"
ERROR - 2025-11-18 06:57:43 --> Could not find the language line "section"
ERROR - 2025-11-18 06:57:43 --> Could not find the language line "section"
ERROR - 2025-11-18 06:57:43 --> Could not find the language line "recommended"
ERROR - 2025-11-18 08:26:21 --> Could not find the language line "recommended"
ERROR - 2025-11-18 10:04:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 10:04:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 10:04:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 10:42:45 --> Could not find the language line "recommended"
ERROR - 2025-11-18 12:30:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-11-18 12:30:08 --> Could not find the language line "recommended"
ERROR - 2025-11-18 13:02:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 13:02:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 13:03:12 --> Could not find the language line "recommended"
ERROR - 2025-11-18 13:13:53 --> Could not find the language line "recommended"
ERROR - 2025-11-18 17:53:18 --> Could not find the language line "recommended"
ERROR - 2025-11-18 18:18:52 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 18:18:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 18:18:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 18:53:12 --> Could not find the language line "recommended"
ERROR - 2025-11-18 19:00:54 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 19:00:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 19:00:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 21:07:20 --> Could not find the language line "recommended"
ERROR - 2025-11-18 21:42:30 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 21:42:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 21:42:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 22:38:44 --> Could not find the language line "recommended"
ERROR - 2025-11-18 22:41:35 --> Could not find the language line "recommended"
ERROR - 2025-11-18 22:57:34 --> Could not find the language line "check_availability"
ERROR - 2025-11-18 22:57:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-18 22:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
