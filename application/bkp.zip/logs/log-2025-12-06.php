<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-06 00:15:51 --> Could not find the language line "recommended"
ERROR - 2025-12-06 00:30:45 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 00:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 00:30:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 00:49:07 --> Could not find the language line "recommended"
ERROR - 2025-12-06 01:00:12 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 01:00:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 01:00:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 01:29:15 --> Could not find the language line "recommended"
ERROR - 2025-12-06 01:40:42 --> Could not find the language line "recommended"
ERROR - 2025-12-06 01:53:30 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 01:53:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 01:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 02:03:57 --> Could not find the language line "recommended"
ERROR - 2025-12-06 03:14:04 --> Could not find the language line "recommended"
ERROR - 2025-12-06 03:47:55 --> Could not find the language line "recommended"
ERROR - 2025-12-06 04:19:18 --> Could not find the language line "recommended"
ERROR - 2025-12-06 04:51:15 --> Could not find the language line "recommended"
ERROR - 2025-12-06 04:56:11 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 04:56:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 04:56:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 06:40:23 --> Could not find the language line "recommended"
ERROR - 2025-12-06 07:19:20 --> Could not find the language line "recommended"
ERROR - 2025-12-06 07:47:01 --> Could not find the language line "recommended"
ERROR - 2025-12-06 08:15:50 --> Could not find the language line "recommended"
ERROR - 2025-12-06 08:20:06 --> Could not find the language line "recommended"
ERROR - 2025-12-06 08:41:33 --> Could not find the language line "recommended"
ERROR - 2025-12-06 09:07:11 --> Could not find the language line "recommended"
ERROR - 2025-12-06 09:38:47 --> Could not find the language line "email_us"
ERROR - 2025-12-06 10:20:33 --> Could not find the language line "recommended"
ERROR - 2025-12-06 10:58:44 --> Could not find the language line "recommended"
ERROR - 2025-12-06 11:11:17 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 11:11:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 11:11:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 11:58:14 --> Could not find the language line "recommended"
ERROR - 2025-12-06 13:19:08 --> Could not find the language line "recommended"
ERROR - 2025-12-06 14:35:09 --> Could not find the language line "email_us"
ERROR - 2025-12-06 14:59:22 --> Could not find the language line "recommended"
ERROR - 2025-12-06 15:25:02 --> Could not find the language line "email_us"
ERROR - 2025-12-06 15:49:56 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 15:49:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 15:49:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 16:21:53 --> Could not find the language line "recommended"
ERROR - 2025-12-06 16:33:06 --> Could not find the language line "recommended"
ERROR - 2025-12-06 17:24:42 --> Could not find the language line "email_us"
ERROR - 2025-12-06 17:47:37 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 17:47:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 17:47:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 18:03:26 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 18:03:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 18:03:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 18:06:04 --> Could not find the language line "recommended"
ERROR - 2025-12-06 18:51:39 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 18:51:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 18:51:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 19:13:13 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 19:13:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 19:13:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 19:29:07 --> Could not find the language line "recommended"
ERROR - 2025-12-06 19:38:36 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 19:38:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 19:38:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 21:50:16 --> Could not find the language line "recommended"
ERROR - 2025-12-06 23:29:27 --> Could not find the language line "recommended"
ERROR - 2025-12-06 23:33:50 --> Could not find the language line "check_availability"
ERROR - 2025-12-06 23:33:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 23:33:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-06 23:39:20 --> Could not find the language line "section"
ERROR - 2025-12-06 23:39:20 --> Could not find the language line "section"
ERROR - 2025-12-06 23:39:20 --> Could not find the language line "recommended"
ERROR - 2025-12-06 23:40:12 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-06 23:40:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-06 23:40:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-06 23:40:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-06 23:40:13 --> Could not find the language line "recommended"
