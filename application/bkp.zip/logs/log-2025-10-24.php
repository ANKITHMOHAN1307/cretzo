<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-24 00:03:18 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:03:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:03:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:03:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:03:49 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:03:59 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:03:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:03:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:04:08 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:04:19 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:04:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:04:30 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:08:14 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:08:40 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:08:41 --> Could not find the language line "section"
ERROR - 2025-10-24 00:08:41 --> Could not find the language line "section"
ERROR - 2025-10-24 00:08:41 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:08:45 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:08:55 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:09:07 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:09:27 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:09:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:09:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:09:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:09:48 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:09:57 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:10:09 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:10:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:10:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:10:20 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:10:37 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:11:02 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:11:07 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:11:16 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:11:27 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:11:42 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:12:01 --> Could not find the language line "compare"
ERROR - 2025-10-24 00:12:12 --> Could not find the language line "section"
ERROR - 2025-10-24 00:12:12 --> Could not find the language line "section"
ERROR - 2025-10-24 00:12:12 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:12:22 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:12:31 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:12:58 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:13:18 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:13:28 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:13:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:13:56 --> Could not find the language line "section"
ERROR - 2025-10-24 00:13:56 --> Could not find the language line "section"
ERROR - 2025-10-24 00:13:56 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:14:06 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:14:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:14:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:14:15 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:14:26 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:14:36 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:14:46 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:15:02 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:15:13 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:15:22 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:15:43 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:15:53 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:16:11 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:16:22 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:16:32 --> Could not find the language line "section"
ERROR - 2025-10-24 00:16:32 --> Could not find the language line "section"
ERROR - 2025-10-24 00:16:32 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:16:41 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:16:52 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:17:29 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:17:36 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:17:48 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:18:13 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:18:23 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:18:32 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:18:52 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:19:03 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:19:13 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:19:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:19:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:19:43 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:20:14 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:20:15 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:20:18 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:20:28 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:20:39 --> Could not find the language line "recommended"
ERROR - 2025-10-24 00:21:04 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-24 00:21:04 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-24 00:21:04 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 00:21:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 00:21:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 01:52:49 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 02:38:41 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 02:38:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 02:38:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 02:56:41 --> Could not find the language line "recommended"
ERROR - 2025-10-24 02:59:22 --> Could not find the language line "recommended"
ERROR - 2025-10-24 03:01:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 03:40:12 --> Could not find the language line "recommended"
ERROR - 2025-10-24 03:55:19 --> Could not find the language line "recommended"
ERROR - 2025-10-24 03:56:03 --> Could not find the language line "email_us"
ERROR - 2025-10-24 04:01:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 04:01:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 04:01:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 04:11:55 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-24 04:11:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-24 04:11:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-24 04:11:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-24 04:11:56 --> Could not find the language line "recommended"
ERROR - 2025-10-24 04:53:30 --> Could not find the language line "return_policy"
ERROR - 2025-10-24 04:53:30 --> Could not find the language line "return_policy"
ERROR - 2025-10-24 06:51:45 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 06:55:54 --> Could not find the language line "recommended"
ERROR - 2025-10-24 06:58:46 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-24 06:58:46 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-24 07:46:25 --> Could not find the language line "recommended"
ERROR - 2025-10-24 08:11:12 --> Could not find the language line "recommended"
ERROR - 2025-10-24 08:40:49 --> Could not find the language line "recommended"
ERROR - 2025-10-24 08:55:10 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 08:55:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 08:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 09:01:30 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 09:01:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 09:01:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 09:41:19 --> Could not find the language line "email_us"
ERROR - 2025-10-24 10:00:45 --> Could not find the language line "email_us"
ERROR - 2025-10-24 10:09:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 10:09:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 10:09:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 10:31:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 10:31:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 10:31:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 10:35:19 --> Could not find the language line "recommended"
ERROR - 2025-10-24 10:46:09 --> Could not find the language line "recommended"
ERROR - 2025-10-24 10:57:49 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:01:39 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:15:55 --> Could not find the language line "section"
ERROR - 2025-10-24 11:15:55 --> Could not find the language line "section"
ERROR - 2025-10-24 11:15:55 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:17:44 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:27:03 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:36:13 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:46:18 --> Could not find the language line "recommended"
ERROR - 2025-10-24 11:54:58 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:02:06 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:04:56 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 12:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 12:04:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 12:06:55 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:09:37 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:09:37 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:14:30 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:37:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 12:51:02 --> Could not find the language line "recommended"
ERROR - 2025-10-24 13:03:26 --> Could not find the language line "recommended"
ERROR - 2025-10-24 13:14:39 --> Could not find the language line "recommended"
ERROR - 2025-10-24 13:26:39 --> Could not find the language line "recommended"
ERROR - 2025-10-24 13:32:00 --> Could not find the language line "recommended"
ERROR - 2025-10-24 13:49:45 --> Could not find the language line "recommended"
ERROR - 2025-10-24 13:49:58 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 13:49:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 13:49:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 14:01:56 --> Could not find the language line "recommended"
ERROR - 2025-10-24 14:13:52 --> Could not find the language line "recommended"
ERROR - 2025-10-24 14:29:16 --> Could not find the language line "recommended"
ERROR - 2025-10-24 14:40:51 --> Could not find the language line "recommended"
ERROR - 2025-10-24 14:52:54 --> Could not find the language line "recommended"
ERROR - 2025-10-24 15:03:53 --> Could not find the language line "recommended"
ERROR - 2025-10-24 15:09:19 --> Could not find the language line "recommended"
ERROR - 2025-10-24 15:15:30 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 15:27:06 --> Could not find the language line "recommended"
ERROR - 2025-10-24 15:38:29 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-24 15:38:29 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-24 15:38:29 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 15:38:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 15:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 15:48:55 --> Could not find the language line "recommended"
ERROR - 2025-10-24 16:14:37 --> Could not find the language line "recommended"
ERROR - 2025-10-24 16:34:39 --> Could not find the language line "recommended"
ERROR - 2025-10-24 16:54:34 --> Could not find the language line "recommended"
ERROR - 2025-10-24 17:11:15 --> Could not find the language line "recommended"
ERROR - 2025-10-24 17:27:58 --> Could not find the language line "recommended"
ERROR - 2025-10-24 17:43:36 --> Could not find the language line "recommended"
ERROR - 2025-10-24 18:15:29 --> Could not find the language line "recommended"
ERROR - 2025-10-24 18:28:36 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 18:28:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 18:28:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 18:29:11 --> Could not find the language line "recommended"
ERROR - 2025-10-24 18:30:38 --> Could not find the language line "recommended"
ERROR - 2025-10-24 18:45:03 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 18:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 18:45:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 18:58:29 --> Could not find the language line "recommended"
ERROR - 2025-10-24 19:11:48 --> Could not find the language line "check_availability"
ERROR - 2025-10-24 19:11:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 19:11:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-24 19:24:34 --> Could not find the language line "recommended"
ERROR - 2025-10-24 19:37:18 --> Could not find the language line "recommended"
ERROR - 2025-10-24 19:51:55 --> Could not find the language line "recommended"
ERROR - 2025-10-24 20:07:39 --> Could not find the language line "recommended"
ERROR - 2025-10-24 20:24:43 --> Could not find the language line "recommended"
ERROR - 2025-10-24 20:38:50 --> Could not find the language line "recommended"
ERROR - 2025-10-24 20:51:40 --> Could not find the language line "recommended"
ERROR - 2025-10-24 21:04:08 --> Could not find the language line "recommended"
ERROR - 2025-10-24 21:28:05 --> Could not find the language line "recommended"
ERROR - 2025-10-24 21:41:09 --> Could not find the language line "recommended"
ERROR - 2025-10-24 21:53:28 --> Could not find the language line "recommended"
ERROR - 2025-10-24 22:16:05 --> Could not find the language line "recommended"
ERROR - 2025-10-24 22:34:34 --> Could not find the language line "recommended"
ERROR - 2025-10-24 22:52:14 --> Could not find the language line "recommended"
ERROR - 2025-10-24 23:08:48 --> Could not find the language line "recommended"
ERROR - 2025-10-24 23:25:17 --> Could not find the language line "recommended"
ERROR - 2025-10-24 23:43:15 --> Could not find the language line "recommended"
ERROR - 2025-10-24 23:47:02 --> Could not find the language line "recommended"
