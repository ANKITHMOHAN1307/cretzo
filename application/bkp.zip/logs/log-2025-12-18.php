<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-18 22:10:59 --> Could not find the language line "section"
ERROR - 2025-12-18 22:10:59 --> Could not find the language line "search"
ERROR - 2025-12-18 22:10:59 --> Could not find the language line "recommended"
ERROR - 2025-12-18 22:13:13 --> Could not find the language line "recommended"
ERROR - 2025-12-18 22:13:19 --> Could not find the language line "recommended"
ERROR - 2025-12-18 22:13:19 --> Could not find the language line "recommended"
ERROR - 2025-12-18 23:02:34 --> Could not find the language line "check_availability"
ERROR - 2025-12-18 23:02:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-18 23:02:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-18 23:39:36 --> Could not find the language line "recommended"
ERROR - 2025-12-18 23:50:47 --> Could not find the language line "check_availability"
ERROR - 2025-12-18 23:50:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-18 23:50:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
