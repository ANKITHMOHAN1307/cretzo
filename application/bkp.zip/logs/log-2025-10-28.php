<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-28 00:04:41 --> Could not find the language line "recommended"
ERROR - 2025-10-28 00:16:13 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 00:16:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 00:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 01:43:44 --> Could not find the language line "return_policy"
ERROR - 2025-10-28 01:43:44 --> Could not find the language line "return_policy"
ERROR - 2025-10-28 02:00:38 --> Could not find the language line "recommended"
ERROR - 2025-10-28 02:07:37 --> Could not find the language line "recommended"
ERROR - 2025-10-28 02:24:05 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 02:24:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 02:24:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 02:42:49 --> Could not find the language line "recommended"
ERROR - 2025-10-28 02:55:53 --> Could not find the language line "recommended"
ERROR - 2025-10-28 02:58:04 --> Could not find the language line "recommended"
ERROR - 2025-10-28 03:01:30 --> Could not find the language line "recommended"
ERROR - 2025-10-28 03:05:15 --> Could not find the language line "recommended"
ERROR - 2025-10-28 03:19:21 --> Could not find the language line "recommended"
ERROR - 2025-10-28 03:35:38 --> Could not find the language line "recommended"
ERROR - 2025-10-28 03:37:30 --> Could not find the language line "recommended"
ERROR - 2025-10-28 03:54:54 --> Could not find the language line "recommended"
ERROR - 2025-10-28 05:31:52 --> Could not find the language line "recommended"
ERROR - 2025-10-28 05:34:10 --> Could not find the language line "recommended"
ERROR - 2025-10-28 05:52:05 --> Could not find the language line "recommended"
ERROR - 2025-10-28 05:58:14 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 05:58:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 05:58:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 06:09:04 --> Could not find the language line "recommended"
ERROR - 2025-10-28 06:49:38 --> Could not find the language line "recommended"
ERROR - 2025-10-28 07:07:11 --> Could not find the language line "recommended"
ERROR - 2025-10-28 07:25:23 --> Could not find the language line "recommended"
ERROR - 2025-10-28 07:25:45 --> Could not find the language line "recommended"
ERROR - 2025-10-28 08:04:51 --> Could not find the language line "recommended"
ERROR - 2025-10-28 08:26:51 --> Could not find the language line "recommended"
ERROR - 2025-10-28 08:27:25 --> Could not find the language line "recommended"
ERROR - 2025-10-28 08:39:57 --> Could not find the language line "recommended"
ERROR - 2025-10-28 08:39:57 --> Could not find the language line "recommended"
ERROR - 2025-10-28 09:02:14 --> Could not find the language line "recommended"
ERROR - 2025-10-28 09:32:48 --> Could not find the language line "recommended"
ERROR - 2025-10-28 10:03:23 --> Could not find the language line "recommended"
ERROR - 2025-10-28 10:15:56 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 10:15:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 10:15:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 10:48:57 --> Could not find the language line "recommended"
ERROR - 2025-10-28 11:29:42 --> Could not find the language line "recommended"
ERROR - 2025-10-28 11:38:50 --> Could not find the language line "login_heading"
ERROR - 2025-10-28 11:38:50 --> Could not find the language line "login_password_label"
ERROR - 2025-10-28 11:38:52 --> Could not find the language line "support_chat"
ERROR - 2025-10-28 11:38:52 --> Could not find the language line "label_close"
ERROR - 2025-10-28 11:38:52 --> Could not find the language line "label_search"
ERROR - 2025-10-28 11:38:52 --> Could not find the language line "label_search_result"
ERROR - 2025-10-28 11:42:59 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 11:42:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 11:42:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 12:31:36 --> Could not find the language line "recommended"
ERROR - 2025-10-28 12:32:17 --> Could not find the language line "email_us"
ERROR - 2025-10-28 12:32:42 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-28 12:32:42 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-28 12:32:42 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 12:32:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 12:32:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 13:00:24 --> Could not find the language line "recommended"
ERROR - 2025-10-28 13:43:30 --> Could not find the language line "recommended"
ERROR - 2025-10-28 14:03:45 --> Could not find the language line "recommended"
ERROR - 2025-10-28 14:28:56 --> Could not find the language line "recommended"
ERROR - 2025-10-28 14:36:14 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 14:36:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 14:36:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 14:38:05 --> Could not find the language line "recommended"
ERROR - 2025-10-28 14:53:02 --> Could not find the language line "recommended"
ERROR - 2025-10-28 15:13:24 --> Could not find the language line "recommended"
ERROR - 2025-10-28 15:33:46 --> Could not find the language line "recommended"
ERROR - 2025-10-28 15:54:05 --> Could not find the language line "recommended"
ERROR - 2025-10-28 16:36:49 --> Could not find the language line "section"
ERROR - 2025-10-28 16:36:49 --> Could not find the language line "tags"
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $total_rows /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-10-28 16:36:49 --> Could not find the language line "recommended"
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-10-28 16:36:49 --> Severity: Warning --> Undefined variable $num_pages /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-10-28 16:40:49 --> Could not find the language line "recommended"
ERROR - 2025-10-28 17:02:17 --> Could not find the language line "recommended"
ERROR - 2025-10-28 17:22:06 --> Could not find the language line "recommended"
ERROR - 2025-10-28 17:42:50 --> Could not find the language line "recommended"
ERROR - 2025-10-28 18:23:58 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 18:23:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 18:23:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 18:31:59 --> Could not find the language line "recommended"
ERROR - 2025-10-28 18:49:47 --> Could not find the language line "login_heading"
ERROR - 2025-10-28 18:49:47 --> Could not find the language line "login_password_label"
ERROR - 2025-10-28 18:49:49 --> Could not find the language line "support_chat"
ERROR - 2025-10-28 18:49:49 --> Could not find the language line "label_close"
ERROR - 2025-10-28 18:49:49 --> Could not find the language line "label_search"
ERROR - 2025-10-28 18:49:49 --> Could not find the language line "label_search_result"
ERROR - 2025-10-28 18:50:30 --> Could not find the language line "promocodes"
ERROR - 2025-10-28 18:50:36 --> Could not find the language line "estimate_date"
ERROR - 2025-10-28 18:50:36 --> Could not find the language line "wallet_balance"
ERROR - 2025-10-28 18:50:36 --> Could not find the language line "available_balance"
ERROR - 2025-10-28 18:50:36 --> Could not find the language line "estimate_date"
ERROR - 2025-10-28 18:50:36 --> Could not find the language line "promocodes"
ERROR - 2025-10-28 18:51:02 --> Could not find the language line "estimate_date"
ERROR - 2025-10-28 18:51:02 --> Could not find the language line "wallet_balance"
ERROR - 2025-10-28 18:51:02 --> Could not find the language line "available_balance"
ERROR - 2025-10-28 18:51:02 --> Could not find the language line "estimate_date"
ERROR - 2025-10-28 18:51:02 --> Could not find the language line "promocodes"
ERROR - 2025-10-28 18:51:13 --> Could not find the language line "estimate_date"
ERROR - 2025-10-28 18:51:13 --> Could not find the language line "wallet_balance"
ERROR - 2025-10-28 18:51:13 --> Could not find the language line "available_balance"
ERROR - 2025-10-28 18:51:13 --> Could not find the language line "estimate_date"
ERROR - 2025-10-28 18:51:13 --> Could not find the language line "promocodes"
ERROR - 2025-10-28 18:51:23 --> Could not find the language line "promocodes"
ERROR - 2025-10-28 18:51:39 --> Could not find the language line "support_chat"
ERROR - 2025-10-28 18:51:39 --> Could not find the language line "label_close"
ERROR - 2025-10-28 18:51:39 --> Could not find the language line "label_search"
ERROR - 2025-10-28 18:51:39 --> Could not find the language line "label_search_result"
ERROR - 2025-10-28 18:54:22 --> Could not find the language line "recommended"
ERROR - 2025-10-28 19:16:14 --> Could not find the language line "recommended"
ERROR - 2025-10-28 19:20:15 --> Could not find the language line "support_chat"
ERROR - 2025-10-28 19:20:15 --> Could not find the language line "label_close"
ERROR - 2025-10-28 19:20:15 --> Could not find the language line "label_search"
ERROR - 2025-10-28 19:20:15 --> Could not find the language line "label_search_result"
ERROR - 2025-10-28 19:37:42 --> Could not find the language line "recommended"
ERROR - 2025-10-28 19:59:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-28 19:59:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 19:59:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-28 20:49:58 --> Could not find the language line "recommended"
ERROR - 2025-10-28 21:08:28 --> Could not find the language line "email_us"
ERROR - 2025-10-28 21:11:40 --> Could not find the language line "recommended"
ERROR - 2025-10-28 21:33:06 --> Could not find the language line "recommended"
ERROR - 2025-10-28 21:53:07 --> Could not find the language line "recommended"
ERROR - 2025-10-28 22:39:02 --> Could not find the language line "recommended"
ERROR - 2025-10-28 22:57:57 --> Could not find the language line "recommended"
ERROR - 2025-10-28 23:18:26 --> Could not find the language line "recommended"
ERROR - 2025-10-28 23:39:36 --> Could not find the language line "recommended"
