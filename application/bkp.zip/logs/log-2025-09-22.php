<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-22 01:35:30 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:20:41 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:21:43 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:40:59 --> Could not find the language line "email_us"
ERROR - 2025-09-22 03:41:00 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:01 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:02 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:02 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:04 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:09 --> Could not find the language line "section"
ERROR - 2025-09-22 03:41:09 --> Could not find the language line "section"
ERROR - 2025-09-22 03:41:09 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:10 --> Could not find the language line "section"
ERROR - 2025-09-22 03:41:10 --> Could not find the language line "section"
ERROR - 2025-09-22 03:41:10 --> Could not find the language line "recommended"
ERROR - 2025-09-22 03:41:14 --> Could not find the language line "email_us"
ERROR - 2025-09-22 04:51:33 --> Could not find the language line "recommended"
ERROR - 2025-09-22 04:51:35 --> Could not find the language line "recommended"
ERROR - 2025-09-22 05:02:10 --> Could not find the language line "check_availability"
ERROR - 2025-09-22 05:02:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-22 05:02:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-22 06:19:18 --> Could not find the language line "recommended"
ERROR - 2025-09-22 08:49:38 --> Could not find the language line "recommended"
ERROR - 2025-09-22 15:03:14 --> Could not find the language line "recommended"
ERROR - 2025-09-22 15:33:54 --> Could not find the language line "recommended"
ERROR - 2025-09-22 15:41:05 --> Could not find the language line "section"
ERROR - 2025-09-22 15:41:05 --> Could not find the language line "tags"
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $total_rows /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-09-22 15:41:05 --> Could not find the language line "recommended"
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-09-22 15:41:05 --> Severity: Warning --> Undefined variable $num_pages /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-09-22 17:58:47 --> Could not find the language line "login_heading"
ERROR - 2025-09-22 17:58:47 --> Severity: Warning --> Undefined array key "identity" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 520
ERROR - 2025-09-22 17:58:47 --> Severity: Warning --> Undefined array key "identity" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 525
ERROR - 2025-09-22 17:58:47 --> Severity: Warning --> Undefined array key "type" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 532
ERROR - 2025-09-22 17:58:47 --> Could not find the language line "login_password_label"
ERROR - 2025-09-22 17:58:47 --> Severity: error --> Exception: Call to undefined method Home::_render_page() /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 637
ERROR - 2025-09-22 19:32:02 --> Could not find the language line "email_us"
ERROR - 2025-09-22 19:32:02 --> Could not find the language line "email_us"
ERROR - 2025-09-22 19:35:57 --> Could not find the language line "recommended"
ERROR - 2025-09-22 20:01:31 --> Could not find the language line "recommended"
ERROR - 2025-09-22 22:10:27 --> Could not find the language line "recommended"
ERROR - 2025-09-22 22:28:21 --> Could not find the language line "recommended"
ERROR - 2025-09-22 23:10:19 --> Could not find the language line "email_us"
ERROR - 2025-09-22 23:10:21 --> Could not find the language line "email_us"
ERROR - 2025-09-22 23:10:27 --> Could not find the language line "shipping_policy"
ERROR - 2025-09-22 23:10:27 --> Could not find the language line "shipping_policy"
