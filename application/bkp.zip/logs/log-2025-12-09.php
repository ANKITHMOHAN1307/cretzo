<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-09 00:30:09 --> Could not find the language line "recommended"
ERROR - 2025-12-09 01:06:48 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 01:22:26 --> Could not find the language line "recommended"
ERROR - 2025-12-09 01:36:11 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 01:36:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 01:36:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 01:38:56 --> Severity: Warning --> Undefined array key "q" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 919
ERROR - 2025-12-09 01:38:56 --> Could not find the language line "section"
ERROR - 2025-12-09 01:38:56 --> Could not find the language line "search"
ERROR - 2025-12-09 01:38:57 --> Could not find the language line "recommended"
ERROR - 2025-12-09 02:01:05 --> Could not find the language line "section"
ERROR - 2025-12-09 02:01:05 --> Could not find the language line "section"
ERROR - 2025-12-09 02:01:05 --> Could not find the language line "recommended"
ERROR - 2025-12-09 02:13:20 --> Could not find the language line "section"
ERROR - 2025-12-09 02:13:20 --> Could not find the language line "section"
ERROR - 2025-12-09 02:13:20 --> Could not find the language line "recommended"
ERROR - 2025-12-09 02:25:33 --> Could not find the language line "recommended"
ERROR - 2025-12-09 02:37:30 --> Could not find the language line "section"
ERROR - 2025-12-09 02:37:30 --> Could not find the language line "section"
ERROR - 2025-12-09 02:37:30 --> Could not find the language line "recommended"
ERROR - 2025-12-09 03:00:36 --> Could not find the language line "section"
ERROR - 2025-12-09 03:00:36 --> Could not find the language line "section"
ERROR - 2025-12-09 03:00:36 --> Could not find the language line "recommended"
ERROR - 2025-12-09 03:19:37 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 03:19:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 03:19:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 03:28:06 --> Could not find the language line "recommended"
ERROR - 2025-12-09 03:41:30 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 03:41:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 03:41:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 03:54:10 --> Could not find the language line "recommended"
ERROR - 2025-12-09 04:19:50 --> Could not find the language line "section"
ERROR - 2025-12-09 04:19:50 --> Could not find the language line "section"
ERROR - 2025-12-09 04:19:50 --> Could not find the language line "recommended"
ERROR - 2025-12-09 04:45:26 --> Could not find the language line "recommended"
ERROR - 2025-12-09 04:58:40 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 04:58:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 04:58:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 05:14:22 --> Could not find the language line "recommended"
ERROR - 2025-12-09 05:46:19 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-09 05:46:19 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-09 05:46:19 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 05:46:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 05:46:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 05:59:20 --> Could not find the language line "recommended"
ERROR - 2025-12-09 06:34:49 --> Could not find the language line "recommended"
ERROR - 2025-12-09 06:46:21 --> Could not find the language line "recommended"
ERROR - 2025-12-09 06:58:36 --> Could not find the language line "recommended"
ERROR - 2025-12-09 07:13:38 --> Could not find the language line "recommended"
ERROR - 2025-12-09 07:54:00 --> Could not find the language line "recommended"
ERROR - 2025-12-09 08:11:46 --> Could not find the language line "recommended"
ERROR - 2025-12-09 08:27:59 --> Could not find the language line "recommended"
ERROR - 2025-12-09 08:41:02 --> Could not find the language line "recommended"
ERROR - 2025-12-09 08:45:17 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-09 08:45:17 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-09 09:02:48 --> Could not find the language line "recommended"
ERROR - 2025-12-09 09:13:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 09:13:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 09:13:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 09:26:09 --> Could not find the language line "recommended"
ERROR - 2025-12-09 09:47:55 --> Could not find the language line "compare"
ERROR - 2025-12-09 10:08:21 --> Could not find the language line "recommended"
ERROR - 2025-12-09 10:48:59 --> Could not find the language line "recommended"
ERROR - 2025-12-09 11:10:49 --> Could not find the language line "return_policy"
ERROR - 2025-12-09 11:10:49 --> Could not find the language line "return_policy"
ERROR - 2025-12-09 11:17:29 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 11:17:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 11:17:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 11:23:25 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 11:23:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 11:23:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 11:26:48 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 11:26:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 11:26:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 11:47:21 --> Could not find the language line "recommended"
ERROR - 2025-12-09 12:20:33 --> Could not find the language line "recommended"
ERROR - 2025-12-09 13:09:53 --> Could not find the language line "recommended"
ERROR - 2025-12-09 14:00:39 --> Could not find the language line "recommended"
ERROR - 2025-12-09 14:51:36 --> Could not find the language line "recommended"
ERROR - 2025-12-09 15:43:23 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 15:43:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 15:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 16:31:51 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-09 16:31:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-09 16:31:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-09 16:31:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-09 16:31:52 --> Could not find the language line "recommended"
ERROR - 2025-12-09 16:45:50 --> Could not find the language line "recommended"
ERROR - 2025-12-09 16:59:39 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 16:59:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 16:59:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 17:54:55 --> Could not find the language line "recommended"
ERROR - 2025-12-09 18:10:59 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 18:10:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 18:10:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 18:30:32 --> Could not find the language line "recommended"
ERROR - 2025-12-09 19:05:04 --> Could not find the language line "recommended"
ERROR - 2025-12-09 19:08:43 --> Could not find the language line "recommended"
ERROR - 2025-12-09 19:14:47 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 19:14:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 19:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 19:19:34 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 19:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 19:19:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 20:12:19 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 20:12:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 20:12:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 20:24:48 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 20:24:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 20:24:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-09 20:46:16 --> Could not find the language line "recommended"
ERROR - 2025-12-09 20:50:44 --> Could not find the language line "check_availability"
ERROR - 2025-12-09 21:24:31 --> Could not find the language line "recommended"
ERROR - 2025-12-09 21:55:30 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:09:54 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:05 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:06 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:09 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:12 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:35 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:37 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:10:39 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:52:09 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:52:12 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 289
ERROR - 2025-12-09 22:52:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 289
ERROR - 2025-12-09 22:52:12 --> Could not find the language line "recommended"
ERROR - 2025-12-09 22:58:49 --> Could not find the language line "recommended"
ERROR - 2025-12-09 23:01:32 --> Could not find the language line "recommended"
ERROR - 2025-12-09 23:39:23 --> Could not find the language line "recommended"
