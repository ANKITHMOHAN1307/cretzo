<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-18 00:29:02 --> Could not find the language line "recommended"
ERROR - 2025-10-18 00:42:21 --> Could not find the language line "recommended"
ERROR - 2025-10-18 00:44:27 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 00:44:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 00:44:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 01:06:08 --> Could not find the language line "recommended"
ERROR - 2025-10-18 01:23:46 --> Could not find the language line "recommended"
ERROR - 2025-10-18 01:28:05 --> Could not find the language line "recommended"
ERROR - 2025-10-18 01:41:25 --> Could not find the language line "recommended"
ERROR - 2025-10-18 01:47:55 --> Could not find the language line "recommended"
ERROR - 2025-10-18 01:59:49 --> Could not find the language line "recommended"
ERROR - 2025-10-18 02:21:13 --> Could not find the language line "recommended"
ERROR - 2025-10-18 02:42:09 --> Could not find the language line "recommended"
ERROR - 2025-10-18 03:01:12 --> Could not find the language line "recommended"
ERROR - 2025-10-18 03:20:25 --> Could not find the language line "recommended"
ERROR - 2025-10-18 03:40:29 --> Could not find the language line "recommended"
ERROR - 2025-10-18 03:59:44 --> Could not find the language line "recommended"
ERROR - 2025-10-18 04:24:01 --> Could not find the language line "recommended"
ERROR - 2025-10-18 04:44:27 --> Could not find the language line "recommended"
ERROR - 2025-10-18 05:04:35 --> Could not find the language line "recommended"
ERROR - 2025-10-18 05:24:12 --> Could not find the language line "recommended"
ERROR - 2025-10-18 05:43:09 --> Could not find the language line "recommended"
ERROR - 2025-10-18 05:59:27 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:16:13 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:32:41 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:38:38 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:50:55 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:50:56 --> Could not find the language line "email_us"
ERROR - 2025-10-18 06:50:57 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:50:59 --> Could not find the language line "section"
ERROR - 2025-10-18 06:50:59 --> Could not find the language line "section"
ERROR - 2025-10-18 06:50:59 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:00 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:02 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 06:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 06:51:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 06:51:02 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:06 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 06:51:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 06:51:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 06:51:07 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:13 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:14 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 06:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 06:51:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 06:51:18 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:21 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:23 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:24 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:26 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:27 --> Could not find the language line "recommended"
ERROR - 2025-10-18 06:51:29 --> Could not find the language line "recommended"
ERROR - 2025-10-18 07:10:07 --> Could not find the language line "recommended"
ERROR - 2025-10-18 07:25:54 --> Could not find the language line "recommended"
ERROR - 2025-10-18 07:41:41 --> Could not find the language line "recommended"
ERROR - 2025-10-18 07:57:17 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-18 07:57:17 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-18 07:57:17 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 07:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 07:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 08:51:45 --> Could not find the language line "recommended"
ERROR - 2025-10-18 09:06:27 --> Could not find the language line "recommended"
ERROR - 2025-10-18 09:23:22 --> Could not find the language line "recommended"
ERROR - 2025-10-18 09:31:12 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 09:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 09:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 09:40:03 --> Could not find the language line "recommended"
ERROR - 2025-10-18 09:58:23 --> Could not find the language line "recommended"
ERROR - 2025-10-18 10:19:19 --> Could not find the language line "recommended"
ERROR - 2025-10-18 10:56:50 --> Could not find the language line "recommended"
ERROR - 2025-10-18 11:15:41 --> Could not find the language line "recommended"
ERROR - 2025-10-18 11:33:05 --> Could not find the language line "recommended"
ERROR - 2025-10-18 11:50:11 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 12:10:58 --> Could not find the language line "recommended"
ERROR - 2025-10-18 12:30:20 --> Could not find the language line "recommended"
ERROR - 2025-10-18 12:47:06 --> Could not find the language line "recommended"
ERROR - 2025-10-18 13:03:41 --> Could not find the language line "recommended"
ERROR - 2025-10-18 13:19:54 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 13:19:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 13:19:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 13:26:01 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 13:36:21 --> Could not find the language line "recommended"
ERROR - 2025-10-18 14:13:41 --> Could not find the language line "recommended"
ERROR - 2025-10-18 14:31:52 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 14:31:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 14:31:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 14:39:15 --> Could not find the language line "email_us"
ERROR - 2025-10-18 14:43:53 --> Could not find the language line "email_us"
ERROR - 2025-10-18 14:48:30 --> Could not find the language line "recommended"
ERROR - 2025-10-18 15:04:19 --> Could not find the language line "recommended"
ERROR - 2025-10-18 15:12:44 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 15:12:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 15:12:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 15:20:02 --> Could not find the language line "recommended"
ERROR - 2025-10-18 15:35:43 --> Could not find the language line "recommended"
ERROR - 2025-10-18 15:50:49 --> Could not find the language line "recommended"
ERROR - 2025-10-18 16:09:23 --> Could not find the language line "recommended"
ERROR - 2025-10-18 16:17:58 --> Could not find the language line "recommended"
ERROR - 2025-10-18 16:33:40 --> Could not find the language line "recommended"
ERROR - 2025-10-18 16:57:52 --> Could not find the language line "recommended"
ERROR - 2025-10-18 17:19:27 --> Could not find the language line "recommended"
ERROR - 2025-10-18 17:22:11 --> Could not find the language line "recommended"
ERROR - 2025-10-18 17:46:11 --> Could not find the language line "recommended"
ERROR - 2025-10-18 18:11:08 --> Could not find the language line "email_us"
ERROR - 2025-10-18 18:15:09 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 18:15:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 18:15:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 18:49:44 --> Could not find the language line "recommended"
ERROR - 2025-10-18 19:05:38 --> Could not find the language line "recommended"
ERROR - 2025-10-18 19:23:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 19:23:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 19:23:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 19:31:16 --> Could not find the language line "recommended"
ERROR - 2025-10-18 19:45:12 --> Could not find the language line "recommended"
ERROR - 2025-10-18 20:15:24 --> Could not find the language line "recommended"
ERROR - 2025-10-18 20:29:09 --> Could not find the language line "recommended"
ERROR - 2025-10-18 21:02:25 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 21:02:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 21:02:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 21:21:12 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 21:21:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 21:21:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 22:12:29 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 22:12:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 22:12:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 23:17:46 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-18 23:17:46 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-18 23:17:46 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 23:17:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 23:17:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 23:23:53 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 23:23:56 --> Could not find the language line "recommended"
ERROR - 2025-10-18 23:27:38 --> Could not find the language line "recommended"
ERROR - 2025-10-18 23:45:44 --> Could not find the language line "check_availability"
ERROR - 2025-10-18 23:45:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-18 23:45:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
