<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-25 00:38:09 --> Could not find the language line "recommended"
ERROR - 2025-09-25 00:40:13 --> Could not find the language line "recommended"
ERROR - 2025-09-25 00:51:54 --> Could not find the language line "recommended"
ERROR - 2025-09-25 05:20:45 --> Could not find the language line "recommended"
ERROR - 2025-09-25 07:12:56 --> Could not find the language line "recommended"
ERROR - 2025-09-25 09:11:05 --> Could not find the language line "recommended"
ERROR - 2025-09-25 11:47:07 --> Could not find the language line "check_availability"
ERROR - 2025-09-25 11:47:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-25 11:47:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-25 12:27:16 --> Could not find the language line "recommended"
ERROR - 2025-09-25 14:14:45 --> Could not find the language line "email_us"
ERROR - 2025-09-25 18:10:52 --> Could not find the language line "recommended"
ERROR - 2025-09-25 18:28:18 --> Could not find the language line "email_us"
ERROR - 2025-09-25 18:28:23 --> Could not find the language line "email_us"
ERROR - 2025-09-25 18:28:57 --> Could not find the language line "recommended"
ERROR - 2025-09-25 21:56:55 --> Could not find the language line "recommended"
ERROR - 2025-09-25 23:18:31 --> Could not find the language line "recommended"
ERROR - 2025-09-25 23:21:49 --> Could not find the language line "compare"
