<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-12 01:46:14 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 01:55:28 --> Could not find the language line "recommended"
ERROR - 2025-10-12 02:27:35 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 02:27:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 02:27:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 03:26:19 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 03:26:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 03:26:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 04:01:51 --> Could not find the language line "recommended"
ERROR - 2025-10-12 04:22:38 --> Could not find the language line "email_us"
ERROR - 2025-10-12 04:33:22 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 04:33:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 04:33:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 04:34:53 --> Could not find the language line "recommended"
ERROR - 2025-10-12 04:58:33 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 04:58:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 04:58:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 05:27:48 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-12 05:27:48 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-12 05:57:51 --> Could not find the language line "compare"
ERROR - 2025-10-12 06:28:05 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 06:28:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 06:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 06:30:49 --> Could not find the language line "recommended"
ERROR - 2025-10-12 07:22:08 --> Could not find the language line "return_policy"
ERROR - 2025-10-12 07:22:08 --> Could not find the language line "return_policy"
ERROR - 2025-10-12 07:49:38 --> Could not find the language line "email_us"
ERROR - 2025-10-12 08:47:31 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 09:15:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 09:15:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 09:15:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 10:00:20 --> Could not find the language line "recommended"
ERROR - 2025-10-12 10:54:06 --> Could not find the language line "recommended"
ERROR - 2025-10-12 11:17:40 --> Could not find the language line "recommended"
ERROR - 2025-10-12 11:41:41 --> Could not find the language line "recommended"
ERROR - 2025-10-12 12:16:30 --> Could not find the language line "recommended"
ERROR - 2025-10-12 12:49:37 --> Could not find the language line "recommended"
ERROR - 2025-10-12 13:14:17 --> Could not find the language line "recommended"
ERROR - 2025-10-12 13:37:32 --> Could not find the language line "recommended"
ERROR - 2025-10-12 14:01:55 --> Could not find the language line "recommended"
ERROR - 2025-10-12 14:30:28 --> Could not find the language line "recommended"
ERROR - 2025-10-12 14:59:08 --> Could not find the language line "recommended"
ERROR - 2025-10-12 15:08:44 --> Could not find the language line "recommended"
ERROR - 2025-10-12 15:25:54 --> Could not find the language line "recommended"
ERROR - 2025-10-12 15:58:48 --> Could not find the language line "recommended"
ERROR - 2025-10-12 16:33:46 --> Could not find the language line "recommended"
ERROR - 2025-10-12 16:55:40 --> Could not find the language line "recommended"
ERROR - 2025-10-12 17:15:37 --> Could not find the language line "recommended"
ERROR - 2025-10-12 17:28:41 --> Could not find the language line "recommended"
ERROR - 2025-10-12 17:28:47 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 17:28:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 17:28:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 17:28:57 --> Could not find the language line "recommended"
ERROR - 2025-10-12 17:38:31 --> Could not find the language line "check_availability"
ERROR - 2025-10-12 17:38:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 17:38:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-12 17:40:51 --> Could not find the language line "recommended"
ERROR - 2025-10-12 17:57:03 --> Could not find the language line "recommended"
ERROR - 2025-10-12 18:43:23 --> Could not find the language line "recommended"
ERROR - 2025-10-12 19:00:59 --> Could not find the language line "recommended"
ERROR - 2025-10-12 19:20:41 --> Could not find the language line "recommended"
ERROR - 2025-10-12 19:38:15 --> Could not find the language line "recommended"
ERROR - 2025-10-12 19:54:45 --> Could not find the language line "recommended"
ERROR - 2025-10-12 20:16:25 --> Could not find the language line "recommended"
ERROR - 2025-10-12 20:33:29 --> Could not find the language line "recommended"
ERROR - 2025-10-12 20:51:38 --> Could not find the language line "recommended"
ERROR - 2025-10-12 21:10:12 --> Could not find the language line "recommended"
ERROR - 2025-10-12 21:33:26 --> Could not find the language line "recommended"
ERROR - 2025-10-12 21:50:05 --> Could not find the language line "recommended"
ERROR - 2025-10-12 22:07:04 --> Could not find the language line "recommended"
ERROR - 2025-10-12 22:26:55 --> Could not find the language line "recommended"
ERROR - 2025-10-12 22:45:39 --> Could not find the language line "recommended"
ERROR - 2025-10-12 23:05:17 --> Could not find the language line "recommended"
ERROR - 2025-10-12 23:23:50 --> Could not find the language line "recommended"
ERROR - 2025-10-12 23:42:14 --> Could not find the language line "recommended"
