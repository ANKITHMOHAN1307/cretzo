<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-04 00:06:51 --> Could not find the language line "recommended"
ERROR - 2025-10-04 00:18:04 --> Could not find the language line "recommended"
ERROR - 2025-10-04 00:29:07 --> Could not find the language line "recommended"
ERROR - 2025-10-04 00:39:12 --> Could not find the language line "recommended"
ERROR - 2025-10-04 00:48:48 --> Could not find the language line "recommended"
ERROR - 2025-10-04 00:58:57 --> Could not find the language line "recommended"
ERROR - 2025-10-04 01:09:05 --> Could not find the language line "recommended"
ERROR - 2025-10-04 01:19:25 --> Could not find the language line "recommended"
ERROR - 2025-10-04 01:28:57 --> Could not find the language line "recommended"
ERROR - 2025-10-04 01:38:41 --> Could not find the language line "recommended"
ERROR - 2025-10-04 01:49:27 --> Could not find the language line "recommended"
ERROR - 2025-10-04 01:58:41 --> Could not find the language line "recommended"
ERROR - 2025-10-04 02:10:45 --> Could not find the language line "recommended"
ERROR - 2025-10-04 02:33:08 --> Could not find the language line "recommended"
ERROR - 2025-10-04 02:52:24 --> Could not find the language line "recommended"
ERROR - 2025-10-04 03:10:31 --> Could not find the language line "recommended"
ERROR - 2025-10-04 03:29:01 --> Could not find the language line "recommended"
ERROR - 2025-10-04 03:48:04 --> Could not find the language line "recommended"
ERROR - 2025-10-04 04:05:44 --> Could not find the language line "recommended"
ERROR - 2025-10-04 04:26:50 --> Could not find the language line "recommended"
ERROR - 2025-10-04 05:01:10 --> Could not find the language line "recommended"
ERROR - 2025-10-04 05:29:05 --> Could not find the language line "recommended"
ERROR - 2025-10-04 05:37:32 --> Could not find the language line "recommended"
ERROR - 2025-10-04 05:46:10 --> Could not find the language line "recommended"
ERROR - 2025-10-04 06:10:50 --> Could not find the language line "recommended"
ERROR - 2025-10-04 07:07:50 --> Could not find the language line "email_us"
ERROR - 2025-10-04 08:01:35 --> Could not find the language line "recommended"
ERROR - 2025-10-04 08:56:52 --> Could not find the language line "check_availability"
ERROR - 2025-10-04 10:13:51 --> Could not find the language line "recommended"
ERROR - 2025-10-04 12:32:50 --> Could not find the language line "recommended"
ERROR - 2025-10-04 13:26:57 --> Could not find the language line "recommended"
ERROR - 2025-10-04 13:56:37 --> Could not find the language line "email_us"
ERROR - 2025-10-04 13:57:44 --> Could not find the language line "section"
ERROR - 2025-10-04 13:57:44 --> Could not find the language line "section"
ERROR - 2025-10-04 13:57:44 --> Could not find the language line "recommended"
ERROR - 2025-10-04 13:58:02 --> Could not find the language line "email_us"
ERROR - 2025-10-04 16:05:57 --> Could not find the language line "recommended"
ERROR - 2025-10-04 16:05:59 --> Could not find the language line "recommended"
ERROR - 2025-10-04 18:08:11 --> Could not find the language line "recommended"
ERROR - 2025-10-04 19:31:48 --> Could not find the language line "check_availability"
ERROR - 2025-10-04 19:31:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 19:31:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 20:37:26 --> Could not find the language line "recommended"
ERROR - 2025-10-04 21:21:19 --> Could not find the language line "check_availability"
ERROR - 2025-10-04 21:21:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 22:05:42 --> Could not find the language line "check_availability"
ERROR - 2025-10-04 22:05:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 22:05:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 22:35:29 --> Could not find the language line "recommended"
ERROR - 2025-10-04 23:05:07 --> Could not find the language line "recommended"
ERROR - 2025-10-04 23:32:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-04 23:32:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-04 23:32:10 --> Could not find the language line "check_availability"
ERROR - 2025-10-04 23:32:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 23:32:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-04 23:55:51 --> Could not find the language line "recommended"
