<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-07 00:37:20 --> Could not find the language line "email_us"
ERROR - 2025-12-07 00:58:34 --> Could not find the language line "email_us"
ERROR - 2025-12-07 00:58:36 --> Could not find the language line "recommended"
ERROR - 2025-12-07 01:24:04 --> Could not find the language line "email_us"
ERROR - 2025-12-07 01:51:48 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 01:51:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 01:51:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 02:09:36 --> Could not find the language line "email_us"
ERROR - 2025-12-07 02:34:30 --> Could not find the language line "section"
ERROR - 2025-12-07 02:34:30 --> Could not find the language line "section"
ERROR - 2025-12-07 02:34:30 --> Could not find the language line "recommended"
ERROR - 2025-12-07 02:47:27 --> Could not find the language line "login_heading"
ERROR - 2025-12-07 02:47:27 --> Could not find the language line "login_password_label"
ERROR - 2025-12-07 02:47:27 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2401:4900:be80:5480:693b:6281:9fbb:ca2f', '9310703144', 1765055847)
ERROR - 2025-12-07 03:21:38 --> Could not find the language line "section"
ERROR - 2025-12-07 03:21:38 --> Could not find the language line "section"
ERROR - 2025-12-07 03:21:38 --> Could not find the language line "recommended"
ERROR - 2025-12-07 03:30:55 --> Could not find the language line "recommended"
ERROR - 2025-12-07 03:59:04 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 03:59:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 03:59:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 04:37:55 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 04:37:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 04:37:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 04:42:25 --> Could not find the language line "recommended"
ERROR - 2025-12-07 05:01:07 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 05:01:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 05:01:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 05:53:11 --> Could not find the language line "recommended"
ERROR - 2025-12-07 06:22:31 --> Could not find the language line "recommended"
ERROR - 2025-12-07 06:22:54 --> Could not find the language line "recommended"
ERROR - 2025-12-07 06:26:43 --> Could not find the language line "recommended"
ERROR - 2025-12-07 07:40:25 --> Could not find the language line "recommended"
ERROR - 2025-12-07 07:55:14 --> Could not find the language line "recommended"
ERROR - 2025-12-07 07:59:53 --> Could not find the language line "recommended"
ERROR - 2025-12-07 08:09:45 --> Could not find the language line "recommended"
ERROR - 2025-12-07 08:24:17 --> Could not find the language line "recommended"
ERROR - 2025-12-07 08:38:38 --> Could not find the language line "recommended"
ERROR - 2025-12-07 08:44:39 --> Could not find the language line "recommended"
ERROR - 2025-12-07 08:53:22 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-07 08:53:22 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-07 08:56:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 08:56:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 08:56:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 09:12:02 --> Could not find the language line "recommended"
ERROR - 2025-12-07 09:26:20 --> Could not find the language line "recommended"
ERROR - 2025-12-07 09:39:31 --> Could not find the language line "recommended"
ERROR - 2025-12-07 09:51:58 --> Could not find the language line "return_policy"
ERROR - 2025-12-07 09:51:58 --> Could not find the language line "return_policy"
ERROR - 2025-12-07 10:40:48 --> Could not find the language line "email_us"
ERROR - 2025-12-07 10:53:15 --> Could not find the language line "recommended"
ERROR - 2025-12-07 11:40:05 --> Could not find the language line "recommended"
ERROR - 2025-12-07 11:42:07 --> Could not find the language line "recommended"
ERROR - 2025-12-07 11:49:16 --> Could not find the language line "recommended"
ERROR - 2025-12-07 11:58:46 --> Could not find the language line "recommended"
ERROR - 2025-12-07 12:04:14 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 12:04:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 12:04:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 12:14:32 --> Could not find the language line "recommended"
ERROR - 2025-12-07 12:45:57 --> Could not find the language line "recommended"
ERROR - 2025-12-07 13:03:13 --> Could not find the language line "email_us"
ERROR - 2025-12-07 13:20:21 --> Could not find the language line "recommended"
ERROR - 2025-12-07 13:26:20 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2401:4900:be92:9da9:1eb:3188:5249:9180', '9310703144', 1765094180)
ERROR - 2025-12-07 13:31:38 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 13:31:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 13:31:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 13:34:57 --> Could not find the language line "recommended"
ERROR - 2025-12-07 13:49:19 --> Could not find the language line "recommended"
ERROR - 2025-12-07 14:02:28 --> Could not find the language line "recommended"
ERROR - 2025-12-07 14:28:32 --> Could not find the language line "recommended"
ERROR - 2025-12-07 14:39:44 --> Could not find the language line "recommended"
ERROR - 2025-12-07 14:41:35 --> Could not find the language line "recommended"
ERROR - 2025-12-07 14:54:56 --> Could not find the language line "recommended"
ERROR - 2025-12-07 15:04:31 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 15:04:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 15:04:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 15:38:08 --> Could not find the language line "recommended"
ERROR - 2025-12-07 15:50:30 --> Could not find the language line "recommended"
ERROR - 2025-12-07 15:54:34 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 15:54:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 15:54:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 16:15:55 --> Could not find the language line "recommended"
ERROR - 2025-12-07 16:16:57 --> Could not find the language line "recommended"
ERROR - 2025-12-07 16:41:00 --> Could not find the language line "recommended"
ERROR - 2025-12-07 16:52:54 --> Could not find the language line "recommended"
ERROR - 2025-12-07 17:19:09 --> Could not find the language line "recommended"
ERROR - 2025-12-07 17:25:45 --> Could not find the language line "recommended"
ERROR - 2025-12-07 17:40:45 --> Could not find the language line "recommended"
ERROR - 2025-12-07 18:09:57 --> Could not find the language line "recommended"
ERROR - 2025-12-07 18:22:40 --> Could not find the language line "recommended"
ERROR - 2025-12-07 18:48:14 --> Could not find the language line "recommended"
ERROR - 2025-12-07 19:01:26 --> Could not find the language line "recommended"
ERROR - 2025-12-07 19:12:30 --> Could not find the language line "email_us"
ERROR - 2025-12-07 19:17:31 --> Could not find the language line "recommended"
ERROR - 2025-12-07 19:43:19 --> Could not find the language line "recommended"
ERROR - 2025-12-07 19:55:42 --> Could not find the language line "recommended"
ERROR - 2025-12-07 20:07:21 --> Could not find the language line "recommended"
ERROR - 2025-12-07 20:31:04 --> Could not find the language line "recommended"
ERROR - 2025-12-07 20:53:16 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 20:53:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 20:53:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 20:53:40 --> Could not find the language line "recommended"
ERROR - 2025-12-07 21:23:24 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 21:23:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 21:23:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 21:23:31 --> Could not find the language line "recommended"
ERROR - 2025-12-07 21:41:24 --> Could not find the language line "recommended"
ERROR - 2025-12-07 22:15:31 --> Could not find the language line "recommended"
ERROR - 2025-12-07 22:32:26 --> Could not find the language line "recommended"
ERROR - 2025-12-07 22:48:43 --> Could not find the language line "recommended"
ERROR - 2025-12-07 23:21:02 --> Could not find the language line "recommended"
ERROR - 2025-12-07 23:24:10 --> Could not find the language line "check_availability"
ERROR - 2025-12-07 23:24:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 23:24:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-07 23:34:09 --> Could not find the language line "recommended"
ERROR - 2025-12-07 23:46:32 --> Could not find the language line "recommended"
ERROR - 2025-12-07 23:57:56 --> Could not find the language line "recommended"
