<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-02 00:08:49 --> Could not find the language line "recommended"
ERROR - 2025-11-02 00:16:49 --> Could not find the language line "recommended"
ERROR - 2025-11-02 00:45:07 --> Could not find the language line "recommended"
ERROR - 2025-11-02 01:16:26 --> Could not find the language line "recommended"
ERROR - 2025-11-02 01:47:31 --> Could not find the language line "recommended"
ERROR - 2025-11-02 02:23:12 --> Could not find the language line "recommended"
ERROR - 2025-11-02 02:54:59 --> Could not find the language line "recommended"
ERROR - 2025-11-02 03:26:56 --> Could not find the language line "recommended"
ERROR - 2025-11-02 03:36:09 --> Could not find the language line "recommended"
ERROR - 2025-11-02 03:57:11 --> Could not find the language line "recommended"
ERROR - 2025-11-02 04:08:55 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-02 04:08:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-02 04:08:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-02 04:08:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-02 04:08:56 --> Could not find the language line "recommended"
ERROR - 2025-11-02 04:09:53 --> Could not find the language line "recommended"
ERROR - 2025-11-02 04:17:45 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 04:17:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 04:17:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 04:33:59 --> Could not find the language line "recommended"
ERROR - 2025-11-02 05:05:21 --> Could not find the language line "recommended"
ERROR - 2025-11-02 05:35:10 --> Could not find the language line "recommended"
ERROR - 2025-11-02 06:04:21 --> Could not find the language line "recommended"
ERROR - 2025-11-02 06:40:34 --> Could not find the language line "recommended"
ERROR - 2025-11-02 07:09:50 --> Could not find the language line "recommended"
ERROR - 2025-11-02 07:38:22 --> Could not find the language line "recommended"
ERROR - 2025-11-02 08:07:19 --> Could not find the language line "recommended"
ERROR - 2025-11-02 08:41:44 --> Could not find the language line "recommended"
ERROR - 2025-11-02 09:02:23 --> Could not find the language line "recommended"
ERROR - 2025-11-02 09:10:34 --> Could not find the language line "recommended"
ERROR - 2025-11-02 09:14:25 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 09:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 09:14:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 09:35:00 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 09:35:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 09:35:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 09:38:42 --> Could not find the language line "recommended"
ERROR - 2025-11-02 09:46:05 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 09:46:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 09:46:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 10:06:38 --> Could not find the language line "recommended"
ERROR - 2025-11-02 10:45:50 --> Could not find the language line "recommended"
ERROR - 2025-11-02 11:16:25 --> Could not find the language line "recommended"
ERROR - 2025-11-02 11:46:07 --> Could not find the language line "recommended"
ERROR - 2025-11-02 12:41:53 --> Could not find the language line "recommended"
ERROR - 2025-11-02 12:56:59 --> Could not find the language line "recommended"
ERROR - 2025-11-02 13:27:13 --> Could not find the language line "recommended"
ERROR - 2025-11-02 13:51:34 --> Could not find the language line "recommended"
ERROR - 2025-11-02 13:55:27 --> Could not find the language line "recommended"
ERROR - 2025-11-02 14:11:52 --> Could not find the language line "recommended"
ERROR - 2025-11-02 14:32:07 --> Could not find the language line "recommended"
ERROR - 2025-11-02 15:03:43 --> Could not find the language line "recommended"
ERROR - 2025-11-02 15:32:16 --> Could not find the language line "recommended"
ERROR - 2025-11-02 15:34:31 --> Could not find the language line "recommended"
ERROR - 2025-11-02 16:07:52 --> Could not find the language line "recommended"
ERROR - 2025-11-02 16:42:45 --> Could not find the language line "recommended"
ERROR - 2025-11-02 17:13:43 --> Could not find the language line "recommended"
ERROR - 2025-11-02 17:43:53 --> Could not find the language line "recommended"
ERROR - 2025-11-02 17:48:34 --> Could not find the language line "recommended"
ERROR - 2025-11-02 18:20:56 --> Could not find the language line "recommended"
ERROR - 2025-11-02 18:36:15 --> Could not find the language line "recommended"
ERROR - 2025-11-02 18:54:09 --> Could not find the language line "recommended"
ERROR - 2025-11-02 19:05:51 --> Could not find the language line "recommended"
ERROR - 2025-11-02 19:24:10 --> Could not find the language line "recommended"
ERROR - 2025-11-02 19:53:59 --> Could not find the language line "recommended"
ERROR - 2025-11-02 20:31:33 --> Could not find the language line "recommended"
ERROR - 2025-11-02 20:51:27 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 20:51:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 20:51:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 21:02:16 --> Could not find the language line "recommended"
ERROR - 2025-11-02 21:13:21 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 21:13:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 21:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 21:32:10 --> Could not find the language line "recommended"
ERROR - 2025-11-02 21:51:17 --> Could not find the language line "recommended"
ERROR - 2025-11-02 21:52:03 --> Could not find the language line "recommended"
ERROR - 2025-11-02 22:01:18 --> Could not find the language line "recommended"
ERROR - 2025-11-02 22:01:57 --> Could not find the language line "recommended"
ERROR - 2025-11-02 22:39:30 --> Could not find the language line "recommended"
ERROR - 2025-11-02 23:10:05 --> Could not find the language line "recommended"
ERROR - 2025-11-02 23:15:00 --> Could not find the language line "check_availability"
ERROR - 2025-11-02 23:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 23:15:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-02 23:40:02 --> Could not find the language line "recommended"
ERROR - 2025-11-02 23:57:50 --> Could not find the language line "email_us"
