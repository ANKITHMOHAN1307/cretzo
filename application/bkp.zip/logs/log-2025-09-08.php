<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-08 00:23:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 00:23:46 --> Unable to connect to the database
ERROR - 2025-09-08 00:30:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 00:30:56 --> Unable to connect to the database
ERROR - 2025-09-08 01:12:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 01:12:54 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:58 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:58 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:58 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:59 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:59 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:59 --> Unable to connect to the database
ERROR - 2025-09-08 02:38:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:38:59 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:00 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:00 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:00 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:00 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:01 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:01 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:01 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:01 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:02 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:02 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:02 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:02 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:03 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:03 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:03 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:04 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:04 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:04 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:04 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:05 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:05 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:05 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:05 --> Unable to connect to the database
ERROR - 2025-09-08 02:39:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:39:06 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:45 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:45 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:56:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:56:46 --> Unable to connect to the database
ERROR - 2025-09-08 02:58:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 02:58:21 --> Unable to connect to the database
ERROR - 2025-09-08 03:10:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 03:10:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 03:10:57 --> Unable to connect to the database
ERROR - 2025-09-08 03:10:57 --> Unable to connect to the database
ERROR - 2025-09-08 03:10:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 03:10:58 --> Unable to connect to the database
ERROR - 2025-09-08 03:10:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 03:10:59 --> Unable to connect to the database
ERROR - 2025-09-08 04:34:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-08 04:34:54 --> Unable to connect to the database
ERROR - 2025-09-08 11:00:45 --> Could not find the language line "recommended"
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-08 11:02:52 --> Could not find the language line "check_availability"
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-08 11:02:52 --> Could not find the language line "check_availability"
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-08 11:02:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-08 18:14:54 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2409:40d0:1007:f0fd:e872:b27d:d862:ca5', '8130358306', 1757335494)
ERROR - 2025-09-08 18:15:36 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2409:40d0:1007:f0fd:e872:b27d:d862:ca5', '8130358306', 1757335536)
ERROR - 2025-09-08 18:16:32 --> Could not find the language line "login_heading"
ERROR - 2025-09-08 18:16:32 --> Could not find the language line "login_password_label"
ERROR - 2025-09-08 18:16:32 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2409:40d0:1007:f0fd:e872:b27d:d862:ca5', '8130358306', 1757335592)
ERROR - 2025-09-08 18:42:22 --> Could not find the language line "login_heading"
ERROR - 2025-09-08 18:42:22 --> Could not find the language line "login_password_label"
ERROR - 2025-09-08 18:42:22 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2409:40d0:10c2:b749:c0ce:6ea6:1a8e:9456', '8130358306', 1757337142)
ERROR - 2025-09-08 21:58:15 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:40 --> Could not find the language line "email_us"
ERROR - 2025-09-08 23:47:47 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:48 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:49 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:51 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:53 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:57 --> Could not find the language line "section"
ERROR - 2025-09-08 23:47:57 --> Could not find the language line "section"
ERROR - 2025-09-08 23:47:57 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:58 --> Could not find the language line "section"
ERROR - 2025-09-08 23:47:58 --> Could not find the language line "section"
ERROR - 2025-09-08 23:47:58 --> Could not find the language line "recommended"
ERROR - 2025-09-08 23:47:59 --> Could not find the language line "email_us"
