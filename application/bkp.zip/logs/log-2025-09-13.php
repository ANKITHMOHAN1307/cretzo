<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-13 01:15:11 --> Could not find the language line "recommended"
ERROR - 2025-09-13 03:35:41 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 03:35:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 03:35:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 04:41:03 --> Could not find the language line "recommended"
ERROR - 2025-09-13 04:50:53 --> Could not find the language line "recommended"
ERROR - 2025-09-13 05:57:32 --> Could not find the language line "recommended"
ERROR - 2025-09-13 08:47:58 --> Could not find the language line "recommended"
ERROR - 2025-09-13 09:08:02 --> Could not find the language line "recommended"
ERROR - 2025-09-13 09:31:01 --> Could not find the language line "recommended"
ERROR - 2025-09-13 09:35:16 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 09:35:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 09:35:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 11:09:32 --> Could not find the language line "recommended"
ERROR - 2025-09-13 12:15:29 --> Could not find the language line "recommended"
ERROR - 2025-09-13 12:18:34 --> Could not find the language line "recommended"
ERROR - 2025-09-13 13:13:07 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-13 13:13:07 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-13 13:13:07 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 13:13:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 13:13:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 13:53:16 --> Could not find the language line "recommended"
ERROR - 2025-09-13 14:51:20 --> Could not find the language line "recommended"
ERROR - 2025-09-13 14:51:23 --> Could not find the language line "recommended"
ERROR - 2025-09-13 14:54:51 --> Could not find the language line "recommended"
ERROR - 2025-09-13 16:15:51 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 16:15:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 16:15:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 17:43:08 --> Could not find the language line "recommended"
ERROR - 2025-09-13 18:04:34 --> Could not find the language line "recommended"
ERROR - 2025-09-13 18:34:31 --> Could not find the language line "recommended"
ERROR - 2025-09-13 19:07:55 --> Could not find the language line "recommended"
ERROR - 2025-09-13 19:15:11 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 19:15:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 19:15:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 21:24:32 --> Could not find the language line "recommended"
ERROR - 2025-09-13 22:36:14 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 22:36:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 22:36:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 22:40:41 --> Could not find the language line "section"
ERROR - 2025-09-13 22:40:41 --> Could not find the language line "section"
ERROR - 2025-09-13 22:40:41 --> Could not find the language line "recommended"
ERROR - 2025-09-13 22:41:00 --> Could not find the language line "recommended"
ERROR - 2025-09-13 22:41:43 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 22:41:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 22:41:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 22:42:53 --> Could not find the language line "check_availability"
ERROR - 2025-09-13 22:42:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-13 22:42:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
