<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-26 00:55:03 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 00:55:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 00:55:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 00:56:38 --> Could not find the language line "recommended"
ERROR - 2025-10-26 01:13:56 --> Could not find the language line "recommended"
ERROR - 2025-10-26 01:18:40 --> Could not find the language line "email_us"
ERROR - 2025-10-26 01:18:41 --> Could not find the language line "email_us"
ERROR - 2025-10-26 01:18:51 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-26 01:18:51 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-26 01:56:04 --> Could not find the language line "recommended"
ERROR - 2025-10-26 01:56:35 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 02:14:42 --> Could not find the language line "recommended"
ERROR - 2025-10-26 02:44:45 --> Could not find the language line "recommended"
ERROR - 2025-10-26 02:46:48 --> Could not find the language line "compare"
ERROR - 2025-10-26 02:57:58 --> Could not find the language line "recommended"
ERROR - 2025-10-26 03:01:59 --> Could not find the language line "recommended"
ERROR - 2025-10-26 03:06:48 --> Could not find the language line "recommended"
ERROR - 2025-10-26 03:18:36 --> Could not find the language line "recommended"
ERROR - 2025-10-26 03:43:37 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 03:43:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 03:43:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 04:29:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 04:29:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 04:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 05:27:28 --> Could not find the language line "recommended"
ERROR - 2025-10-26 06:05:23 --> Could not find the language line "recommended"
ERROR - 2025-10-26 06:40:37 --> Could not find the language line "recommended"
ERROR - 2025-10-26 06:54:17 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 08:14:22 --> Could not find the language line "recommended"
ERROR - 2025-10-26 08:57:09 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 08:57:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 08:57:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 08:58:48 --> Could not find the language line "recommended"
ERROR - 2025-10-26 09:27:38 --> Could not find the language line "recommended"
ERROR - 2025-10-26 10:19:03 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 10:19:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 10:19:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 10:58:56 --> Could not find the language line "section"
ERROR - 2025-10-26 10:58:56 --> Could not find the language line "section"
ERROR - 2025-10-26 10:58:56 --> Could not find the language line "recommended"
ERROR - 2025-10-26 10:59:17 --> Could not find the language line "section"
ERROR - 2025-10-26 10:59:17 --> Could not find the language line "section"
ERROR - 2025-10-26 10:59:17 --> Could not find the language line "recommended"
ERROR - 2025-10-26 11:56:47 --> Could not find the language line "recommended"
ERROR - 2025-10-26 12:26:52 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-26 12:26:52 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-26 12:26:52 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 12:26:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 12:26:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 12:43:36 --> Could not find the language line "recommended"
ERROR - 2025-10-26 13:00:29 --> Could not find the language line "recommended"
ERROR - 2025-10-26 13:09:37 --> Could not find the language line "recommended"
ERROR - 2025-10-26 13:18:12 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 13:18:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 13:18:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 13:33:55 --> Could not find the language line "recommended"
ERROR - 2025-10-26 16:39:55 --> Could not find the language line "recommended"
ERROR - 2025-10-26 17:02:04 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 17:02:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 17:02:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 17:11:22 --> Could not find the language line "recommended"
ERROR - 2025-10-26 17:24:49 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 17:24:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 17:24:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 18:44:32 --> Could not find the language line "recommended"
ERROR - 2025-10-26 20:44:07 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 20:44:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 20:44:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 20:49:48 --> Could not find the language line "login_heading"
ERROR - 2025-10-26 20:49:48 --> Could not find the language line "login_password_label"
ERROR - 2025-10-26 20:49:50 --> Could not find the language line "support_chat"
ERROR - 2025-10-26 20:49:50 --> Could not find the language line "label_close"
ERROR - 2025-10-26 20:49:50 --> Could not find the language line "label_search"
ERROR - 2025-10-26 20:49:50 --> Could not find the language line "label_search_result"
ERROR - 2025-10-26 21:00:11 --> Could not find the language line "recommended"
ERROR - 2025-10-26 21:21:18 --> Could not find the language line "recommended"
ERROR - 2025-10-26 21:21:25 --> Could not find the language line "check_availability"
ERROR - 2025-10-26 21:21:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 21:21:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-26 21:41:23 --> Could not find the language line "recommended"
ERROR - 2025-10-26 22:02:49 --> Could not find the language line "section"
ERROR - 2025-10-26 22:02:49 --> Could not find the language line "section"
ERROR - 2025-10-26 22:02:49 --> Could not find the language line "recommended"
ERROR - 2025-10-26 22:43:06 --> Could not find the language line "recommended"
ERROR - 2025-10-26 23:16:37 --> Could not find the language line "recommended"
