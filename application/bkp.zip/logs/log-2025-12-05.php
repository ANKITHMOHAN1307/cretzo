<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-05 00:14:47 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 00:14:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 00:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 00:17:03 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 00:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 00:17:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 00:51:02 --> Could not find the language line "recommended"
ERROR - 2025-12-05 02:06:27 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 02:06:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 02:06:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 02:09:42 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-05 02:09:42 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-05 02:09:42 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 02:09:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 02:09:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 02:43:37 --> Could not find the language line "recommended"
ERROR - 2025-12-05 03:21:32 --> Could not find the language line "recommended"
ERROR - 2025-12-05 03:59:25 --> Could not find the language line "recommended"
ERROR - 2025-12-05 04:36:27 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 04:36:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 04:36:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 04:49:12 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 04:49:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 04:49:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 05:20:41 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 05:20:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 05:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 06:01:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 06:01:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 06:01:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 06:38:24 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 06:38:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 06:38:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 07:49:24 --> Could not find the language line "recommended"
ERROR - 2025-12-05 08:21:03 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 08:21:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 08:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 08:24:20 --> Could not find the language line "recommended"
ERROR - 2025-12-05 08:52:35 --> Could not find the language line "recommended"
ERROR - 2025-12-05 09:37:26 --> Could not find the language line "recommended"
ERROR - 2025-12-05 10:31:19 --> Could not find the language line "section"
ERROR - 2025-12-05 10:31:19 --> Could not find the language line "section"
ERROR - 2025-12-05 10:31:19 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:02:12 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:02:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:33:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:33:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:33:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:38:51 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:38:52 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:38:53 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:38:55 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:38:56 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:38:59 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:38:59 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:01 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:03 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:04 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:06 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:39:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:09 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:10 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:12 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-05 11:39:12 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-05 11:39:13 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:15 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-05 11:39:15 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-05 11:39:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:39:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:18 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:19 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:20 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:23 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:39:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:24 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:26 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:28 --> Could not find the language line "email_us"
ERROR - 2025-12-05 11:39:29 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:31 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:32 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:34 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:35 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:37 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:38 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:40 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:41 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:43 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:44 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:46 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:39:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:39:48 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:49 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:50 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:52 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:53 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:55 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:56 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:58 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:39:59 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:01 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:03 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-05 11:40:03 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-05 11:40:03 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 11:40:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:40:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 11:40:05 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:06 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:08 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:10 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:10 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:12 --> Could not find the language line "recommended"
ERROR - 2025-12-05 11:40:15 --> Could not find the language line "recommended"
ERROR - 2025-12-05 12:09:38 --> Could not find the language line "recommended"
ERROR - 2025-12-05 12:23:24 --> Could not find the language line "recommended"
ERROR - 2025-12-05 12:47:44 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 12:47:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 12:47:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 12:50:36 --> Could not find the language line "section"
ERROR - 2025-12-05 12:50:36 --> Could not find the language line "section"
ERROR - 2025-12-05 12:50:36 --> Could not find the language line "recommended"
ERROR - 2025-12-05 13:01:45 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 13:01:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 13:01:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 13:06:54 --> Could not find the language line "recommended"
ERROR - 2025-12-05 14:57:12 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 14:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 14:57:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 16:04:48 --> Could not find the language line "recommended"
ERROR - 2025-12-05 16:58:36 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 16:58:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 16:58:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 17:23:08 --> Could not find the language line "recommended"
ERROR - 2025-12-05 18:34:18 --> Could not find the language line "recommended"
ERROR - 2025-12-05 19:49:32 --> Could not find the language line "recommended"
ERROR - 2025-12-05 20:22:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 20:22:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 20:22:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 20:27:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 20:27:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 20:27:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 21:05:02 --> Could not find the language line "recommended"
ERROR - 2025-12-05 21:23:51 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 21:23:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 21:23:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 21:48:19 --> Could not find the language line "compare"
ERROR - 2025-12-05 22:18:47 --> Could not find the language line "recommended"
ERROR - 2025-12-05 23:00:02 --> Could not find the language line "recommended"
ERROR - 2025-12-05 23:16:36 --> Could not find the language line "recommended"
ERROR - 2025-12-05 23:30:55 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 23:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 23:30:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 23:39:29 --> Could not find the language line "check_availability"
ERROR - 2025-12-05 23:39:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-05 23:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
