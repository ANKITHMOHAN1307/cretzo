<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-11 00:32:46 --> Could not find the language line "recommended"
ERROR - 2025-09-11 03:19:23 --> Could not find the language line "recommended"
ERROR - 2025-09-11 04:40:41 --> Could not find the language line "recommended"
ERROR - 2025-09-11 04:49:04 --> Could not find the language line "recommended"
ERROR - 2025-09-11 05:18:04 --> Could not find the language line "recommended"
ERROR - 2025-09-11 06:27:47 --> Could not find the language line "recommended"
ERROR - 2025-09-11 07:06:14 --> Could not find the language line "recommended"
ERROR - 2025-09-11 12:33:35 --> Could not find the language line "recommended"
ERROR - 2025-09-11 14:44:39 --> Could not find the language line "recommended"
ERROR - 2025-09-11 18:53:34 --> Could not find the language line "check_availability"
ERROR - 2025-09-11 18:53:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-11 18:53:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-11 19:16:03 --> Could not find the language line "recommended"
ERROR - 2025-09-11 19:40:11 --> Could not find the language line "recommended"
ERROR - 2025-09-11 20:01:03 --> Could not find the language line "email_us"
ERROR - 2025-09-11 20:19:40 --> Could not find the language line "recommended"
ERROR - 2025-09-11 22:31:09 --> Could not find the language line "email_us"
ERROR - 2025-09-11 22:31:11 --> Could not find the language line "recommended"
ERROR - 2025-09-11 23:06:13 --> Could not find the language line "section"
ERROR - 2025-09-11 23:06:13 --> Could not find the language line "section"
ERROR - 2025-09-11 23:06:13 --> Could not find the language line "recommended"
ERROR - 2025-09-11 23:55:33 --> Could not find the language line "recommended"
