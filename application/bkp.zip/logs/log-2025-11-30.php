<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-30 00:05:06 --> Could not find the language line "recommended"
ERROR - 2025-11-30 00:22:45 --> Could not find the language line "recommended"
ERROR - 2025-11-30 01:12:23 --> Could not find the language line "recommended"
ERROR - 2025-11-30 02:02:37 --> Could not find the language line "recommended"
ERROR - 2025-11-30 03:20:59 --> Could not find the language line "recommended"
ERROR - 2025-11-30 03:41:47 --> Could not find the language line "recommended"
ERROR - 2025-11-30 03:46:58 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 03:46:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 03:46:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 03:54:53 --> Could not find the language line "email_us"
ERROR - 2025-11-30 04:12:45 --> Could not find the language line "recommended"
ERROR - 2025-11-30 05:16:08 --> Could not find the language line "recommended"
ERROR - 2025-11-30 05:29:15 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 05:29:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 05:29:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 06:17:32 --> Could not find the language line "recommended"
ERROR - 2025-11-30 06:25:13 --> Could not find the language line "recommended"
ERROR - 2025-11-30 06:36:25 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 06:36:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 06:36:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 07:34:48 --> Could not find the language line "email_us"
ERROR - 2025-11-30 07:45:37 --> Could not find the language line "recommended"
ERROR - 2025-11-30 07:53:36 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 07:53:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 07:53:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 08:55:19 --> Could not find the language line "recommended"
ERROR - 2025-11-30 09:40:03 --> Could not find the language line "recommended"
ERROR - 2025-11-30 10:02:31 --> Could not find the language line "recommended"
ERROR - 2025-11-30 10:18:31 --> Could not find the language line "recommended"
ERROR - 2025-11-30 10:25:36 --> Could not find the language line "recommended"
ERROR - 2025-11-30 11:24:38 --> Could not find the language line "recommended"
ERROR - 2025-11-30 12:10:47 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 12:10:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 12:10:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 13:48:21 --> Could not find the language line "recommended"
ERROR - 2025-11-30 14:12:59 --> Could not find the language line "recommended"
ERROR - 2025-11-30 15:08:50 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 15:08:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 15:08:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 15:08:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 15:08:51 --> Could not find the language line "recommended"
ERROR - 2025-11-30 15:08:51 --> Could not find the language line "recommended"
ERROR - 2025-11-30 15:34:42 --> Could not find the language line "recommended"
ERROR - 2025-11-30 16:03:05 --> Could not find the language line "recommended"
ERROR - 2025-11-30 17:14:53 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 17:14:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 17:14:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 17:17:15 --> Could not find the language line "recommended"
ERROR - 2025-11-30 17:23:56 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 17:23:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 17:23:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 18:00:26 --> Could not find the language line "recommended"
ERROR - 2025-11-30 18:10:07 --> Could not find the language line "email_us"
ERROR - 2025-11-30 18:22:33 --> Could not find the language line "recommended"
ERROR - 2025-11-30 19:16:03 --> Could not find the language line "recommended"
ERROR - 2025-11-30 20:52:32 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 20:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 20:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 20:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-30 20:52:33 --> Could not find the language line "recommended"
ERROR - 2025-11-30 21:04:42 --> Could not find the language line "recommended"
ERROR - 2025-11-30 21:04:50 --> Could not find the language line "recommended"
ERROR - 2025-11-30 21:31:32 --> Could not find the language line "recommended"
ERROR - 2025-11-30 21:41:31 --> Could not find the language line "check_availability"
ERROR - 2025-11-30 21:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 21:41:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-30 21:59:12 --> Could not find the language line "recommended"
ERROR - 2025-11-30 23:02:38 --> Could not find the language line "recommended"
ERROR - 2025-11-30 23:31:27 --> Could not find the language line "section"
ERROR - 2025-11-30 23:31:27 --> Could not find the language line "section"
ERROR - 2025-11-30 23:31:27 --> Could not find the language line "recommended"
