<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-27 00:04:28 --> Could not find the language line "recommended"
ERROR - 2025-10-27 00:43:05 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 00:43:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 00:43:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 01:00:39 --> Could not find the language line "recommended"
ERROR - 2025-10-27 01:02:18 --> Could not find the language line "recommended"
ERROR - 2025-10-27 01:13:19 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 01:13:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 01:13:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 01:19:12 --> Could not find the language line "recommended"
ERROR - 2025-10-27 01:34:40 --> Could not find the language line "recommended"
ERROR - 2025-10-27 02:13:44 --> Could not find the language line "recommended"
ERROR - 2025-10-27 02:31:42 --> Could not find the language line "recommended"
ERROR - 2025-10-27 02:56:16 --> Could not find the language line "recommended"
ERROR - 2025-10-27 02:56:36 --> Could not find the language line "recommended"
ERROR - 2025-10-27 03:04:31 --> Could not find the language line "recommended"
ERROR - 2025-10-27 03:09:17 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 03:09:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 03:09:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 03:29:12 --> Could not find the language line "recommended"
ERROR - 2025-10-27 03:44:07 --> Could not find the language line "email_us"
ERROR - 2025-10-27 03:51:22 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 03:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 03:51:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 04:10:28 --> Could not find the language line "recommended"
ERROR - 2025-10-27 04:23:03 --> Could not find the language line "email_us"
ERROR - 2025-10-27 04:23:05 --> Could not find the language line "recommended"
ERROR - 2025-10-27 04:29:02 --> Could not find the language line "recommended"
ERROR - 2025-10-27 04:46:14 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 04:46:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 04:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 04:56:11 --> Could not find the language line "recommended"
ERROR - 2025-10-27 05:02:55 --> Could not find the language line "email_us"
ERROR - 2025-10-27 05:11:45 --> Could not find the language line "recommended"
ERROR - 2025-10-27 05:18:25 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-27 05:18:25 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-27 05:18:25 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 05:18:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 05:18:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 05:50:47 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 05:50:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 05:50:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 06:05:44 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 06:05:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 06:05:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 06:13:17 --> Could not find the language line "recommended"
ERROR - 2025-10-27 06:54:10 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 06:54:56 --> Could not find the language line "recommended"
ERROR - 2025-10-27 06:55:01 --> Could not find the language line "recommended"
ERROR - 2025-10-27 06:56:39 --> Could not find the language line "recommended"
ERROR - 2025-10-27 07:01:59 --> Could not find the language line "recommended"
ERROR - 2025-10-27 07:11:55 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 07:11:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 07:11:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 07:55:08 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 08:12:43 --> Could not find the language line "recommended"
ERROR - 2025-10-27 08:25:44 --> Could not find the language line "recommended"
ERROR - 2025-10-27 08:31:51 --> Could not find the language line "email_us"
ERROR - 2025-10-27 08:45:45 --> Could not find the language line "recommended"
ERROR - 2025-10-27 08:45:55 --> Could not find the language line "recommended"
ERROR - 2025-10-27 08:46:29 --> Could not find the language line "recommended"
ERROR - 2025-10-27 08:49:53 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-27 08:49:53 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-27 08:49:53 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 08:49:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 08:49:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 08:56:48 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 08:56:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 08:56:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 08:58:31 --> Could not find the language line "recommended"
ERROR - 2025-10-27 09:25:21 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 09:25:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 09:25:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 09:42:15 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 09:42:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 09:42:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 09:59:43 --> Could not find the language line "recommended"
ERROR - 2025-10-27 10:13:41 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 10:13:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 10:13:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 10:22:22 --> Could not find the language line "recommended"
ERROR - 2025-10-27 10:40:13 --> Could not find the language line "email_us"
ERROR - 2025-10-27 10:57:53 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 10:57:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 10:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 11:46:20 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 12:02:16 --> Could not find the language line "recommended"
ERROR - 2025-10-27 12:08:15 --> Could not find the language line "recommended"
ERROR - 2025-10-27 12:08:49 --> Could not find the language line "recommended"
ERROR - 2025-10-27 12:27:17 --> Could not find the language line "recommended"
ERROR - 2025-10-27 12:44:23 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 12:44:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 12:44:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:01:50 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 13:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:01:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:18:31 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 13:18:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:18:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:19:09 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 13:19:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:19:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:31:04 --> Could not find the language line "recommended"
ERROR - 2025-10-27 13:34:29 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 13:34:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:34:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 13:50:23 --> Could not find the language line "section"
ERROR - 2025-10-27 13:50:23 --> Could not find the language line "section"
ERROR - 2025-10-27 13:50:23 --> Could not find the language line "recommended"
ERROR - 2025-10-27 14:11:10 --> Could not find the language line "recommended"
ERROR - 2025-10-27 14:23:22 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 14:23:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 14:23:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 15:08:38 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 15:08:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 15:08:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 15:26:07 --> Could not find the language line "section"
ERROR - 2025-10-27 15:26:07 --> Could not find the language line "section"
ERROR - 2025-10-27 15:26:07 --> Could not find the language line "recommended"
ERROR - 2025-10-27 15:42:55 --> Could not find the language line "recommended"
ERROR - 2025-10-27 16:00:13 --> Could not find the language line "recommended"
ERROR - 2025-10-27 16:21:44 --> Could not find the language line "recommended"
ERROR - 2025-10-27 17:05:05 --> Could not find the language line "recommended"
ERROR - 2025-10-27 17:18:33 --> Could not find the language line "recommended"
ERROR - 2025-10-27 17:23:57 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 17:23:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 17:23:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 17:42:23 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 17:42:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 17:42:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 18:00:49 --> Could not find the language line "section"
ERROR - 2025-10-27 18:00:49 --> Could not find the language line "section"
ERROR - 2025-10-27 18:00:49 --> Could not find the language line "recommended"
ERROR - 2025-10-27 18:50:44 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 19:15:02 --> Could not find the language line "recommended"
ERROR - 2025-10-27 19:37:28 --> Could not find the language line "recommended"
ERROR - 2025-10-27 19:59:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 19:59:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 19:59:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 20:18:24 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 20:18:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 20:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 21:03:53 --> Could not find the language line "recommended"
ERROR - 2025-10-27 21:14:56 --> Could not find the language line "recommended"
ERROR - 2025-10-27 21:30:20 --> Could not find the language line "recommended"
ERROR - 2025-10-27 21:44:38 --> Could not find the language line "recommended"
ERROR - 2025-10-27 22:38:47 --> Could not find the language line "recommended"
ERROR - 2025-10-27 22:46:38 --> Could not find the language line "recommended"
ERROR - 2025-10-27 22:59:37 --> Could not find the language line "recommended"
ERROR - 2025-10-27 23:12:40 --> Could not find the language line "recommended"
ERROR - 2025-10-27 23:26:03 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-27 23:26:03 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-27 23:38:51 --> Could not find the language line "check_availability"
ERROR - 2025-10-27 23:38:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 23:38:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-27 23:51:33 --> Could not find the language line "compare"
ERROR - 2025-10-27 23:54:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-10-27 23:54:58 --> Could not find the language line "recommended"
