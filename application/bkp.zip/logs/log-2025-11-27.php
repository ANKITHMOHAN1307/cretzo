<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-27 02:13:27 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 02:13:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 02:13:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 02:49:36 --> Could not find the language line "recommended"
ERROR - 2025-11-27 03:29:29 --> Could not find the language line "recommended"
ERROR - 2025-11-27 10:27:03 --> Could not find the language line "section"
ERROR - 2025-11-27 10:27:03 --> Could not find the language line "tags"
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $per_page /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $total_rows /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 232
ERROR - 2025-11-27 10:27:03 --> Could not find the language line "recommended"
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $page_no /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-11-27 10:27:03 --> Severity: Warning --> Undefined variable $num_pages /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-listing.php 345
ERROR - 2025-11-27 10:43:45 --> Could not find the language line "email_us"
ERROR - 2025-11-27 11:18:21 --> Could not find the language line "section"
ERROR - 2025-11-27 11:18:21 --> Could not find the language line "section"
ERROR - 2025-11-27 11:18:21 --> Could not find the language line "recommended"
ERROR - 2025-11-27 13:30:23 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 13:30:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 13:30:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 13:53:07 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 13:53:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 13:53:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 14:46:19 --> Could not find the language line "recommended"
ERROR - 2025-11-27 15:28:21 --> Could not find the language line "recommended"
ERROR - 2025-11-27 16:05:02 --> Could not find the language line "email_us"
ERROR - 2025-11-27 17:03:10 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 17:03:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 17:03:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 17:21:46 --> Could not find the language line "email_us"
ERROR - 2025-11-27 18:21:04 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 18:21:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 18:21:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 18:48:22 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 18:48:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 18:48:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 18:55:15 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 18:55:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 18:55:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 19:15:55 --> Could not find the language line "recommended"
ERROR - 2025-11-27 20:26:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 20:26:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 20:26:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 20:27:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-27 20:27:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 20:27:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-27 20:47:49 --> Could not find the language line "recommended"
ERROR - 2025-11-27 21:23:52 --> Could not find the language line "recommended"
ERROR - 2025-11-27 21:56:29 --> Could not find the language line "recommended"
ERROR - 2025-11-27 22:21:47 --> Could not find the language line "recommended"
ERROR - 2025-11-27 22:35:12 --> Could not find the language line "recommended"
ERROR - 2025-11-27 22:41:23 --> Could not find the language line "login_heading"
ERROR - 2025-11-27 22:41:23 --> Could not find the language line "login_password_label"
ERROR - 2025-11-27 23:02:04 --> Could not find the language line "recommended"
ERROR - 2025-11-27 23:29:38 --> Could not find the language line "recommended"
ERROR - 2025-11-27 23:31:14 --> Could not find the language line "recommended"
ERROR - 2025-11-27 23:44:21 --> Could not find the language line "recommended"
ERROR - 2025-11-27 23:59:14 --> Could not find the language line "recommended"
