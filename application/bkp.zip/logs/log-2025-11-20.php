<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-20 00:31:26 --> Could not find the language line "recommended"
ERROR - 2025-11-20 00:43:32 --> Could not find the language line "recommended"
ERROR - 2025-11-20 01:09:49 --> Could not find the language line "recommended"
ERROR - 2025-11-20 01:53:35 --> Could not find the language line "recommended"
ERROR - 2025-11-20 01:53:38 --> Could not find the language line "return_policy"
ERROR - 2025-11-20 01:53:38 --> Could not find the language line "return_policy"
ERROR - 2025-11-20 01:53:43 --> Could not find the language line "compare"
ERROR - 2025-11-20 01:55:45 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 01:55:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 01:55:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 01:56:39 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 01:56:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 01:56:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 01:57:46 --> Could not find the language line "recommended"
ERROR - 2025-11-20 01:57:47 --> Could not find the language line "return_policy"
ERROR - 2025-11-20 01:57:47 --> Could not find the language line "return_policy"
ERROR - 2025-11-20 01:59:47 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 01:59:47 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 02:01:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:01:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:01:49 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 02:01:49 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 02:02:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:04:30 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:04:46 --> Could not find the language line "compare"
ERROR - 2025-11-20 02:05:14 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:05:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:05:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:07:18 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-20 02:07:18 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-20 02:07:18 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:07:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:08:18 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-20 02:08:18 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-20 02:08:18 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:08:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:08:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:08:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:08:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:08:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:08:39 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:08:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:08:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:09:47 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:09:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:09:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:11:42 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:11:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:11:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:11:44 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:11:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:11:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:14:36 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:16:08 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:17:13 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:17:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:17:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:17:31 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:17:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:17:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:17:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:17:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:18:15 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:18:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:18:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:18:26 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:18:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:18:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:19:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:19:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:19:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:20:21 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:20:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:20:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:21:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:21:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:21:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:21:24 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:21:47 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:22:15 --> Could not find the language line "section"
ERROR - 2025-11-20 02:22:15 --> Could not find the language line "section"
ERROR - 2025-11-20 02:22:15 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:23:36 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:23:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:23:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:25:16 --> Could not find the language line "section"
ERROR - 2025-11-20 02:25:16 --> Could not find the language line "section"
ERROR - 2025-11-20 02:25:16 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:26:09 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:28:00 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:28:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:28:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:29:25 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:31:14 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:36:10 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:36:38 --> Could not find the language line "section"
ERROR - 2025-11-20 02:36:38 --> Could not find the language line "section"
ERROR - 2025-11-20 02:36:38 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:39:37 --> Could not find the language line "section"
ERROR - 2025-11-20 02:39:37 --> Could not find the language line "section"
ERROR - 2025-11-20 02:39:37 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:39:49 --> Could not find the language line "section"
ERROR - 2025-11-20 02:39:49 --> Could not find the language line "section"
ERROR - 2025-11-20 02:39:49 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:41:26 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:41:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:41:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:42:36 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 02:42:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:42:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 02:44:20 --> Could not find the language line "section"
ERROR - 2025-11-20 02:44:20 --> Could not find the language line "section"
ERROR - 2025-11-20 02:44:20 --> Could not find the language line "recommended"
ERROR - 2025-11-20 02:44:47 --> Could not find the language line "section"
ERROR - 2025-11-20 02:44:47 --> Could not find the language line "section"
ERROR - 2025-11-20 02:44:47 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:01:09 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:01:16 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:02:08 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:02:23 --> Could not find the language line "email_us"
ERROR - 2025-11-20 03:02:30 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:02:35 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:04:37 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:05:40 --> Could not find the language line "email_us"
ERROR - 2025-11-20 03:05:42 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:06:37 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:06:40 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:07:30 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:08:16 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:11:25 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:11:31 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:31:05 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-20 03:31:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-20 03:31:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-20 03:31:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-20 03:52:51 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:52:53 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:53:08 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:53:11 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:53:13 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:53:17 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:53:24 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:54:08 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:55:03 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:55:35 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:56:06 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:56:55 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:57:16 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:57:36 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:58:11 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:58:53 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:59:06 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:59:28 --> Could not find the language line "recommended"
ERROR - 2025-11-20 03:59:38 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:00:15 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:01:21 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:02:20 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:03:12 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:03:58 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:04:37 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:05:16 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:05:49 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:06:20 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:06:48 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:07:34 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:07:55 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:08:13 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:08:29 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:08:44 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:08:57 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:09:08 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:09:19 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:09:28 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:09:37 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:12:17 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:13:13 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:14:05 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:14:51 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:15:34 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:16:11 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:16:43 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:17:12 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:17:38 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:18:02 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:18:23 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:18:43 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:19:01 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:19:32 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:19:46 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:19:59 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:20:31 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:20:42 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:22:53 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:23:29 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:24:24 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:25:17 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:26:05 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:27:22 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:27:57 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:30:19 --> Could not find the language line "email_us"
ERROR - 2025-11-20 04:32:03 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:34:24 --> Could not find the language line "recommended"
ERROR - 2025-11-20 04:55:20 --> Could not find the language line "recommended"
ERROR - 2025-11-20 05:16:37 --> Could not find the language line "recommended"
ERROR - 2025-11-20 05:38:36 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 05:38:36 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 06:21:30 --> Could not find the language line "recommended"
ERROR - 2025-11-20 06:47:57 --> Could not find the language line "compare"
ERROR - 2025-11-20 06:52:16 --> Could not find the language line "email_us"
ERROR - 2025-11-20 07:16:31 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 07:16:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 07:16:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 07:34:40 --> Could not find the language line "recommended"
ERROR - 2025-11-20 08:00:15 --> Could not find the language line "return_policy"
ERROR - 2025-11-20 08:00:15 --> Could not find the language line "return_policy"
ERROR - 2025-11-20 08:31:56 --> Could not find the language line "recommended"
ERROR - 2025-11-20 08:42:19 --> Could not find the language line "recommended"
ERROR - 2025-11-20 09:40:10 --> Could not find the language line "section"
ERROR - 2025-11-20 09:40:10 --> Could not find the language line "section"
ERROR - 2025-11-20 09:40:10 --> Could not find the language line "recommended"
ERROR - 2025-11-20 09:41:05 --> Could not find the language line "recommended"
ERROR - 2025-11-20 10:47:29 --> Could not find the language line "recommended"
ERROR - 2025-11-20 11:10:51 --> Could not find the language line "recommended"
ERROR - 2025-11-20 11:14:28 --> Could not find the language line "recommended"
ERROR - 2025-11-20 11:22:08 --> Could not find the language line "recommended"
ERROR - 2025-11-20 11:32:48 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 11:32:48 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-20 11:33:34 --> Could not find the language line "recommended"
ERROR - 2025-11-20 11:36:11 --> Could not find the language line "section"
ERROR - 2025-11-20 11:36:11 --> Could not find the language line "section"
ERROR - 2025-11-20 11:36:12 --> Could not find the language line "recommended"
ERROR - 2025-11-20 11:43:24 --> Could not find the language line "recommended"
ERROR - 2025-11-20 12:01:12 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 12:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 12:01:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 12:08:27 --> Could not find the language line "recommended"
ERROR - 2025-11-20 12:17:48 --> Could not find the language line "recommended"
ERROR - 2025-11-20 12:22:31 --> Could not find the language line "recommended"
ERROR - 2025-11-20 12:43:16 --> Could not find the language line "recommended"
ERROR - 2025-11-20 13:02:44 --> Could not find the language line "recommended"
ERROR - 2025-11-20 13:23:45 --> Could not find the language line "recommended"
ERROR - 2025-11-20 13:25:40 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 13:25:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 13:25:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 13:43:54 --> Could not find the language line "recommended"
ERROR - 2025-11-20 14:04:21 --> Could not find the language line "recommended"
ERROR - 2025-11-20 15:00:48 --> Could not find the language line "recommended"
ERROR - 2025-11-20 15:32:19 --> Could not find the language line "recommended"
ERROR - 2025-11-20 16:02:14 --> Could not find the language line "recommended"
ERROR - 2025-11-20 16:31:51 --> Could not find the language line "recommended"
ERROR - 2025-11-20 17:15:21 --> Could not find the language line "recommended"
ERROR - 2025-11-20 17:50:23 --> Could not find the language line "recommended"
ERROR - 2025-11-20 17:58:50 --> Could not find the language line "recommended"
ERROR - 2025-11-20 18:18:05 --> Could not find the language line "recommended"
ERROR - 2025-11-20 18:44:07 --> Could not find the language line "recommended"
ERROR - 2025-11-20 19:11:18 --> Could not find the language line "recommended"
ERROR - 2025-11-20 19:57:51 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 19:57:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 19:57:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 20:01:24 --> Could not find the language line "email_us"
ERROR - 2025-11-20 20:26:12 --> Could not find the language line "recommended"
ERROR - 2025-11-20 20:39:40 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 20:39:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 20:39:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 20:55:14 --> Could not find the language line "recommended"
ERROR - 2025-11-20 21:38:25 --> Could not find the language line "recommended"
ERROR - 2025-11-20 21:40:05 --> Could not find the language line "recommended"
ERROR - 2025-11-20 22:01:59 --> Could not find the language line "recommended"
ERROR - 2025-11-20 22:24:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-20 22:24:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 22:24:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-20 22:32:54 --> Could not find the language line "recommended"
ERROR - 2025-11-20 22:57:43 --> Could not find the language line "recommended"
ERROR - 2025-11-20 23:38:47 --> Could not find the language line "recommended"
ERROR - 2025-11-20 23:43:03 --> Could not find the language line "recommended"
ERROR - 2025-11-20 23:58:38 --> Could not find the language line "recommended"
