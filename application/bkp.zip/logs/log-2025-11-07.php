<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-07 00:03:35 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:03:38 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:03:44 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:03:46 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:07:38 --> Could not find the language line "email_us"
ERROR - 2025-11-07 00:07:40 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:07:42 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:07:44 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:07:46 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:16:01 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:15 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:17 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:23 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:25 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:28 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:31 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:34 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:20:48 --> Could not find the language line "recommended"
ERROR - 2025-11-07 00:46:00 --> Could not find the language line "recommended"
ERROR - 2025-11-07 01:05:38 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 01:05:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 01:05:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 01:08:57 --> Could not find the language line "recommended"
ERROR - 2025-11-07 01:30:54 --> Could not find the language line "recommended"
ERROR - 2025-11-07 01:53:02 --> Could not find the language line "recommended"
ERROR - 2025-11-07 02:15:18 --> Could not find the language line "recommended"
ERROR - 2025-11-07 02:41:57 --> Could not find the language line "recommended"
ERROR - 2025-11-07 02:47:37 --> Could not find the language line "recommended"
ERROR - 2025-11-07 03:12:09 --> Could not find the language line "recommended"
ERROR - 2025-11-07 03:35:30 --> Could not find the language line "recommended"
ERROR - 2025-11-07 03:59:03 --> Could not find the language line "email_us"
ERROR - 2025-11-07 04:29:12 --> Could not find the language line "recommended"
ERROR - 2025-11-07 04:54:25 --> Could not find the language line "recommended"
ERROR - 2025-11-07 05:16:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 05:16:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 05:16:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 05:16:41 --> Could not find the language line "recommended"
ERROR - 2025-11-07 05:17:22 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 05:17:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 05:17:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 05:40:10 --> Could not find the language line "recommended"
ERROR - 2025-11-07 05:49:07 --> Could not find the language line "recommended"
ERROR - 2025-11-07 06:02:04 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 06:02:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 06:02:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 06:02:46 --> Could not find the language line "recommended"
ERROR - 2025-11-07 06:05:21 --> Could not find the language line "recommended"
ERROR - 2025-11-07 06:30:00 --> Could not find the language line "recommended"
ERROR - 2025-11-07 06:44:55 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 06:44:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 06:44:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 06:57:08 --> Could not find the language line "recommended"
ERROR - 2025-11-07 07:21:56 --> Could not find the language line "recommended"
ERROR - 2025-11-07 07:46:15 --> Could not find the language line "recommended"
ERROR - 2025-11-07 07:51:37 --> Could not find the language line "recommended"
ERROR - 2025-11-07 07:54:29 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 07:54:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 07:54:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 08:10:51 --> Could not find the language line "recommended"
ERROR - 2025-11-07 08:41:10 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:01:32 --> Could not find the language line "login_heading"
ERROR - 2025-11-07 09:01:32 --> Could not find the language line "login_password_label"
ERROR - 2025-11-07 09:01:37 --> Could not find the language line "login_heading"
ERROR - 2025-11-07 09:01:37 --> Could not find the language line "login_password_label"
ERROR - 2025-11-07 09:01:42 --> Could not find the language line "login_heading"
ERROR - 2025-11-07 09:01:42 --> Could not find the language line "login_password_label"
ERROR - 2025-11-07 09:02:20 --> Could not find the language line "email_us"
ERROR - 2025-11-07 09:03:09 --> Could not find the language line "section"
ERROR - 2025-11-07 09:03:09 --> Could not find the language line "section"
ERROR - 2025-11-07 09:03:09 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:03:53 --> Could not find the language line "email_us"
ERROR - 2025-11-07 09:04:34 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:04:50 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 09:04:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 09:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 09:05:08 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:05:21 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:05:24 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:05:41 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 09:05:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 09:05:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 09:27:26 --> Could not find the language line "recommended"
ERROR - 2025-11-07 09:50:07 --> Could not find the language line "email_us"
ERROR - 2025-11-07 10:12:20 --> Could not find the language line "recommended"
ERROR - 2025-11-07 10:23:12 --> Could not find the language line "recommended"
ERROR - 2025-11-07 10:42:31 --> Could not find the language line "recommended"
ERROR - 2025-11-07 11:06:01 --> Could not find the language line "recommended"
ERROR - 2025-11-07 11:26:36 --> Could not find the language line "recommended"
ERROR - 2025-11-07 11:29:35 --> Could not find the language line "email_us"
ERROR - 2025-11-07 11:29:39 --> Could not find the language line "recommended"
ERROR - 2025-11-07 11:33:20 --> Could not find the language line "recommended"
ERROR - 2025-11-07 11:52:22 --> Could not find the language line "recommended"
ERROR - 2025-11-07 12:18:29 --> Could not find the language line "recommended"
ERROR - 2025-11-07 12:46:06 --> Could not find the language line "recommended"
ERROR - 2025-11-07 13:09:24 --> Could not find the language line "recommended"
ERROR - 2025-11-07 13:32:07 --> Could not find the language line "email_us"
ERROR - 2025-11-07 13:54:20 --> Could not find the language line "recommended"
ERROR - 2025-11-07 14:25:05 --> Could not find the language line "recommended"
ERROR - 2025-11-07 14:38:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 14:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 14:38:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 14:50:46 --> Could not find the language line "recommended"
ERROR - 2025-11-07 15:14:07 --> Could not find the language line "recommended"
ERROR - 2025-11-07 15:36:00 --> Could not find the language line "recommended"
ERROR - 2025-11-07 15:57:30 --> Could not find the language line "recommended"
ERROR - 2025-11-07 16:26:17 --> Could not find the language line "recommended"
ERROR - 2025-11-07 16:51:39 --> Could not find the language line "recommended"
ERROR - 2025-11-07 17:10:08 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 17:10:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 17:10:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 17:13:57 --> Could not find the language line "email_us"
ERROR - 2025-11-07 17:36:03 --> Could not find the language line "recommended"
ERROR - 2025-11-07 17:58:08 --> Could not find the language line "recommended"
ERROR - 2025-11-07 18:23:34 --> Could not find the language line "recommended"
ERROR - 2025-11-07 18:52:20 --> Could not find the language line "recommended"
ERROR - 2025-11-07 19:01:55 --> Could not find the language line "section"
ERROR - 2025-11-07 19:01:55 --> Could not find the language line "section"
ERROR - 2025-11-07 19:01:55 --> Could not find the language line "recommended"
ERROR - 2025-11-07 19:02:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 19:02:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 19:02:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 19:16:34 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 19:16:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 19:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 19:17:00 --> Could not find the language line "recommended"
ERROR - 2025-11-07 19:17:55 --> Could not find the language line "recommended"
ERROR - 2025-11-07 19:40:12 --> Could not find the language line "recommended"
ERROR - 2025-11-07 20:02:39 --> Could not find the language line "recommended"
ERROR - 2025-11-07 20:32:21 --> Could not find the language line "recommended"
ERROR - 2025-11-07 20:57:31 --> Could not find the language line "recommended"
ERROR - 2025-11-07 21:19:59 --> Could not find the language line "email_us"
ERROR - 2025-11-07 21:43:23 --> Could not find the language line "recommended"
ERROR - 2025-11-07 21:56:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 21:56:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 21:56:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:07:14 --> Could not find the language line "recommended"
ERROR - 2025-11-07 22:27:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 22:27:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:27:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:27:20 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 22:27:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:27:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:27:21 --> Could not find the language line "check_availability"
ERROR - 2025-11-07 22:27:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:27:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-07 22:43:31 --> Could not find the language line "recommended"
ERROR - 2025-11-07 23:12:14 --> Could not find the language line "recommended"
ERROR - 2025-11-07 23:12:31 --> Could not find the language line "recommended"
ERROR - 2025-11-07 23:25:40 --> Could not find the language line "recommended"
ERROR - 2025-11-07 23:40:06 --> Could not find the language line "recommended"
