<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-08 00:07:34 --> Could not find the language line "recommended"
ERROR - 2025-11-08 00:43:02 --> Could not find the language line "recommended"
ERROR - 2025-11-08 00:47:25 --> Could not find the language line "recommended"
ERROR - 2025-11-08 01:14:24 --> Could not find the language line "recommended"
ERROR - 2025-11-08 01:30:23 --> Could not find the language line "recommended"
ERROR - 2025-11-08 01:35:41 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 01:35:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 01:35:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 01:47:57 --> Could not find the language line "recommended"
ERROR - 2025-11-08 02:09:06 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 02:09:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 02:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 02:28:31 --> Could not find the language line "recommended"
ERROR - 2025-11-08 02:53:31 --> Could not find the language line "recommended"
ERROR - 2025-11-08 03:08:47 --> Could not find the language line "recommended"
ERROR - 2025-11-08 04:25:07 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 04:25:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 04:25:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 04:43:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 04:43:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 04:43:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 05:17:42 --> Could not find the language line "email_us"
ERROR - 2025-11-08 05:17:44 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:17:46 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:17:50 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:17:52 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:17:59 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:20:58 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:22:05 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:23:08 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:25:02 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:25:57 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:37:05 --> Could not find the language line "recommended"
ERROR - 2025-11-08 05:38:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 05:38:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 05:38:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 05:54:04 --> Could not find the language line "recommended"
ERROR - 2025-11-08 06:01:25 --> Could not find the language line "recommended"
ERROR - 2025-11-08 06:01:40 --> Could not find the language line "recommended"
ERROR - 2025-11-08 07:12:24 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 07:12:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 07:12:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 07:16:05 --> Could not find the language line "recommended"
ERROR - 2025-11-08 07:26:21 --> Could not find the language line "recommended"
ERROR - 2025-11-08 07:47:14 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 07:47:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 07:47:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 08:04:56 --> Could not find the language line "recommended"
ERROR - 2025-11-08 09:41:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 09:41:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 09:41:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 10:01:30 --> Could not find the language line "recommended"
ERROR - 2025-11-08 10:32:32 --> Could not find the language line "recommended"
ERROR - 2025-11-08 11:23:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 11:23:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 11:23:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 13:01:14 --> Could not find the language line "recommended"
ERROR - 2025-11-08 15:20:52 --> Could not find the language line "recommended"
ERROR - 2025-11-08 16:48:00 --> Could not find the language line "recommended"
ERROR - 2025-11-08 16:58:03 --> Could not find the language line "recommended"
ERROR - 2025-11-08 17:19:24 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 17:19:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 17:19:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 17:35:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 17:35:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 17:35:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 17:42:10 --> Could not find the language line "recommended"
ERROR - 2025-11-08 18:23:20 --> Could not find the language line "recommended"
ERROR - 2025-11-08 19:54:57 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 19:54:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 19:54:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 20:02:54 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 20:02:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 20:02:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 20:03:59 --> Could not find the language line "recommended"
ERROR - 2025-11-08 20:51:11 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 20:51:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 20:51:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 21:40:59 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-08 21:40:59 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-08 21:40:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 21:40:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 21:40:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 21:59:46 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 21:59:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 21:59:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:05:16 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 22:05:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:05:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:11:06 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 22:11:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:11:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:25:15 --> Could not find the language line "check_availability"
ERROR - 2025-11-08 22:25:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:25:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-08 22:30:44 --> Could not find the language line "recommended"
