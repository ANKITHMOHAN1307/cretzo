<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-18 00:24:53 --> Could not find the language line "recommended"
ERROR - 2025-09-18 02:30:26 --> Could not find the language line "recommended"
ERROR - 2025-09-18 03:35:45 --> Could not find the language line "recommended"
ERROR - 2025-09-18 04:31:24 --> Could not find the language line "recommended"
ERROR - 2025-09-18 08:25:57 --> Could not find the language line "recommended"
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 10:15:10 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 10:15:10 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 10:15:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 10:46:34 --> Could not find the language line "recommended"
ERROR - 2025-09-18 11:51:17 --> Could not find the language line "email_us"
ERROR - 2025-09-18 12:08:43 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 12:08:43 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 12:08:43 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 12:08:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 12:08:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 13:39:41 --> Could not find the language line "recommended"
ERROR - 2025-09-18 15:07:07 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 15:07:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 15:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 15:07:43 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 15:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 15:07:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 15:09:38 --> Could not find the language line "recommended"
ERROR - 2025-09-18 15:09:42 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 15:09:42 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-18 15:09:42 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 15:09:42 --> Could not find the language line "product_is"
ERROR - 2025-09-18 15:09:42 --> Could not find the language line "delivarable_on"
ERROR - 2025-09-18 15:09:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 15:09:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 15:09:44 --> Could not find the language line "recommended"
ERROR - 2025-09-18 15:09:49 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:49 --> Could not find the language line "recommended"
ERROR - 2025-09-18 15:09:56 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-18 15:09:56 --> Could not find the language line "recommended"
ERROR - 2025-09-18 15:10:00 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 15:10:00 --> Could not find the language line "product_is"
ERROR - 2025-09-18 15:10:00 --> Could not find the language line "delivarable_on"
ERROR - 2025-09-18 15:14:08 --> Could not find the language line "recommended"
ERROR - 2025-09-18 15:14:08 --> Could not find the language line "recommended"
ERROR - 2025-09-18 16:15:51 --> Could not find the language line "recommended"
ERROR - 2025-09-18 16:47:45 --> Could not find the language line "recommended"
ERROR - 2025-09-18 16:47:51 --> Could not find the language line "check_availability"
ERROR - 2025-09-18 16:47:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 16:47:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-18 16:48:08 --> Could not find the language line "recommended"
