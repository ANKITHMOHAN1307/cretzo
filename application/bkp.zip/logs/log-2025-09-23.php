<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-23 04:21:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-09-23 04:21:14 --> Could not find the language line "recommended"
ERROR - 2025-09-23 04:21:25 --> Could not find the language line "email_us"
ERROR - 2025-09-23 07:30:27 --> Could not find the language line "recommended"
ERROR - 2025-09-23 08:22:13 --> Could not find the language line "recommended"
ERROR - 2025-09-23 08:55:37 --> Could not find the language line "recommended"
ERROR - 2025-09-23 14:02:20 --> Could not find the language line "shipping_policy"
ERROR - 2025-09-23 14:02:20 --> Could not find the language line "shipping_policy"
ERROR - 2025-09-23 17:48:28 --> Could not find the language line "recommended"
ERROR - 2025-09-23 22:34:29 --> Could not find the language line "email_us"
ERROR - 2025-09-23 22:34:31 --> Could not find the language line "recommended"
