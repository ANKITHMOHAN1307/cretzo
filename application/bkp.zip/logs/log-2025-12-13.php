<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-13 00:54:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-12-13 00:54:38 --> Could not find the language line "recommended"
ERROR - 2025-12-13 01:00:15 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:21:59 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:21:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:22:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:22:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:22:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:22:39 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:22:59 --> Could not find the language line "email_us"
ERROR - 2025-12-13 03:23:20 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:23:40 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:24:20 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:24:40 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:25:01 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:25:20 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:25:40 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:25:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:25:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:26:01 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:26:50 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:27:12 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:28:28 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:28:55 --> Could not find the language line "section"
ERROR - 2025-12-13 03:28:55 --> Could not find the language line "section"
ERROR - 2025-12-13 03:28:55 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:29:07 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:29:18 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:29:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:29:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:30:16 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:30:37 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:31:25 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:31:39 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:32:08 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:32:53 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:33:12 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:33:32 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:33:53 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:33:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:33:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:34:12 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:34:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:34:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:35:17 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-13 03:35:17 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-12-13 03:35:17 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:35:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:35:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:35:38 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:35:57 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:36:17 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:36:38 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 03:36:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 03:36:57 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:37:37 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:37:57 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:38:17 --> Could not find the language line "section"
ERROR - 2025-12-13 03:38:17 --> Could not find the language line "section"
ERROR - 2025-12-13 03:38:18 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:38:37 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:39:18 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:39:38 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:39:57 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:40:17 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:40:38 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:40:58 --> Could not find the language line "recommended"
ERROR - 2025-12-13 03:42:26 --> Could not find the language line "recommended"
ERROR - 2025-12-13 04:20:13 --> Could not find the language line "recommended"
ERROR - 2025-12-13 04:53:19 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 04:53:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 04:53:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 04:58:52 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 04:58:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 04:58:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 05:16:47 --> Could not find the language line "recommended"
ERROR - 2025-12-13 05:31:23 --> Could not find the language line "recommended"
ERROR - 2025-12-13 05:33:36 --> Could not find the language line "recommended"
ERROR - 2025-12-13 06:09:04 --> Could not find the language line "recommended"
ERROR - 2025-12-13 06:21:26 --> Could not find the language line "recommended"
ERROR - 2025-12-13 07:17:10 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 07:17:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 07:17:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 07:38:52 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 07:38:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 07:38:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 09:24:23 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 09:24:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 09:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 09:32:01 --> Could not find the language line "recommended"
ERROR - 2025-12-13 09:55:08 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 09:55:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 09:55:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 10:09:46 --> Could not find the language line "recommended"
ERROR - 2025-12-13 10:21:39 --> Could not find the language line "recommended"
ERROR - 2025-12-13 11:06:53 --> Could not find the language line "recommended"
ERROR - 2025-12-13 11:38:00 --> Could not find the language line "recommended"
ERROR - 2025-12-13 11:50:00 --> Could not find the language line "recommended"
ERROR - 2025-12-13 12:01:56 --> Could not find the language line "recommended"
ERROR - 2025-12-13 12:24:52 --> Could not find the language line "recommended"
ERROR - 2025-12-13 12:47:20 --> Could not find the language line "recommended"
ERROR - 2025-12-13 12:58:31 --> Could not find the language line "recommended"
ERROR - 2025-12-13 13:25:37 --> Could not find the language line "recommended"
ERROR - 2025-12-13 14:25:19 --> Could not find the language line "recommended"
ERROR - 2025-12-13 14:32:16 --> Could not find the language line "recommended"
ERROR - 2025-12-13 14:41:58 --> Could not find the language line "recommended"
ERROR - 2025-12-13 14:51:55 --> Could not find the language line "recommended"
ERROR - 2025-12-13 15:31:31 --> Could not find the language line "recommended"
ERROR - 2025-12-13 15:42:43 --> Could not find the language line "recommended"
ERROR - 2025-12-13 16:14:03 --> Could not find the language line "recommended"
ERROR - 2025-12-13 16:52:44 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 16:52:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 16:52:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 16:55:22 --> Could not find the language line "recommended"
ERROR - 2025-12-13 16:57:25 --> Could not find the language line "check_availability"
ERROR - 2025-12-13 16:57:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 16:57:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-13 17:06:21 --> Could not find the language line "recommended"
ERROR - 2025-12-13 17:43:09 --> Could not find the language line "recommended"
