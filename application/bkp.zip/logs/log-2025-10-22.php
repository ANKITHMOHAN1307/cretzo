<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-22 00:17:26 --> Could not find the language line "recommended"
ERROR - 2025-10-22 00:24:23 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 00:24:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 00:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 00:56:35 --> Could not find the language line "recommended"
ERROR - 2025-10-22 01:09:02 --> Could not find the language line "recommended"
ERROR - 2025-10-22 01:13:51 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 02:54:47 --> Could not find the language line "recommended"
ERROR - 2025-10-22 03:01:27 --> Could not find the language line "email_us"
ERROR - 2025-10-22 03:03:26 --> Could not find the language line "recommended"
ERROR - 2025-10-22 03:25:03 --> Could not find the language line "recommended"
ERROR - 2025-10-22 03:25:49 --> Could not find the language line "recommended"
ERROR - 2025-10-22 03:59:10 --> Could not find the language line "recommended"
ERROR - 2025-10-22 05:52:30 --> Could not find the language line "recommended"
ERROR - 2025-10-22 06:26:06 --> Could not find the language line "recommended"
ERROR - 2025-10-22 06:58:17 --> Could not find the language line "recommended"
ERROR - 2025-10-22 06:58:40 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 07:00:22 --> Could not find the language line "blogs"
ERROR - 2025-10-22 07:00:22 --> Could not find the language line "no_blogs_found"
ERROR - 2025-10-22 09:21:36 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 09:21:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 09:21:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 09:27:02 --> Could not find the language line "recommended"
ERROR - 2025-10-22 10:11:21 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 10:11:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 10:11:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 10:24:46 --> Could not find the language line "recommended"
ERROR - 2025-10-22 10:55:24 --> Could not find the language line "recommended"
ERROR - 2025-10-22 11:04:22 --> Could not find the language line "recommended"
ERROR - 2025-10-22 12:12:51 --> Could not find the language line "recommended"
ERROR - 2025-10-22 12:21:38 --> Could not find the language line "recommended"
ERROR - 2025-10-22 12:23:43 --> Could not find the language line "recommended"
ERROR - 2025-10-22 12:25:55 --> Could not find the language line "recommended"
ERROR - 2025-10-22 12:26:02 --> Could not find the language line "section"
ERROR - 2025-10-22 12:26:02 --> Could not find the language line "section"
ERROR - 2025-10-22 12:26:02 --> Could not find the language line "recommended"
ERROR - 2025-10-22 12:29:12 --> Could not find the language line "recommended"
ERROR - 2025-10-22 13:18:59 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 13:18:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 13:18:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 13:28:34 --> Could not find the language line "recommended"
ERROR - 2025-10-22 13:37:40 --> Could not find the language line "recommended"
ERROR - 2025-10-22 14:00:45 --> Could not find the language line "recommended"
ERROR - 2025-10-22 17:04:46 --> Could not find the language line "recommended"
ERROR - 2025-10-22 17:59:41 --> Could not find the language line "email_us"
ERROR - 2025-10-22 18:33:24 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 18:33:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 18:33:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 18:33:30 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 18:33:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 18:33:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 20:24:36 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-22 20:24:36 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-22 21:10:39 --> Could not find the language line "compare"
ERROR - 2025-10-22 21:37:03 --> Could not find the language line "return_policy"
ERROR - 2025-10-22 21:37:03 --> Could not find the language line "return_policy"
ERROR - 2025-10-22 21:45:12 --> Could not find the language line "recommended"
ERROR - 2025-10-22 21:57:33 --> Could not find the language line "recommended"
ERROR - 2025-10-22 22:06:07 --> Could not find the language line "recommended"
ERROR - 2025-10-22 22:16:17 --> Could not find the language line "recommended"
ERROR - 2025-10-22 22:35:59 --> Could not find the language line "recommended"
ERROR - 2025-10-22 22:45:43 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:04:41 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:13:53 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:22:58 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:32:11 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:41:04 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:41:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-22 23:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 23:41:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-22 23:49:59 --> Could not find the language line "recommended"
ERROR - 2025-10-22 23:48:26 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-10-22 23:48:26 --> Unable to connect to the database
