<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-30 00:16:19 --> Could not find the language line "recommended"
ERROR - 2025-10-30 00:43:16 --> Could not find the language line "recommended"
ERROR - 2025-10-30 01:07:01 --> Could not find the language line "recommended"
ERROR - 2025-10-30 01:32:31 --> Could not find the language line "recommended"
ERROR - 2025-10-30 01:58:07 --> Could not find the language line "recommended"
ERROR - 2025-10-30 02:28:04 --> Could not find the language line "recommended"
ERROR - 2025-10-30 02:55:11 --> Could not find the language line "recommended"
ERROR - 2025-10-30 03:12:20 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-30 03:12:20 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-30 03:12:20 --> Could not find the language line "check_availability"
ERROR - 2025-10-30 03:12:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 03:12:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 03:22:00 --> Could not find the language line "recommended"
ERROR - 2025-10-30 03:49:36 --> Could not find the language line "recommended"
ERROR - 2025-10-30 04:17:49 --> Could not find the language line "recommended"
ERROR - 2025-10-30 04:19:49 --> Could not find the language line "recommended"
ERROR - 2025-10-30 04:48:10 --> Could not find the language line "recommended"
ERROR - 2025-10-30 04:57:23 --> Could not find the language line "recommended"
ERROR - 2025-10-30 05:14:20 --> Could not find the language line "recommended"
ERROR - 2025-10-30 05:41:39 --> Could not find the language line "recommended"
ERROR - 2025-10-30 06:36:42 --> Could not find the language line "recommended"
ERROR - 2025-10-30 07:01:43 --> Could not find the language line "recommended"
ERROR - 2025-10-30 07:19:21 --> Could not find the language line "recommended"
ERROR - 2025-10-30 07:26:29 --> Could not find the language line "recommended"
ERROR - 2025-10-30 07:50:50 --> Could not find the language line "recommended"
ERROR - 2025-10-30 08:20:33 --> Could not find the language line "recommended"
ERROR - 2025-10-30 08:48:05 --> Could not find the language line "recommended"
ERROR - 2025-10-30 09:13:35 --> Could not find the language line "recommended"
ERROR - 2025-10-30 09:40:07 --> Could not find the language line "recommended"
ERROR - 2025-10-30 09:58:49 --> Could not find the language line "email_us"
ERROR - 2025-10-30 10:09:45 --> Could not find the language line "recommended"
ERROR - 2025-10-30 10:36:23 --> Could not find the language line "recommended"
ERROR - 2025-10-30 10:59:36 --> Could not find the language line "recommended"
ERROR - 2025-10-30 11:02:28 --> Could not find the language line "recommended"
ERROR - 2025-10-30 11:02:40 --> Could not find the language line "check_availability"
ERROR - 2025-10-30 11:02:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 11:02:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 11:28:19 --> Could not find the language line "recommended"
ERROR - 2025-10-30 11:52:47 --> Could not find the language line "recommended"
ERROR - 2025-10-30 12:22:58 --> Could not find the language line "recommended"
ERROR - 2025-10-30 12:51:54 --> Could not find the language line "recommended"
ERROR - 2025-10-30 13:18:31 --> Could not find the language line "recommended"
ERROR - 2025-10-30 13:46:51 --> Could not find the language line "recommended"
ERROR - 2025-10-30 13:53:26 --> Could not find the language line "recommended"
ERROR - 2025-10-30 14:12:23 --> Could not find the language line "recommended"
ERROR - 2025-10-30 14:18:40 --> Could not find the language line "recommended"
ERROR - 2025-10-30 14:47:07 --> Could not find the language line "recommended"
ERROR - 2025-10-30 14:47:26 --> Could not find the language line "check_availability"
ERROR - 2025-10-30 14:47:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 14:47:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 15:15:00 --> Could not find the language line "recommended"
ERROR - 2025-10-30 15:41:15 --> Could not find the language line "recommended"
ERROR - 2025-10-30 16:12:03 --> Could not find the language line "recommended"
ERROR - 2025-10-30 16:40:37 --> Could not find the language line "recommended"
ERROR - 2025-10-30 17:06:38 --> Could not find the language line "recommended"
ERROR - 2025-10-30 17:33:07 --> Could not find the language line "recommended"
ERROR - 2025-10-30 18:01:41 --> Could not find the language line "recommended"
ERROR - 2025-10-30 18:31:22 --> Could not find the language line "recommended"
ERROR - 2025-10-30 18:45:15 --> Could not find the language line "check_availability"
ERROR - 2025-10-30 18:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 18:45:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 18:45:53 --> Could not find the language line "check_availability"
ERROR - 2025-10-30 18:45:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 18:45:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 18:59:15 --> Could not find the language line "recommended"
ERROR - 2025-10-30 19:29:31 --> Could not find the language line "recommended"
ERROR - 2025-10-30 19:56:57 --> Could not find the language line "recommended"
ERROR - 2025-10-30 20:28:29 --> Could not find the language line "recommended"
ERROR - 2025-10-30 20:58:13 --> Could not find the language line "recommended"
ERROR - 2025-10-30 21:02:46 --> Could not find the language line "check_availability"
ERROR - 2025-10-30 21:02:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 21:02:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-30 21:25:54 --> Could not find the language line "recommended"
ERROR - 2025-10-30 21:26:42 --> Could not find the language line "recommended"
ERROR - 2025-10-30 21:53:40 --> Could not find the language line "recommended"
ERROR - 2025-10-30 21:57:57 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-30 21:57:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-30 21:57:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-30 21:57:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-30 21:57:58 --> Could not find the language line "recommended"
ERROR - 2025-10-30 22:24:48 --> Could not find the language line "recommended"
ERROR - 2025-10-30 22:51:46 --> Could not find the language line "recommended"
ERROR - 2025-10-30 23:11:59 --> Could not find the language line "recommended"
ERROR - 2025-10-30 23:18:13 --> Could not find the language line "recommended"
ERROR - 2025-10-30 23:45:01 --> Could not find the language line "recommended"
