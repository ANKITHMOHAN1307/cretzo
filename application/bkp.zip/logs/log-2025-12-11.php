<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-11 00:22:41 --> Could not find the language line "recommended"
ERROR - 2025-12-11 02:02:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 02:02:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 02:02:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 02:51:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 02:51:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 02:51:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 03:12:41 --> Could not find the language line "recommended"
ERROR - 2025-12-11 03:35:10 --> Could not find the language line "recommended"
ERROR - 2025-12-11 04:31:34 --> Could not find the language line "recommended"
ERROR - 2025-12-11 04:45:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 04:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 04:45:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 04:45:42 --> Could not find the language line "recommended"
ERROR - 2025-12-11 05:00:17 --> Could not find the language line "return_policy"
ERROR - 2025-12-11 05:00:17 --> Could not find the language line "return_policy"
ERROR - 2025-12-11 05:12:13 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 05:12:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 05:12:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 05:13:04 --> Could not find the language line "email_us"
ERROR - 2025-12-11 05:15:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 05:15:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 05:15:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 05:45:38 --> Could not find the language line "recommended"
ERROR - 2025-12-11 05:48:13 --> Could not find the language line "section"
ERROR - 2025-12-11 05:48:13 --> Could not find the language line "section"
ERROR - 2025-12-11 05:48:13 --> Could not find the language line "recommended"
ERROR - 2025-12-11 05:56:10 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 05:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 05:56:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 05:59:17 --> Could not find the language line "recommended"
ERROR - 2025-12-11 06:17:52 --> Could not find the language line "email_us"
ERROR - 2025-12-11 07:56:08 --> Could not find the language line "section"
ERROR - 2025-12-11 07:56:08 --> Could not find the language line "section"
ERROR - 2025-12-11 07:56:08 --> Could not find the language line "recommended"
ERROR - 2025-12-11 08:27:08 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 08:27:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 08:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 09:11:54 --> Could not find the language line "recommended"
ERROR - 2025-12-11 09:24:50 --> Could not find the language line "recommended"
ERROR - 2025-12-11 09:53:07 --> Could not find the language line "recommended"
ERROR - 2025-12-11 10:01:21 --> Could not find the language line "recommended"
ERROR - 2025-12-11 10:28:34 --> Could not find the language line "section"
ERROR - 2025-12-11 10:28:34 --> Could not find the language line "section"
ERROR - 2025-12-11 10:28:34 --> Could not find the language line "recommended"
ERROR - 2025-12-11 13:21:59 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 13:21:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 13:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 13:50:38 --> Could not find the language line "recommended"
ERROR - 2025-12-11 14:46:34 --> Could not find the language line "recommended"
ERROR - 2025-12-11 14:59:23 --> Could not find the language line "recommended"
ERROR - 2025-12-11 16:07:46 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 16:07:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 16:07:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 16:53:37 --> Could not find the language line "recommended"
ERROR - 2025-12-11 17:40:59 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 17:40:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 17:40:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 18:16:31 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 18:16:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 18:16:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 18:29:40 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 18:29:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 18:29:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 18:45:05 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 18:45:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 18:45:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 19:04:16 --> Could not find the language line "recommended"
ERROR - 2025-12-11 20:01:22 --> Could not find the language line "email_us"
ERROR - 2025-12-11 22:49:30 --> Could not find the language line "email_us"
ERROR - 2025-12-11 23:26:57 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 23:26:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 23:26:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 23:39:18 --> Could not find the language line "check_availability"
ERROR - 2025-12-11 23:39:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-11 23:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
