<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-29 00:04:52 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-29 00:04:52 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-29 00:05:43 --> Could not find the language line "return_policy"
ERROR - 2025-11-29 00:05:43 --> Could not find the language line "return_policy"
ERROR - 2025-11-29 00:05:55 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:06:08 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:06:21 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:06:34 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:06:46 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:06:59 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:07:13 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:07:25 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:07:38 --> Could not find the language line "section"
ERROR - 2025-11-29 00:07:38 --> Could not find the language line "section"
ERROR - 2025-11-29 00:07:38 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:07:51 --> Could not find the language line "section"
ERROR - 2025-11-29 00:07:51 --> Could not find the language line "section"
ERROR - 2025-11-29 00:07:51 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:08:04 --> Could not find the language line "section"
ERROR - 2025-11-29 00:08:04 --> Could not find the language line "section"
ERROR - 2025-11-29 00:08:04 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:08:16 --> Could not find the language line "section"
ERROR - 2025-11-29 00:08:16 --> Could not find the language line "section"
ERROR - 2025-11-29 00:08:17 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:08:29 --> Could not find the language line "section"
ERROR - 2025-11-29 00:08:29 --> Could not find the language line "section"
ERROR - 2025-11-29 00:08:29 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:08:42 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:08:55 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:08:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:08:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:08 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:09:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:20 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:09:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:09:46 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:09:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:59 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:09:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:09:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:12 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:10:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:24 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:10:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:37 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:10:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:50 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:10:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:10:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:03 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:11:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:16 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-29 00:11:16 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-29 00:11:16 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:11:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 00:11:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 00:11:41 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:11:54 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:12:07 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:12:19 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:12:32 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:12:45 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:12:57 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:13:10 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:13:23 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:13:36 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:13:48 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:14:01 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:14:14 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:14:26 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:14:39 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:14:52 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:15:05 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:15:17 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:15:31 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:15:44 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:15:57 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:16:09 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:16:22 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:16:35 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:16:47 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:17:00 --> Could not find the language line "recommended"
ERROR - 2025-11-29 00:21:15 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 01:09:37 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:10:29 --> Could not find the language line "compare"
ERROR - 2025-11-29 01:10:42 --> Could not find the language line "email_us"
ERROR - 2025-11-29 01:11:07 --> Could not find the language line "email_us"
ERROR - 2025-11-29 01:12:24 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:12:36 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:12:49 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:13:02 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:13:15 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:13:27 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:13:40 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:13:53 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:14:05 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:14:18 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:14:31 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:14:44 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:14:57 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:15:10 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:15:22 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:15:35 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:15:48 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:16:00 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:16:13 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:16:26 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:16:39 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:16:51 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:17:04 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:17:17 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:17:30 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:17:42 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:17:55 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:18:08 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:18:20 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:18:33 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:18:46 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:19:01 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:19:14 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:19:27 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:19:40 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:19:53 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:20:05 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:20:18 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:20:31 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:20:43 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:20:56 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:21:09 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:21:22 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:21:34 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:21:47 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:22:00 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:22:12 --> Could not find the language line "recommended"
ERROR - 2025-11-29 01:49:18 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-29 01:49:18 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-29 01:49:18 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 01:49:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 01:49:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 01:51:22 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 01:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 01:51:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 02:22:44 --> Could not find the language line "recommended"
ERROR - 2025-11-29 02:40:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 02:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 02:40:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 03:10:32 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 03:10:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 03:10:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 03:37:53 --> Could not find the language line "recommended"
ERROR - 2025-11-29 03:39:15 --> Could not find the language line "recommended"
ERROR - 2025-11-29 03:55:13 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 03:55:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 03:55:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 04:02:33 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 04:02:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 04:02:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 04:40:57 --> Could not find the language line "recommended"
ERROR - 2025-11-29 05:19:05 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 05:56:48 --> Could not find the language line "recommended"
ERROR - 2025-11-29 06:35:41 --> Could not find the language line "recommended"
ERROR - 2025-11-29 07:20:03 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 07:20:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 07:20:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 07:25:53 --> Could not find the language line "recommended"
ERROR - 2025-11-29 08:12:24 --> Could not find the language line "recommended"
ERROR - 2025-11-29 08:59:14 --> Could not find the language line "recommended"
ERROR - 2025-11-29 09:35:20 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 09:35:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 09:35:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 09:43:14 --> Could not find the language line "recommended"
ERROR - 2025-11-29 10:10:28 --> Could not find the language line "recommended"
ERROR - 2025-11-29 10:17:39 --> Could not find the language line "recommended"
ERROR - 2025-11-29 10:52:23 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-29 10:52:23 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-29 10:52:23 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 10:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 10:52:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 10:55:11 --> Could not find the language line "recommended"
ERROR - 2025-11-29 10:56:26 --> Could not find the language line "recommended"
ERROR - 2025-11-29 11:45:27 --> Could not find the language line "recommended"
ERROR - 2025-11-29 11:55:31 --> Could not find the language line "recommended"
ERROR - 2025-11-29 12:41:12 --> Could not find the language line "recommended"
ERROR - 2025-11-29 13:18:21 --> Could not find the language line "section"
ERROR - 2025-11-29 13:18:21 --> Could not find the language line "section"
ERROR - 2025-11-29 13:18:21 --> Could not find the language line "recommended"
ERROR - 2025-11-29 13:53:46 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 13:53:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 13:53:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 14:28:42 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 14:28:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 14:28:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 14:31:22 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 14:31:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 14:31:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 14:42:44 --> Could not find the language line "recommended"
ERROR - 2025-11-29 14:57:51 --> Could not find the language line "section"
ERROR - 2025-11-29 14:57:51 --> Could not find the language line "section"
ERROR - 2025-11-29 14:57:51 --> Could not find the language line "recommended"
ERROR - 2025-11-29 15:14:22 --> Could not find the language line "email_us"
ERROR - 2025-11-29 15:14:56 --> Could not find the language line "login_heading"
ERROR - 2025-11-29 15:14:56 --> Could not find the language line "login_password_label"
ERROR - 2025-11-29 15:15:01 --> Could not find the language line "login_heading"
ERROR - 2025-11-29 15:15:01 --> Could not find the language line "login_password_label"
ERROR - 2025-11-29 15:15:06 --> Could not find the language line "login_heading"
ERROR - 2025-11-29 15:15:06 --> Could not find the language line "login_password_label"
ERROR - 2025-11-29 15:23:32 --> Could not find the language line "recommended"
ERROR - 2025-11-29 15:25:12 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 15:25:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 15:25:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 15:49:48 --> Could not find the language line "recommended"
ERROR - 2025-11-29 16:13:22 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 16:13:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 16:13:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 17:22:56 --> Could not find the language line "recommended"
ERROR - 2025-11-29 17:35:05 --> Could not find the language line "email_us"
ERROR - 2025-11-29 17:59:33 --> Could not find the language line "recommended"
ERROR - 2025-11-29 18:37:06 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 18:37:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 18:37:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 19:18:00 --> Could not find the language line "recommended"
ERROR - 2025-11-29 19:37:20 --> Could not find the language line "recommended"
ERROR - 2025-11-29 19:38:40 --> Could not find the language line "recommended"
ERROR - 2025-11-29 19:55:30 --> Could not find the language line "recommended"
ERROR - 2025-11-29 20:13:45 --> Could not find the language line "recommended"
ERROR - 2025-11-29 20:15:51 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 20:15:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 20:15:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 20:19:14 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 20:19:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 20:19:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 20:53:25 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-29 20:53:25 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-29 21:11:43 --> Could not find the language line "recommended"
ERROR - 2025-11-29 21:16:00 --> Could not find the language line "recommended"
ERROR - 2025-11-29 21:46:54 --> Could not find the language line "recommended"
ERROR - 2025-11-29 22:18:40 --> Could not find the language line "compare"
ERROR - 2025-11-29 22:22:11 --> Could not find the language line "recommended"
ERROR - 2025-11-29 22:34:19 --> Could not find the language line "recommended"
ERROR - 2025-11-29 22:36:36 --> Could not find the language line "recommended"
ERROR - 2025-11-29 22:52:09 --> Could not find the language line "recommended"
ERROR - 2025-11-29 22:55:30 --> Could not find the language line "check_availability"
ERROR - 2025-11-29 22:55:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 22:55:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-29 23:07:16 --> Could not find the language line "recommended"
ERROR - 2025-11-29 23:11:36 --> Could not find the language line "recommended"
ERROR - 2025-11-29 23:12:06 --> Could not find the language line "recommended"
ERROR - 2025-11-29 23:22:09 --> Could not find the language line "recommended"
ERROR - 2025-11-29 23:29:17 --> Could not find the language line "return_policy"
ERROR - 2025-11-29 23:29:17 --> Could not find the language line "return_policy"
ERROR - 2025-11-29 23:47:37 --> Could not find the language line "recommended"
