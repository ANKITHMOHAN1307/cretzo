<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-17 00:40:27 --> Could not find the language line "recommended"
ERROR - 2025-10-17 00:50:46 --> Could not find the language line "recommended"
ERROR - 2025-10-17 01:49:26 --> Could not find the language line "email_us"
ERROR - 2025-10-17 01:49:26 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-17 01:49:26 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-17 01:49:27 --> Could not find the language line "recommended"
ERROR - 2025-10-17 01:49:27 --> Could not find the language line "return_policy"
ERROR - 2025-10-17 01:49:27 --> Could not find the language line "return_policy"
ERROR - 2025-10-17 01:49:28 --> Could not find the language line "compare"
ERROR - 2025-10-17 02:31:33 --> Could not find the language line "recommended"
ERROR - 2025-10-17 02:50:23 --> Could not find the language line "email_us"
ERROR - 2025-10-17 02:50:24 --> Could not find the language line "recommended"
ERROR - 2025-10-17 02:50:24 --> Could not find the language line "return_policy"
ERROR - 2025-10-17 02:50:24 --> Could not find the language line "return_policy"
ERROR - 2025-10-17 02:50:24 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-17 02:50:24 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-17 02:50:25 --> Could not find the language line "compare"
ERROR - 2025-10-17 03:25:36 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 03:25:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 03:25:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 06:41:11 --> Could not find the language line "recommended"
ERROR - 2025-10-17 08:54:33 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 08:54:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 08:54:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 10:00:24 --> Could not find the language line "recommended"
ERROR - 2025-10-17 10:30:32 --> Could not find the language line "email_us"
ERROR - 2025-10-17 10:30:53 --> Could not find the language line "section"
ERROR - 2025-10-17 10:30:53 --> Could not find the language line "section"
ERROR - 2025-10-17 10:30:53 --> Could not find the language line "recommended"
ERROR - 2025-10-17 10:31:03 --> Could not find the language line "email_us"
ERROR - 2025-10-17 11:10:17 --> Could not find the language line "recommended"
ERROR - 2025-10-17 11:25:35 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 12:12:36 --> Could not find the language line "email_us"
ERROR - 2025-10-17 12:31:01 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-17 12:31:01 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-17 13:04:57 --> Could not find the language line "compare"
ERROR - 2025-10-17 13:10:47 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 13:10:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 13:10:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 14:03:30 --> Could not find the language line "recommended"
ERROR - 2025-10-17 14:14:22 --> Could not find the language line "return_policy"
ERROR - 2025-10-17 14:14:22 --> Could not find the language line "return_policy"
ERROR - 2025-10-17 15:34:42 --> Could not find the language line "recommended"
ERROR - 2025-10-17 15:48:29 --> Could not find the language line "recommended"
ERROR - 2025-10-17 16:04:46 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 16:04:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 16:04:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 16:04:47 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 16:04:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 16:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 16:04:48 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 16:04:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 16:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 16:19:05 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 16:24:30 --> Could not find the language line "recommended"
ERROR - 2025-10-17 17:21:21 --> Could not find the language line "recommended"
ERROR - 2025-10-17 17:54:55 --> Could not find the language line "recommended"
ERROR - 2025-10-17 18:21:30 --> Could not find the language line "recommended"
ERROR - 2025-10-17 18:52:24 --> Could not find the language line "recommended"
ERROR - 2025-10-17 19:20:48 --> Could not find the language line "recommended"
ERROR - 2025-10-17 19:47:41 --> Could not find the language line "recommended"
ERROR - 2025-10-17 20:06:41 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 20:06:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 20:18:27 --> Could not find the language line "recommended"
ERROR - 2025-10-17 20:35:45 --> Could not find the language line "email_us"
ERROR - 2025-10-17 20:35:47 --> Could not find the language line "recommended"
ERROR - 2025-10-17 20:44:48 --> Could not find the language line "recommended"
ERROR - 2025-10-17 21:05:42 --> Could not find the language line "recommended"
ERROR - 2025-10-17 21:25:42 --> Could not find the language line "recommended"
ERROR - 2025-10-17 21:28:57 --> Could not find the language line "check_availability"
ERROR - 2025-10-17 21:28:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 21:28:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-17 21:46:01 --> Could not find the language line "recommended"
ERROR - 2025-10-17 22:07:55 --> Could not find the language line "recommended"
ERROR - 2025-10-17 22:36:36 --> Could not find the language line "recommended"
ERROR - 2025-10-17 22:58:58 --> Could not find the language line "recommended"
ERROR - 2025-10-17 23:21:12 --> Could not find the language line "recommended"
ERROR - 2025-10-17 23:43:59 --> Could not find the language line "recommended"
