<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-10 00:06:20 --> Could not find the language line "recommended"
ERROR - 2025-12-10 00:32:54 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 00:32:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 00:32:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 01:26:52 --> Could not find the language line "recommended"
ERROR - 2025-12-10 01:55:54 --> Could not find the language line "compare"
ERROR - 2025-12-10 02:15:15 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 02:15:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 02:15:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 03:11:25 --> Could not find the language line "email_us"
ERROR - 2025-12-10 03:11:28 --> Could not find the language line "email_us"
ERROR - 2025-12-10 04:02:45 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 04:02:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 04:02:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 04:12:08 --> Could not find the language line "email_us"
ERROR - 2025-12-10 04:12:09 --> Could not find the language line "recommended"
ERROR - 2025-12-10 04:12:09 --> Could not find the language line "return_policy"
ERROR - 2025-12-10 04:12:09 --> Could not find the language line "return_policy"
ERROR - 2025-12-10 04:12:09 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-10 04:12:09 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-10 04:12:09 --> Could not find the language line "compare"
ERROR - 2025-12-10 04:24:49 --> Could not find the language line "email_us"
ERROR - 2025-12-10 04:24:49 --> Could not find the language line "recommended"
ERROR - 2025-12-10 04:24:49 --> Could not find the language line "return_policy"
ERROR - 2025-12-10 04:24:49 --> Could not find the language line "return_policy"
ERROR - 2025-12-10 04:24:50 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-10 04:24:50 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-10 04:24:50 --> Could not find the language line "compare"
ERROR - 2025-12-10 04:44:56 --> Could not find the language line "recommended"
ERROR - 2025-12-10 05:23:35 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 05:23:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 05:23:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 05:31:36 --> Could not find the language line "recommended"
ERROR - 2025-12-10 06:09:56 --> Could not find the language line "recommended"
ERROR - 2025-12-10 06:16:23 --> Could not find the language line "recommended"
ERROR - 2025-12-10 06:33:39 --> Could not find the language line "recommended"
ERROR - 2025-12-10 06:42:51 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 06:42:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 06:42:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 06:46:29 --> Could not find the language line "recommended"
ERROR - 2025-12-10 07:29:50 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 08:10:10 --> Could not find the language line "recommended"
ERROR - 2025-12-10 09:58:35 --> Could not find the language line "email_us"
ERROR - 2025-12-10 10:47:43 --> Could not find the language line "recommended"
ERROR - 2025-12-10 11:16:53 --> Could not find the language line "recommended"
ERROR - 2025-12-10 11:46:04 --> Could not find the language line "recommended"
ERROR - 2025-12-10 11:55:38 --> Could not find the language line "recommended"
ERROR - 2025-12-10 13:13:50 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 13:13:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 13:13:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 13:30:15 --> Could not find the language line "email_us"
ERROR - 2025-12-10 14:04:29 --> Could not find the language line "recommended"
ERROR - 2025-12-10 14:19:35 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 14:19:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 14:19:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 14:24:49 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 14:24:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 14:24:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 14:26:03 --> Could not find the language line "return_policy"
ERROR - 2025-12-10 14:26:03 --> Could not find the language line "return_policy"
ERROR - 2025-12-10 15:26:43 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-10 15:26:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-10 15:26:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-10 15:26:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-10 15:26:45 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:39:26 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:49:37 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-10 15:49:37 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-10 15:50:31 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 15:50:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 15:50:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 15:50:36 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:38 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:43 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:45 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:48 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:51 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:54 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:56 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:50:59 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:03 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:06 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:08 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:11 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:16 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:18 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:21 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:24 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:27 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:29 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:33 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:42 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:43 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:46 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:51 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:53 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:57 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:51:59 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:02 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:05 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:07 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:09 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:11 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:16 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:19 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:22 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:26 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:28 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:34 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:36 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:39 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:47 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:50 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:52 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:54 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:56 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:52:59 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:03 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:06 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:08 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:22 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:23 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:26 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:27 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:29 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:34 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:37 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:42 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:43 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:45 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:49 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:53:51 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:03 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:07 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:13 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:14 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:16 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:19 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:21 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:23 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:25 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:26 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:29 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:31 --> Could not find the language line "recommended"
ERROR - 2025-12-10 15:54:39 --> Could not find the language line "email_us"
ERROR - 2025-12-10 15:57:39 --> Could not find the language line "recommended"
ERROR - 2025-12-10 16:16:02 --> Could not find the language line "recommended"
ERROR - 2025-12-10 16:44:33 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 16:44:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 16:44:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 16:58:57 --> Could not find the language line "email_us"
ERROR - 2025-12-10 17:56:45 --> Could not find the language line "recommended"
ERROR - 2025-12-10 18:19:57 --> Could not find the language line "recommended"
ERROR - 2025-12-10 18:39:18 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 18:39:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 18:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 18:42:07 --> Could not find the language line "recommended"
ERROR - 2025-12-10 18:59:33 --> Could not find the language line "recommended"
ERROR - 2025-12-10 19:17:58 --> Could not find the language line "email_us"
ERROR - 2025-12-10 19:56:35 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 19:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 19:56:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 20:08:11 --> Could not find the language line "compare"
ERROR - 2025-12-10 20:32:13 --> Could not find the language line "recommended"
ERROR - 2025-12-10 20:46:21 --> Could not find the language line "recommended"
ERROR - 2025-12-10 21:17:14 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 21:17:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 21:17:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 21:49:28 --> Could not find the language line "check_availability"
ERROR - 2025-12-10 21:49:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-10 21:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
