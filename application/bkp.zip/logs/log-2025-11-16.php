<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-16 00:35:32 --> Could not find the language line "recommended"
ERROR - 2025-11-16 00:55:15 --> Could not find the language line "recommended"
ERROR - 2025-11-16 01:12:03 --> Could not find the language line "recommended"
ERROR - 2025-11-16 01:29:14 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 01:29:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 01:29:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 01:46:02 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-16 01:46:02 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-16 01:46:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 01:46:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 01:46:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:13:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 02:13:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:13:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:18:55 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 02:40:23 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 02:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:40:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:57:48 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 02:57:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:57:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 02:58:29 --> Could not find the language line "email_us"
ERROR - 2025-11-16 03:13:49 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 03:13:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 03:13:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 03:14:05 --> Could not find the language line "recommended"
ERROR - 2025-11-16 03:29:51 --> Could not find the language line "recommended"
ERROR - 2025-11-16 03:44:47 --> Could not find the language line "recommended"
ERROR - 2025-11-16 04:00:39 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 04:00:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:00:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:13:21 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 04:13:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:19:17 --> Could not find the language line "recommended"
ERROR - 2025-11-16 04:24:03 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 04:24:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:24:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:37:35 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 04:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:37:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 04:54:16 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 05:12:06 --> Could not find the language line "recommended"
ERROR - 2025-11-16 05:28:53 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 05:29:55 --> Could not find the language line "recommended"
ERROR - 2025-11-16 05:44:41 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 05:44:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 05:44:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 06:01:29 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 06:01:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 06:01:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 06:17:58 --> Could not find the language line "recommended"
ERROR - 2025-11-16 06:38:43 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 06:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 06:38:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 06:42:48 --> Could not find the language line "recommended"
ERROR - 2025-11-16 06:56:21 --> Could not find the language line "recommended"
ERROR - 2025-11-16 07:12:19 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-16 07:12:19 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-11-16 07:12:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 07:12:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 07:12:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 07:27:43 --> Could not find the language line "recommended"
ERROR - 2025-11-16 07:44:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 07:44:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 07:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 07:56:36 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 07:56:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 07:56:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 07:59:31 --> Could not find the language line "recommended"
ERROR - 2025-11-16 08:00:46 --> Could not find the language line "recommended"
ERROR - 2025-11-16 08:16:13 --> Could not find the language line "recommended"
ERROR - 2025-11-16 08:25:24 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 08:25:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 08:25:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 08:35:25 --> Could not find the language line "recommended"
ERROR - 2025-11-16 08:52:37 --> Could not find the language line "recommended"
ERROR - 2025-11-16 09:08:32 --> Could not find the language line "recommended"
ERROR - 2025-11-16 09:12:00 --> Could not find the language line "recommended"
ERROR - 2025-11-16 09:24:50 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 09:24:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 09:24:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 09:25:08 --> Could not find the language line "recommended"
ERROR - 2025-11-16 09:41:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 09:41:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 09:41:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 09:57:04 --> Could not find the language line "section"
ERROR - 2025-11-16 09:57:04 --> Could not find the language line "section"
ERROR - 2025-11-16 09:57:04 --> Could not find the language line "recommended"
ERROR - 2025-11-16 09:57:38 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 09:57:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 09:57:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 10:14:02 --> Could not find the language line "recommended"
ERROR - 2025-11-16 10:36:18 --> Could not find the language line "recommended"
ERROR - 2025-11-16 11:12:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 11:12:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 11:12:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 11:28:45 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 11:28:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 11:28:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 11:44:49 --> Could not find the language line "recommended"
ERROR - 2025-11-16 12:01:37 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 12:01:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 12:01:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 12:19:27 --> Could not find the language line "recommended"
ERROR - 2025-11-16 12:38:20 --> Could not find the language line "recommended"
ERROR - 2025-11-16 12:53:43 --> Could not find the language line "recommended"
ERROR - 2025-11-16 13:10:47 --> Could not find the language line "recommended"
ERROR - 2025-11-16 13:13:51 --> Could not find the language line "recommended"
ERROR - 2025-11-16 13:42:30 --> Could not find the language line "recommended"
ERROR - 2025-11-16 14:05:03 --> Could not find the language line "recommended"
ERROR - 2025-11-16 14:12:18 --> Could not find the language line "recommended"
ERROR - 2025-11-16 14:29:18 --> Could not find the language line "recommended"
ERROR - 2025-11-16 14:30:34 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 14:30:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 14:30:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 14:46:42 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 14:46:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 14:46:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 14:56:44 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:03:20 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:17:58 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:31:32 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:45:53 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:58:15 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:58:17 --> Could not find the language line "recommended"
ERROR - 2025-11-16 15:59:56 --> Could not find the language line "recommended"
ERROR - 2025-11-16 16:13:48 --> Could not find the language line "recommended"
ERROR - 2025-11-16 16:24:33 --> Could not find the language line "recommended"
ERROR - 2025-11-16 16:31:38 --> Could not find the language line "recommended"
ERROR - 2025-11-16 16:48:56 --> Could not find the language line "recommended"
ERROR - 2025-11-16 17:02:51 --> Could not find the language line "recommended"
ERROR - 2025-11-16 17:17:51 --> Could not find the language line "recommended"
ERROR - 2025-11-16 17:31:59 --> Could not find the language line "recommended"
ERROR - 2025-11-16 17:46:23 --> Could not find the language line "recommended"
ERROR - 2025-11-16 18:02:23 --> Could not find the language line "recommended"
ERROR - 2025-11-16 18:19:07 --> Could not find the language line "recommended"
ERROR - 2025-11-16 18:40:05 --> Could not find the language line "recommended"
ERROR - 2025-11-16 18:55:04 --> Could not find the language line "recommended"
ERROR - 2025-11-16 18:55:04 --> Could not find the language line "recommended"
ERROR - 2025-11-16 18:57:56 --> Could not find the language line "recommended"
ERROR - 2025-11-16 19:31:55 --> Could not find the language line "recommended"
ERROR - 2025-11-16 19:37:16 --> Could not find the language line "recommended"
ERROR - 2025-11-16 19:47:56 --> Could not find the language line "section"
ERROR - 2025-11-16 19:47:56 --> Could not find the language line "section"
ERROR - 2025-11-16 19:47:56 --> Could not find the language line "recommended"
ERROR - 2025-11-16 19:48:34 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 19:48:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 19:48:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 20:03:54 --> Could not find the language line "section"
ERROR - 2025-11-16 20:03:54 --> Could not find the language line "section"
ERROR - 2025-11-16 20:03:54 --> Could not find the language line "recommended"
ERROR - 2025-11-16 20:20:10 --> Could not find the language line "recommended"
ERROR - 2025-11-16 20:51:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 20:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 20:51:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 20:52:11 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 20:52:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 20:52:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 20:53:11 --> Could not find the language line "recommended"
ERROR - 2025-11-16 21:07:34 --> Could not find the language line "section"
ERROR - 2025-11-16 21:07:34 --> Could not find the language line "section"
ERROR - 2025-11-16 21:07:34 --> Could not find the language line "recommended"
ERROR - 2025-11-16 21:22:59 --> Could not find the language line "email_us"
ERROR - 2025-11-16 21:43:03 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 22:05:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 22:05:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 22:05:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 22:34:08 --> Could not find the language line "recommended"
ERROR - 2025-11-16 23:04:31 --> Could not find the language line "recommended"
ERROR - 2025-11-16 23:30:51 --> Could not find the language line "recommended"
ERROR - 2025-11-16 23:33:40 --> Could not find the language line "check_availability"
ERROR - 2025-11-16 23:33:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 23:33:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-16 23:43:47 --> Could not find the language line "recommended"
