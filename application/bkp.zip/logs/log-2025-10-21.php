<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-21 00:44:03 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 00:44:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 00:44:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 01:22:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 01:22:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 01:22:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 01:44:07 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 01:44:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 01:44:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 01:57:47 --> Could not find the language line "recommended"
ERROR - 2025-10-21 02:45:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 02:45:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 02:45:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 02:55:23 --> Could not find the language line "recommended"
ERROR - 2025-10-21 03:24:31 --> Could not find the language line "recommended"
ERROR - 2025-10-21 03:32:23 --> Could not find the language line "recommended"
ERROR - 2025-10-21 03:43:25 --> Could not find the language line "recommended"
ERROR - 2025-10-21 03:54:43 --> Could not find the language line "recommended"
ERROR - 2025-10-21 03:55:16 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 04:19:59 --> Could not find the language line "recommended"
ERROR - 2025-10-21 05:12:39 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 05:12:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 05:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 05:33:15 --> Could not find the language line "recommended"
ERROR - 2025-10-21 05:58:13 --> Could not find the language line "recommended"
ERROR - 2025-10-21 06:01:38 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 06:01:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 06:01:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 06:54:44 --> Could not find the language line "recommended"
ERROR - 2025-10-21 07:40:19 --> Could not find the language line "recommended"
ERROR - 2025-10-21 07:43:37 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 07:43:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 07:43:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 08:50:16 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 08:50:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 08:50:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 10:26:53 --> Could not find the language line "recommended"
ERROR - 2025-10-21 10:34:55 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 10:58:13 --> Could not find the language line "recommended"
ERROR - 2025-10-21 12:33:47 --> Could not find the language line "email_us"
ERROR - 2025-10-21 12:33:48 --> Could not find the language line "recommended"
ERROR - 2025-10-21 12:38:46 --> Could not find the language line "section"
ERROR - 2025-10-21 12:38:46 --> Could not find the language line "section"
ERROR - 2025-10-21 12:38:46 --> Could not find the language line "recommended"
ERROR - 2025-10-21 12:39:06 --> Could not find the language line "recommended"
ERROR - 2025-10-21 12:49:05 --> Could not find the language line "email_us"
ERROR - 2025-10-21 12:49:06 --> Could not find the language line "recommended"
ERROR - 2025-10-21 12:51:35 --> Could not find the language line "recommended"
ERROR - 2025-10-21 12:58:51 --> Could not find the language line "section"
ERROR - 2025-10-21 12:58:51 --> Could not find the language line "section"
ERROR - 2025-10-21 12:58:51 --> Could not find the language line "recommended"
ERROR - 2025-10-21 13:55:50 --> Could not find the language line "section"
ERROR - 2025-10-21 13:55:50 --> Could not find the language line "section"
ERROR - 2025-10-21 13:55:50 --> Could not find the language line "recommended"
ERROR - 2025-10-21 14:54:25 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 15:00:22 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 15:00:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 15:00:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 15:13:44 --> Could not find the language line "recommended"
ERROR - 2025-10-21 16:20:41 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 16:20:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 16:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 20:54:31 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-21 20:54:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-21 20:54:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-21 20:54:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-21 20:54:32 --> Could not find the language line "recommended"
ERROR - 2025-10-21 21:18:45 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 21:18:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 21:18:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 22:04:40 --> Could not find the language line "check_availability"
ERROR - 2025-10-21 22:04:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-21 22:04:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
