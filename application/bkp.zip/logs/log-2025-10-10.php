<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-10 00:16:59 --> Could not find the language line "recommended"
ERROR - 2025-10-10 01:54:00 --> Could not find the language line "recommended"
ERROR - 2025-10-10 02:35:27 --> Could not find the language line "check_availability"
ERROR - 2025-10-10 02:35:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-10 02:35:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-10 03:10:55 --> Could not find the language line "recommended"
ERROR - 2025-10-10 04:34:55 --> Could not find the language line "recommended"
ERROR - 2025-10-10 05:24:34 --> Could not find the language line "check_availability"
ERROR - 2025-10-10 05:24:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-10 05:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-10 06:12:13 --> Could not find the language line "recommended"
ERROR - 2025-10-10 07:24:30 --> Could not find the language line "recommended"
ERROR - 2025-10-10 09:38:47 --> Could not find the language line "recommended"
ERROR - 2025-10-10 10:08:17 --> Could not find the language line "check_availability"
ERROR - 2025-10-10 10:08:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-10 10:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-10 10:41:18 --> Could not find the language line "recommended"
ERROR - 2025-10-10 11:24:50 --> Could not find the language line "recommended"
ERROR - 2025-10-10 11:41:30 --> Could not find the language line "recommended"
ERROR - 2025-10-10 11:49:56 --> Could not find the language line "email_us"
ERROR - 2025-10-10 11:57:28 --> Could not find the language line "recommended"
ERROR - 2025-10-10 12:42:19 --> Could not find the language line "return_policy"
ERROR - 2025-10-10 12:42:19 --> Could not find the language line "return_policy"
ERROR - 2025-10-10 13:29:56 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-10 13:29:56 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-10 14:41:06 --> Could not find the language line "email_us"
ERROR - 2025-10-10 14:42:23 --> Could not find the language line "recommended"
ERROR - 2025-10-10 15:17:35 --> Could not find the language line "recommended"
ERROR - 2025-10-10 15:41:45 --> Could not find the language line "recommended"
ERROR - 2025-10-10 16:10:25 --> Could not find the language line "recommended"
ERROR - 2025-10-10 16:29:38 --> Could not find the language line "recommended"
ERROR - 2025-10-10 17:18:18 --> Could not find the language line "compare"
ERROR - 2025-10-10 17:49:52 --> Could not find the language line "recommended"
ERROR - 2025-10-10 17:51:39 --> Could not find the language line "email_us"
ERROR - 2025-10-10 17:51:39 --> Could not find the language line "recommended"
ERROR - 2025-10-10 17:51:40 --> Could not find the language line "return_policy"
ERROR - 2025-10-10 17:51:40 --> Could not find the language line "return_policy"
ERROR - 2025-10-10 17:51:40 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-10 17:51:40 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-10 17:51:41 --> Could not find the language line "compare"
ERROR - 2025-10-10 23:21:56 --> Could not find the language line "recommended"
