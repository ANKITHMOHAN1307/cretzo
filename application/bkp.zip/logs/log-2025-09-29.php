<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-29 01:51:17 --> Could not find the language line "recommended"
ERROR - 2025-09-29 01:58:45 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:06:23 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:07:20 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:12:33 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:19:33 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:26:22 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:33:27 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:36:47 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:40:36 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:47:52 --> Could not find the language line "recommended"
ERROR - 2025-09-29 02:54:53 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:01:46 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:08:50 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:15:30 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:22:02 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:28:31 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:34:26 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:40:34 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:46:25 --> Could not find the language line "recommended"
ERROR - 2025-09-29 03:52:21 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:01:31 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:10:32 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:12:13 --> Could not find the language line "email_us"
ERROR - 2025-09-29 04:18:15 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:25:19 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:32:25 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:43:14 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:48:42 --> Could not find the language line "recommended"
ERROR - 2025-09-29 04:54:41 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:00:53 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:06:47 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:12:59 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:18:45 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:24:38 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:24:53 --> Could not find the language line "email_us"
ERROR - 2025-09-29 05:30:12 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:36:12 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:41:49 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:54:00 --> Could not find the language line "recommended"
ERROR - 2025-09-29 05:59:38 --> Could not find the language line "email_us"
ERROR - 2025-09-29 06:54:27 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 06:54:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 06:54:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 07:17:42 --> Could not find the language line "email_us"
ERROR - 2025-09-29 07:32:49 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 07:32:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 07:32:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 08:16:01 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 08:16:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 08:16:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 08:24:35 --> Could not find the language line "recommended"
ERROR - 2025-09-29 08:56:33 --> Could not find the language line "email_us"
ERROR - 2025-09-29 09:36:22 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-29 09:36:22 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-29 09:36:22 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 09:36:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 09:36:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 09:46:29 --> Could not find the language line "recommended"
ERROR - 2025-09-29 13:25:29 --> Could not find the language line "recommended"
ERROR - 2025-09-29 14:25:37 --> Could not find the language line "recommended"
ERROR - 2025-09-29 14:47:10 --> Could not find the language line "recommended"
ERROR - 2025-09-29 15:43:34 --> Could not find the language line "recommended"
ERROR - 2025-09-29 15:57:15 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 16:09:05 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 16:09:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:09:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:21:39 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 16:21:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:21:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:33:26 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 16:33:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:33:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:44:49 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 16:44:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:44:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:55:43 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 16:55:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 16:55:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 17:06:19 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 17:06:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 17:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 17:15:26 --> Could not find the language line "recommended"
ERROR - 2025-09-29 17:22:39 --> Could not find the language line "recommended"
ERROR - 2025-09-29 17:38:44 --> Could not find the language line "recommended"
ERROR - 2025-09-29 17:44:03 --> Could not find the language line "check_availability"
ERROR - 2025-09-29 17:44:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 17:44:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-29 21:17:54 --> Could not find the language line "recommended"
ERROR - 2025-09-29 22:36:09 --> Could not find the language line "email_us"
ERROR - 2025-09-29 22:36:11 --> Could not find the language line "recommended"
