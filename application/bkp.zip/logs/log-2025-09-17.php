<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-17 00:28:24 --> Could not find the language line "recommended"
ERROR - 2025-09-17 01:17:47 --> Could not find the language line "recommended"
ERROR - 2025-09-17 07:07:37 --> Could not find the language line "email_us"
ERROR - 2025-09-17 09:34:41 --> Could not find the language line "compare"
ERROR - 2025-09-17 09:40:46 --> Could not find the language line "recommended"
ERROR - 2025-09-17 09:43:45 --> Could not find the language line "recommended"
ERROR - 2025-09-17 10:12:33 --> Could not find the language line "recommended"
ERROR - 2025-09-17 10:13:25 --> Could not find the language line "recommended"
ERROR - 2025-09-17 10:14:32 --> Could not find the language line "recommended"
ERROR - 2025-09-17 10:58:53 --> Could not find the language line "recommended"
ERROR - 2025-09-17 13:29:09 --> Could not find the language line "recommended"
ERROR - 2025-09-17 15:10:28 --> Could not find the language line "check_availability"
ERROR - 2025-09-17 15:10:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-17 15:10:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-17 15:10:50 --> Could not find the language line "recommended"
ERROR - 2025-09-17 15:29:01 --> Could not find the language line "recommended"
ERROR - 2025-09-17 15:35:45 --> Could not find the language line "recommended"
ERROR - 2025-09-17 20:49:09 --> Could not find the language line "recommended"
ERROR - 2025-09-17 22:32:44 --> Could not find the language line "email_us"
ERROR - 2025-09-17 22:32:45 --> Could not find the language line "recommended"
ERROR - 2025-09-17 22:38:10 --> Could not find the language line "recommended"
ERROR - 2025-09-17 22:58:43 --> Could not find the language line "recommended"
