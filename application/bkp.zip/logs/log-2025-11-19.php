<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-19 00:33:07 --> Could not find the language line "recommended"
ERROR - 2025-11-19 00:48:53 --> Could not find the language line "recommended"
ERROR - 2025-11-19 01:41:44 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 01:41:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 01:41:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 01:52:51 --> Could not find the language line "recommended"
ERROR - 2025-11-19 02:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-11-19 02:12:42 --> Could not find the language line "recommended"
ERROR - 2025-11-19 02:42:11 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 02:42:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 02:42:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 02:47:13 --> Could not find the language line "email_us"
ERROR - 2025-11-19 03:16:12 --> Could not find the language line "recommended"
ERROR - 2025-11-19 04:15:59 --> Could not find the language line "recommended"
ERROR - 2025-11-19 05:42:38 --> Could not find the language line "recommended"
ERROR - 2025-11-19 05:53:10 --> Could not find the language line "recommended"
ERROR - 2025-11-19 06:31:19 --> Could not find the language line "recommended"
ERROR - 2025-11-19 07:05:09 --> Could not find the language line "recommended"
ERROR - 2025-11-19 07:30:42 --> Could not find the language line "email_us"
ERROR - 2025-11-19 07:30:43 --> Could not find the language line "recommended"
ERROR - 2025-11-19 07:30:43 --> Could not find the language line "return_policy"
ERROR - 2025-11-19 07:30:43 --> Could not find the language line "return_policy"
ERROR - 2025-11-19 07:30:44 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-19 07:30:44 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-19 07:30:44 --> Could not find the language line "compare"
ERROR - 2025-11-19 07:38:03 --> Could not find the language line "recommended"
ERROR - 2025-11-19 07:46:07 --> Could not find the language line "email_us"
ERROR - 2025-11-19 07:46:08 --> Could not find the language line "recommended"
ERROR - 2025-11-19 07:46:08 --> Could not find the language line "return_policy"
ERROR - 2025-11-19 07:46:08 --> Could not find the language line "return_policy"
ERROR - 2025-11-19 07:46:08 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-19 07:46:08 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-19 07:46:08 --> Could not find the language line "compare"
ERROR - 2025-11-19 08:13:53 --> Could not find the language line "recommended"
ERROR - 2025-11-19 08:55:33 --> Could not find the language line "recommended"
ERROR - 2025-11-19 09:39:57 --> Could not find the language line "recommended"
ERROR - 2025-11-19 10:24:50 --> Could not find the language line "recommended"
ERROR - 2025-11-19 11:08:26 --> Could not find the language line "recommended"
ERROR - 2025-11-19 11:38:54 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 11:38:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 11:38:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 11:45:53 --> Could not find the language line "recommended"
ERROR - 2025-11-19 12:25:45 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-19 12:25:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-19 12:25:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-19 12:25:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-19 12:25:46 --> Could not find the language line "recommended"
ERROR - 2025-11-19 13:14:16 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 13:14:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 13:14:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 13:25:06 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 13:25:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 13:25:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 13:38:19 --> Could not find the language line "recommended"
ERROR - 2025-11-19 14:45:06 --> Could not find the language line "recommended"
ERROR - 2025-11-19 15:20:59 --> Could not find the language line "recommended"
ERROR - 2025-11-19 15:31:05 --> Could not find the language line "recommended"
ERROR - 2025-11-19 15:55:24 --> Could not find the language line "recommended"
ERROR - 2025-11-19 16:31:54 --> Could not find the language line "recommended"
ERROR - 2025-11-19 16:51:04 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 16:51:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 16:51:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 17:26:08 --> Could not find the language line "recommended"
ERROR - 2025-11-19 17:41:47 --> Could not find the language line "recommended"
ERROR - 2025-11-19 18:03:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 18:03:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 18:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 18:12:59 --> Could not find the language line "email_us"
ERROR - 2025-11-19 18:44:14 --> Could not find the language line "recommended"
ERROR - 2025-11-19 18:58:15 --> Could not find the language line "email_us"
ERROR - 2025-11-19 18:58:16 --> Could not find the language line "recommended"
ERROR - 2025-11-19 19:18:33 --> Could not find the language line "recommended"
ERROR - 2025-11-19 19:48:08 --> Could not find the language line "recommended"
ERROR - 2025-11-19 20:16:59 --> Could not find the language line "recommended"
ERROR - 2025-11-19 20:48:32 --> Could not find the language line "recommended"
ERROR - 2025-11-19 21:48:43 --> Could not find the language line "recommended"
ERROR - 2025-11-19 23:23:55 --> Could not find the language line "recommended"
ERROR - 2025-11-19 23:45:07 --> Could not find the language line "check_availability"
ERROR - 2025-11-19 23:45:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 23:45:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-19 23:56:29 --> Could not find the language line "compare"
