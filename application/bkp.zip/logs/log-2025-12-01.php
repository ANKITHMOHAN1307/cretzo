<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-01 00:00:44 --> Could not find the language line "section"
ERROR - 2025-12-01 00:00:44 --> Could not find the language line "section"
ERROR - 2025-12-01 00:00:44 --> Could not find the language line "recommended"
ERROR - 2025-12-01 00:31:47 --> Could not find the language line "recommended"
ERROR - 2025-12-01 00:39:01 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 00:39:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 00:39:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 01:01:40 --> Could not find the language line "recommended"
ERROR - 2025-12-01 01:26:25 --> Could not find the language line "email_us"
ERROR - 2025-12-01 01:29:00 --> Could not find the language line "recommended"
ERROR - 2025-12-01 01:44:10 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 01:44:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 01:44:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 01:51:23 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 01:51:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 01:51:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 01:57:20 --> Could not find the language line "section"
ERROR - 2025-12-01 01:57:20 --> Could not find the language line "section"
ERROR - 2025-12-01 01:57:20 --> Could not find the language line "recommended"
ERROR - 2025-12-01 02:57:46 --> Could not find the language line "recommended"
ERROR - 2025-12-01 03:27:01 --> Could not find the language line "recommended"
ERROR - 2025-12-01 03:36:33 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 03:36:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 03:36:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 04:11:18 --> Could not find the language line "recommended"
ERROR - 2025-12-01 04:25:28 --> Could not find the language line "recommended"
ERROR - 2025-12-01 04:37:27 --> Could not find the language line "recommended"
ERROR - 2025-12-01 04:54:27 --> Could not find the language line "recommended"
ERROR - 2025-12-01 05:31:47 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 05:31:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 05:31:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 05:39:27 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 05:39:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 05:39:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 05:45:06 --> Could not find the language line "recommended"
ERROR - 2025-12-01 06:13:08 --> Could not find the language line "recommended"
ERROR - 2025-12-01 06:48:59 --> Could not find the language line "recommended"
ERROR - 2025-12-01 07:27:33 --> Could not find the language line "recommended"
ERROR - 2025-12-01 08:50:59 --> Could not find the language line "recommended"
ERROR - 2025-12-01 09:30:11 --> Could not find the language line "email_us"
ERROR - 2025-12-01 09:47:38 --> Could not find the language line "recommended"
ERROR - 2025-12-01 10:48:53 --> Could not find the language line "recommended"
ERROR - 2025-12-01 11:47:47 --> Could not find the language line "recommended"
ERROR - 2025-12-01 12:43:57 --> Could not find the language line "recommended"
ERROR - 2025-12-01 12:47:08 --> Could not find the language line "recommended"
ERROR - 2025-12-01 12:59:19 --> Could not find the language line "email_us"
ERROR - 2025-12-01 13:06:54 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-01 13:06:54 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-01 13:14:00 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-01 13:14:00 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-01 13:49:10 --> Could not find the language line "recommended"
ERROR - 2025-12-01 14:55:29 --> Could not find the language line "recommended"
ERROR - 2025-12-01 16:03:51 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 16:03:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 16:03:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 16:23:28 --> Could not find the language line "recommended"
ERROR - 2025-12-01 16:43:13 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 16:43:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 16:43:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 17:24:55 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 17:24:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 17:24:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 17:44:38 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 17:44:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 17:44:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 17:55:04 --> Could not find the language line "recommended"
ERROR - 2025-12-01 17:55:41 --> Could not find the language line "recommended"
ERROR - 2025-12-01 18:01:40 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 18:01:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 18:01:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 19:59:07 --> Could not find the language line "email_us"
ERROR - 2025-12-01 21:21:41 --> Could not find the language line "check_availability"
ERROR - 2025-12-01 21:21:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 21:21:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-01 21:25:21 --> Could not find the language line "recommended"
ERROR - 2025-12-01 21:40:43 --> Could not find the language line "recommended"
ERROR - 2025-12-01 22:01:35 --> Could not find the language line "recommended"
ERROR - 2025-12-01 22:39:06 --> Could not find the language line "recommended"
ERROR - 2025-12-01 23:17:45 --> Could not find the language line "recommended"
ERROR - 2025-12-01 23:29:59 --> Could not find the language line "recommended"
