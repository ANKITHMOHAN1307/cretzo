<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-19 00:02:38 --> Could not find the language line "recommended"
ERROR - 2025-12-19 01:02:11 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 01:02:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 01:02:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 01:42:22 --> Could not find the language line "email_us"
ERROR - 2025-12-19 01:42:24 --> Could not find the language line "recommended"
ERROR - 2025-12-19 02:53:55 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 02:53:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 02:53:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 04:48:25 --> Could not find the language line "email_us"
ERROR - 2025-12-19 06:24:38 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 06:24:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 06:24:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 07:09:19 --> Could not find the language line "recommended"
ERROR - 2025-12-19 09:37:30 --> Could not find the language line "email_us"
ERROR - 2025-12-19 10:09:11 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 10:09:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 10:09:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 10:37:02 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 10:37:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 10:37:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 13:16:58 --> Could not find the language line "recommended"
ERROR - 2025-12-19 14:14:23 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 14:14:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 14:14:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 14:29:45 --> Could not find the language line "recommended"
ERROR - 2025-12-19 15:07:52 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 15:07:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 15:07:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 17:23:22 --> Could not find the language line "check_availability"
ERROR - 2025-12-19 17:23:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 17:23:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-19 20:16:26 --> Could not find the language line "recommended"
