<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-07 16:36:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'id21984800_cretzo'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 16:36:50 --> Unable to connect to the database
ERROR - 2025-09-07 16:42:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'id21984800_cretzo'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 16:42:55 --> Unable to connect to the database
ERROR - 2025-09-07 16:54:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'id21984800_cretzo'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 16:54:56 --> Unable to connect to the database
ERROR - 2025-09-07 17:07:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 17:07:54 --> Unable to connect to the database
ERROR - 2025-09-07 17:15:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 17:15:54 --> Unable to connect to the database
ERROR - 2025-09-07 17:15:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 17:15:58 --> Unable to connect to the database
ERROR - 2025-09-07 17:21:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 17:21:44 --> Unable to connect to the database
ERROR - 2025-09-07 18:33:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 18:33:31 --> Unable to connect to the database
ERROR - 2025-09-07 18:38:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 18:38:59 --> Unable to connect to the database
ERROR - 2025-09-07 19:00:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 19:00:14 --> Unable to connect to the database
ERROR - 2025-09-07 19:02:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 19:02:16 --> Unable to connect to the database
ERROR - 2025-09-07 19:22:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 19:22:04 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:53 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:53 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:53 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:53 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:53 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:53 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:54 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:55 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:55 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:55 --> Unable to connect to the database
ERROR - 2025-09-07 20:26:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 20:26:55 --> Unable to connect to the database
ERROR - 2025-09-07 22:20:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 22:20:31 --> Unable to connect to the database
ERROR - 2025-09-07 22:48:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 22:48:50 --> Unable to connect to the database
ERROR - 2025-09-07 23:05:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 23:05:46 --> Unable to connect to the database
ERROR - 2025-09-07 23:23:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 23:23:00 --> Unable to connect to the database
ERROR - 2025-09-07 23:27:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 23:27:28 --> Unable to connect to the database
ERROR - 2025-09-07 23:27:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 23:27:42 --> Unable to connect to the database
ERROR - 2025-09-07 23:33:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cretzo_new'@'localhost' (using password: YES) /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-09-07 23:33:00 --> Unable to connect to the database
