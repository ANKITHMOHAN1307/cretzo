<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-10 00:40:09 --> Could not find the language line "email_us"
ERROR - 2025-11-10 01:17:28 --> Could not find the language line "recommended"
ERROR - 2025-11-10 01:54:26 --> Could not find the language line "recommended"
ERROR - 2025-11-10 02:36:40 --> Could not find the language line "recommended"
ERROR - 2025-11-10 03:04:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 03:04:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 03:04:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 03:13:16 --> Could not find the language line "email_us"
ERROR - 2025-11-10 03:49:58 --> Could not find the language line "recommended"
ERROR - 2025-11-10 04:30:53 --> Could not find the language line "recommended"
ERROR - 2025-11-10 04:32:24 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 04:32:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 04:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 05:09:03 --> Could not find the language line "recommended"
ERROR - 2025-11-10 05:41:50 --> Could not find the language line "recommended"
ERROR - 2025-11-10 05:45:18 --> Could not find the language line "recommended"
ERROR - 2025-11-10 06:11:02 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 06:11:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 06:11:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 06:26:36 --> Could not find the language line "recommended"
ERROR - 2025-11-10 07:04:17 --> Could not find the language line "email_us"
ERROR - 2025-11-10 07:39:18 --> Could not find the language line "recommended"
ERROR - 2025-11-10 07:45:08 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 07:45:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 07:45:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 08:18:17 --> Could not find the language line "recommended"
ERROR - 2025-11-10 08:30:14 --> Could not find the language line "recommended"
ERROR - 2025-11-10 08:58:17 --> Could not find the language line "recommended"
ERROR - 2025-11-10 09:35:32 --> Could not find the language line "recommended"
ERROR - 2025-11-10 10:12:16 --> Could not find the language line "recommended"
ERROR - 2025-11-10 10:56:37 --> Could not find the language line "recommended"
ERROR - 2025-11-10 11:33:57 --> Could not find the language line "email_us"
ERROR - 2025-11-10 12:04:30 --> Could not find the language line "recommended"
ERROR - 2025-11-10 12:10:50 --> Could not find the language line "recommended"
ERROR - 2025-11-10 12:52:16 --> Could not find the language line "recommended"
ERROR - 2025-11-10 13:27:39 --> Could not find the language line "recommended"
ERROR - 2025-11-10 14:02:45 --> Could not find the language line "recommended"
ERROR - 2025-11-10 14:43:32 --> Could not find the language line "email_us"
ERROR - 2025-11-10 15:00:08 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-10 15:00:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-10 15:00:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-10 15:00:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-11-10 15:00:09 --> Could not find the language line "recommended"
ERROR - 2025-11-10 15:19:40 --> Could not find the language line "recommended"
ERROR - 2025-11-10 16:06:35 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 16:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 16:06:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 16:07:31 --> Could not find the language line "recommended"
ERROR - 2025-11-10 16:32:41 --> Could not find the language line "recommended"
ERROR - 2025-11-10 17:11:02 --> Could not find the language line "email_us"
ERROR - 2025-11-10 17:25:35 --> Could not find the language line "recommended"
ERROR - 2025-11-10 17:25:39 --> Could not find the language line "recommended"
ERROR - 2025-11-10 17:25:44 --> Could not find the language line "recommended"
ERROR - 2025-11-10 17:45:50 --> Could not find the language line "recommended"
ERROR - 2025-11-10 18:26:12 --> Could not find the language line "recommended"
ERROR - 2025-11-10 19:01:55 --> Could not find the language line "recommended"
ERROR - 2025-11-10 19:37:55 --> Could not find the language line "recommended"
ERROR - 2025-11-10 20:14:00 --> Could not find the language line "recommended"
ERROR - 2025-11-10 20:50:20 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 20:50:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 20:50:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 20:56:37 --> Could not find the language line "recommended"
ERROR - 2025-11-10 21:33:43 --> Could not find the language line "email_us"
ERROR - 2025-11-10 22:11:00 --> Could not find the language line "recommended"
ERROR - 2025-11-10 22:52:44 --> Could not find the language line "recommended"
ERROR - 2025-11-10 22:58:39 --> Could not find the language line "recommended"
ERROR - 2025-11-10 23:27:32 --> Could not find the language line "recommended"
ERROR - 2025-11-10 23:54:22 --> Could not find the language line "check_availability"
ERROR - 2025-11-10 23:54:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-10 23:54:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
