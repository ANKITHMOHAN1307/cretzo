<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-15 00:53:28 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 00:53:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 00:53:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 00:53:29 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 00:53:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 00:53:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 00:53:30 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 00:53:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 00:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 01:04:19 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 01:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 01:04:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 01:05:36 --> Could not find the language line "recommended"
ERROR - 2025-10-15 02:28:47 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 02:55:30 --> Could not find the language line "recommended"
ERROR - 2025-10-15 03:08:28 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 03:08:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 03:08:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 03:40:00 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 03:40:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 03:40:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 03:59:12 --> Could not find the language line "recommended"
ERROR - 2025-10-15 04:53:33 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 04:53:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 04:53:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 05:36:38 --> Could not find the language line "recommended"
ERROR - 2025-10-15 05:37:59 --> Could not find the language line "recommended"
ERROR - 2025-10-15 06:16:14 --> Could not find the language line "recommended"
ERROR - 2025-10-15 06:51:27 --> Could not find the language line "recommended"
ERROR - 2025-10-15 06:51:29 --> Could not find the language line "recommended"
ERROR - 2025-10-15 06:59:13 --> Could not find the language line "recommended"
ERROR - 2025-10-15 07:17:17 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 07:17:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 07:17:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 08:10:49 --> Could not find the language line "compare"
ERROR - 2025-10-15 10:14:26 --> Could not find the language line "recommended"
ERROR - 2025-10-15 10:52:34 --> Could not find the language line "recommended"
ERROR - 2025-10-15 12:55:09 --> Could not find the language line "recommended"
ERROR - 2025-10-15 12:59:00 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 12:59:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 12:59:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 13:05:44 --> Could not find the language line "recommended"
ERROR - 2025-10-15 14:02:25 --> Could not find the language line "recommended"
ERROR - 2025-10-15 14:42:19 --> Could not find the language line "recommended"
ERROR - 2025-10-15 14:42:19 --> Could not find the language line "recommended"
ERROR - 2025-10-15 15:17:50 --> Could not find the language line "recommended"
ERROR - 2025-10-15 15:32:46 --> Could not find the language line "recommended"
ERROR - 2025-10-15 15:51:49 --> Could not find the language line "recommended"
ERROR - 2025-10-15 16:23:53 --> Could not find the language line "recommended"
ERROR - 2025-10-15 16:44:25 --> Could not find the language line "recommended"
ERROR - 2025-10-15 17:14:09 --> Could not find the language line "recommended"
ERROR - 2025-10-15 17:41:59 --> Could not find the language line "recommended"
ERROR - 2025-10-15 17:47:44 --> Could not find the language line "recommended"
ERROR - 2025-10-15 18:51:05 --> Could not find the language line "recommended"
ERROR - 2025-10-15 19:25:17 --> Could not find the language line "recommended"
ERROR - 2025-10-15 19:26:14 --> Could not find the language line "recommended"
ERROR - 2025-10-15 19:26:15 --> Could not find the language line "recommended"
ERROR - 2025-10-15 19:26:17 --> Could not find the language line "recommended"
ERROR - 2025-10-15 19:38:31 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 19:38:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 19:38:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 20:25:51 --> Could not find the language line "check_availability"
ERROR - 2025-10-15 20:25:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 20:25:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-15 22:29:33 --> Could not find the language line "recommended"
