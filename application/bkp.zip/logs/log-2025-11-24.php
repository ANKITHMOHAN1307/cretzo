<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-24 00:07:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 00:07:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 00:07:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 00:21:38 --> Could not find the language line "email_us"
ERROR - 2025-11-24 00:22:59 --> Could not find the language line "recommended"
ERROR - 2025-11-24 00:43:41 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 00:43:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 00:43:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 01:00:52 --> Could not find the language line "recommended"
ERROR - 2025-11-24 01:01:13 --> Could not find the language line "recommended"
ERROR - 2025-11-24 01:16:35 --> Could not find the language line "recommended"
ERROR - 2025-11-24 01:33:07 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 01:33:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 01:33:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 01:48:55 --> Could not find the language line "recommended"
ERROR - 2025-11-24 02:04:19 --> Could not find the language line "recommended"
ERROR - 2025-11-24 02:21:04 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 02:21:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 02:21:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 02:39:15 --> Could not find the language line "recommended"
ERROR - 2025-11-24 02:55:42 --> Could not find the language line "recommended"
ERROR - 2025-11-24 03:11:26 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 03:11:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 03:11:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 03:26:05 --> Could not find the language line "recommended"
ERROR - 2025-11-24 03:26:27 --> Could not find the language line "recommended"
ERROR - 2025-11-24 03:40:40 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 03:40:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 03:40:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 03:55:17 --> Could not find the language line "recommended"
ERROR - 2025-11-24 04:09:55 --> Could not find the language line "recommended"
ERROR - 2025-11-24 04:24:03 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 04:24:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 04:24:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 04:25:03 --> Could not find the language line "recommended"
ERROR - 2025-11-24 04:42:35 --> Could not find the language line "recommended"
ERROR - 2025-11-24 04:56:40 --> Could not find the language line "recommended"
ERROR - 2025-11-24 05:10:05 --> Could not find the language line "recommended"
ERROR - 2025-11-24 05:22:39 --> Could not find the language line "recommended"
ERROR - 2025-11-24 05:35:11 --> Could not find the language line "recommended"
ERROR - 2025-11-24 05:59:44 --> Could not find the language line "recommended"
ERROR - 2025-11-24 06:11:38 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 06:11:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 06:11:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 06:12:40 --> Could not find the language line "recommended"
ERROR - 2025-11-24 06:27:11 --> Could not find the language line "recommended"
ERROR - 2025-11-24 06:43:10 --> Could not find the language line "recommended"
ERROR - 2025-11-24 06:56:54 --> Could not find the language line "recommended"
ERROR - 2025-11-24 06:58:46 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 06:58:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 06:58:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 07:09:00 --> Could not find the language line "recommended"
ERROR - 2025-11-24 07:21:51 --> Could not find the language line "recommended"
ERROR - 2025-11-24 07:33:50 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 07:33:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 07:33:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 07:45:37 --> Could not find the language line "recommended"
ERROR - 2025-11-24 07:57:11 --> Could not find the language line "recommended"
ERROR - 2025-11-24 08:22:27 --> Could not find the language line "recommended"
ERROR - 2025-11-24 08:38:05 --> Could not find the language line "recommended"
ERROR - 2025-11-24 08:51:11 --> Could not find the language line "recommended"
ERROR - 2025-11-24 09:03:32 --> Could not find the language line "recommended"
ERROR - 2025-11-24 09:15:41 --> Could not find the language line "recommended"
ERROR - 2025-11-24 09:28:03 --> Could not find the language line "recommended"
ERROR - 2025-11-24 09:40:50 --> Could not find the language line "recommended"
ERROR - 2025-11-24 09:53:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 09:53:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 09:53:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 10:06:09 --> Could not find the language line "recommended"
ERROR - 2025-11-24 10:19:18 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 10:19:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 10:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 10:30:18 --> Could not find the language line "email_us"
ERROR - 2025-11-24 10:30:20 --> Could not find the language line "recommended"
ERROR - 2025-11-24 10:35:19 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 10:35:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 10:35:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 10:36:32 --> Could not find the language line "recommended"
ERROR - 2025-11-24 10:51:01 --> Could not find the language line "recommended"
ERROR - 2025-11-24 11:04:35 --> Could not find the language line "recommended"
ERROR - 2025-11-24 11:15:23 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 11:15:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 11:15:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 11:17:23 --> Could not find the language line "recommended"
ERROR - 2025-11-24 11:18:26 --> Could not find the language line "recommended"
ERROR - 2025-11-24 11:24:37 --> Could not find the language line "recommended"
ERROR - 2025-11-24 11:43:48 --> Could not find the language line "recommended"
ERROR - 2025-11-24 12:36:48 --> Could not find the language line "recommended"
ERROR - 2025-11-24 12:51:03 --> Could not find the language line "recommended"
ERROR - 2025-11-24 13:03:31 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 13:03:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 13:16:17 --> Could not find the language line "recommended"
ERROR - 2025-11-24 13:28:13 --> Could not find the language line "recommended"
ERROR - 2025-11-24 13:40:13 --> Could not find the language line "recommended"
ERROR - 2025-11-24 13:52:22 --> Could not find the language line "recommended"
ERROR - 2025-11-24 14:03:55 --> Could not find the language line "recommended"
ERROR - 2025-11-24 14:15:37 --> Could not find the language line "recommended"
ERROR - 2025-11-24 14:28:58 --> Could not find the language line "section"
ERROR - 2025-11-24 14:28:58 --> Could not find the language line "section"
ERROR - 2025-11-24 14:28:58 --> Could not find the language line "recommended"
ERROR - 2025-11-24 14:43:23 --> Could not find the language line "section"
ERROR - 2025-11-24 14:43:23 --> Could not find the language line "section"
ERROR - 2025-11-24 14:43:23 --> Could not find the language line "recommended"
ERROR - 2025-11-24 14:56:21 --> Could not find the language line "recommended"
ERROR - 2025-11-24 15:20:24 --> Could not find the language line "section"
ERROR - 2025-11-24 15:20:24 --> Could not find the language line "section"
ERROR - 2025-11-24 15:20:24 --> Could not find the language line "recommended"
ERROR - 2025-11-24 15:31:42 --> Could not find the language line "recommended"
ERROR - 2025-11-24 15:42:56 --> Could not find the language line "recommended"
ERROR - 2025-11-24 15:56:18 --> Could not find the language line "recommended"
ERROR - 2025-11-24 15:59:23 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 15:59:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 15:59:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 16:19:06 --> Could not find the language line "recommended"
ERROR - 2025-11-24 16:31:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-11-24 16:31:02 --> Could not find the language line "recommended"
ERROR - 2025-11-24 16:32:36 --> Could not find the language line "recommended"
ERROR - 2025-11-24 16:45:42 --> Could not find the language line "recommended"
ERROR - 2025-11-24 16:55:07 --> Could not find the language line "recommended"
ERROR - 2025-11-24 17:06:47 --> Could not find the language line "recommended"
ERROR - 2025-11-24 17:16:00 --> Could not find the language line "recommended"
ERROR - 2025-11-24 17:17:09 --> Could not find the language line "recommended"
ERROR - 2025-11-24 17:28:11 --> Could not find the language line "recommended"
ERROR - 2025-11-24 17:39:26 --> Could not find the language line "recommended"
ERROR - 2025-11-24 17:49:52 --> Could not find the language line "recommended"
ERROR - 2025-11-24 18:00:40 --> Could not find the language line "recommended"
ERROR - 2025-11-24 18:11:26 --> Could not find the language line "recommended"
ERROR - 2025-11-24 18:21:47 --> Could not find the language line "recommended"
ERROR - 2025-11-24 18:35:01 --> Could not find the language line "recommended"
ERROR - 2025-11-24 18:47:38 --> Could not find the language line "recommended"
ERROR - 2025-11-24 18:59:15 --> Could not find the language line "recommended"
ERROR - 2025-11-24 19:10:01 --> Could not find the language line "recommended"
ERROR - 2025-11-24 19:21:30 --> Could not find the language line "recommended"
ERROR - 2025-11-24 19:42:52 --> Could not find the language line "recommended"
ERROR - 2025-11-24 19:53:33 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:04:47 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:15:19 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:27:24 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:40:12 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:48:59 --> Could not find the language line "section"
ERROR - 2025-11-24 20:48:59 --> Could not find the language line "section"
ERROR - 2025-11-24 20:48:59 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:49:15 --> Could not find the language line "section"
ERROR - 2025-11-24 20:49:15 --> Could not find the language line "section"
ERROR - 2025-11-24 20:49:15 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:49:20 --> Could not find the language line "section"
ERROR - 2025-11-24 20:49:20 --> Could not find the language line "section"
ERROR - 2025-11-24 20:49:20 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:49:23 --> Could not find the language line "section"
ERROR - 2025-11-24 20:49:23 --> Could not find the language line "section"
ERROR - 2025-11-24 20:49:23 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:49:56 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:50:15 --> Could not find the language line "login_heading"
ERROR - 2025-11-24 20:50:15 --> Could not find the language line "login_password_label"
ERROR - 2025-11-24 20:50:16 --> Could not find the language line "login_heading"
ERROR - 2025-11-24 20:50:16 --> Could not find the language line "login_password_label"
ERROR - 2025-11-24 20:51:05 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:51:12 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:51:14 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:52:03 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:52:13 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:53:46 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:53:50 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:53:56 --> Could not find the language line "recommended"
ERROR - 2025-11-24 20:54:05 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:01:45 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:12:10 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:23:19 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:29:55 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 21:29:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 21:29:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 21:34:32 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:45:32 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:47:00 --> Could not find the language line "compare"
ERROR - 2025-11-24 21:47:32 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:47:59 --> Could not find the language line "return_policy"
ERROR - 2025-11-24 21:47:59 --> Could not find the language line "return_policy"
ERROR - 2025-11-24 21:48:10 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-24 21:48:10 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-24 21:50:17 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 21:56:42 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:58:35 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:58:39 --> Could not find the language line "recommended"
ERROR - 2025-11-24 21:58:54 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 22:00:20 --> Could not find the language line "recommended"
ERROR - 2025-11-24 22:00:28 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 22:00:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 22:00:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 22:06:46 --> Could not find the language line "login_heading"
ERROR - 2025-11-24 22:06:46 --> Could not find the language line "login_password_label"
ERROR - 2025-11-24 22:06:54 --> Could not find the language line "login_heading"
ERROR - 2025-11-24 22:06:54 --> Could not find the language line "login_password_label"
ERROR - 2025-11-24 22:07:04 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:07:04 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:07:04 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:07:04 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:07:39 --> Could not find the language line "email_us"
ERROR - 2025-11-24 22:08:01 --> Severity: Warning --> Undefined variable $sort /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:08:01 --> Severity: Warning --> Undefined variable $limit /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:08:01 --> Severity: Warning --> Undefined variable $offset /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:08:47 --> Severity: Warning --> Undefined variable $sort /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:08:47 --> Severity: Warning --> Undefined variable $limit /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:08:47 --> Severity: Warning --> Undefined variable $offset /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:09:57 --> Severity: Warning --> Undefined variable $sort /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:09:57 --> Severity: Warning --> Undefined variable $limit /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:09:57 --> Severity: Warning --> Undefined variable $offset /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:12:20 --> Severity: Warning --> Undefined variable $sort /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:12:20 --> Severity: Warning --> Undefined variable $limit /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:12:20 --> Severity: Warning --> Undefined variable $offset /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-11-24 22:16:12 --> Could not find the language line "login_heading"
ERROR - 2025-11-24 22:16:12 --> Could not find the language line "login_password_label"
ERROR - 2025-11-24 22:16:15 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:16:15 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:16:15 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:16:15 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:17:12 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:17:12 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:17:12 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:17:12 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:19:01 --> Could not find the language line "recommended"
ERROR - 2025-11-24 22:19:07 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:19:07 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:19:07 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:19:07 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:19:15 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:19:15 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:19:15 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:19:15 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:22:01 --> Could not find the language line "check_availability"
ERROR - 2025-11-24 22:22:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 22:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-24 22:22:03 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:22:03 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:22:03 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:22:03 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:22:15 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:22:15 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:22:15 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:22:15 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:28:19 --> Could not find the language line "support_chat"
ERROR - 2025-11-24 22:28:19 --> Could not find the language line "label_close"
ERROR - 2025-11-24 22:28:19 --> Could not find the language line "label_search"
ERROR - 2025-11-24 22:28:19 --> Could not find the language line "label_search_result"
ERROR - 2025-11-24 22:44:56 --> Could not find the language line "recommended"
ERROR - 2025-11-24 22:56:18 --> Could not find the language line "email_us"
ERROR - 2025-11-24 23:07:35 --> Could not find the language line "recommended"
ERROR - 2025-11-24 23:29:45 --> Could not find the language line "recommended"
ERROR - 2025-11-24 23:40:42 --> Could not find the language line "recommended"
ERROR - 2025-11-24 23:51:23 --> Could not find the language line "recommended"
