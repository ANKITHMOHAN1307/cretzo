<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-21 02:01:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-09-21 02:01:32 --> Could not find the language line "recommended"
ERROR - 2025-09-21 04:13:47 --> Could not find the language line "recommended"
ERROR - 2025-09-21 04:51:18 --> Could not find the language line "email_us"
ERROR - 2025-09-21 04:59:26 --> Could not find the language line "email_us"
ERROR - 2025-09-21 06:14:34 --> Could not find the language line "recommended"
ERROR - 2025-09-21 06:42:30 --> Could not find the language line "recommended"
ERROR - 2025-09-21 09:04:28 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-21 09:04:28 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-21 09:04:28 --> Could not find the language line "check_availability"
ERROR - 2025-09-21 09:04:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-21 09:04:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-21 09:04:48 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-21 09:04:48 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-21 09:04:48 --> Could not find the language line "check_availability"
ERROR - 2025-09-21 09:04:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-21 09:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-21 13:25:36 --> Could not find the language line "section"
ERROR - 2025-09-21 13:25:36 --> Could not find the language line "section"
ERROR - 2025-09-21 13:25:36 --> Could not find the language line "recommended"
ERROR - 2025-09-21 13:32:39 --> Could not find the language line "recommended"
ERROR - 2025-09-21 13:37:32 --> Could not find the language line "recommended"
ERROR - 2025-09-21 15:30:36 --> Could not find the language line "recommended"
ERROR - 2025-09-21 15:30:39 --> Could not find the language line "recommended"
ERROR - 2025-09-21 16:01:30 --> Could not find the language line "section"
ERROR - 2025-09-21 16:01:30 --> Could not find the language line "section"
ERROR - 2025-09-21 16:01:30 --> Could not find the language line "recommended"
ERROR - 2025-09-21 16:48:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-09-21 16:48:13 --> Could not find the language line "recommended"
ERROR - 2025-09-21 17:51:38 --> Could not find the language line "email_us"
ERROR - 2025-09-21 17:51:39 --> Could not find the language line "recommended"
ERROR - 2025-09-21 19:55:02 --> Could not find the language line "recommended"
ERROR - 2025-09-21 20:00:04 --> Could not find the language line "recommended"
ERROR - 2025-09-21 20:11:06 --> Could not find the language line "recommended"
ERROR - 2025-09-21 21:27:54 --> Could not find the language line "recommended"
ERROR - 2025-09-21 21:36:55 --> Could not find the language line "recommended"
ERROR - 2025-09-21 23:11:18 --> Could not find the language line "recommended"
