<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-09 02:56:40 --> Could not find the language line "recommended"
ERROR - 2025-09-09 03:55:52 --> Could not find the language line "recommended"
ERROR - 2025-09-09 06:50:49 --> Could not find the language line "recommended"
ERROR - 2025-09-09 06:50:50 --> Could not find the language line "recommended"
ERROR - 2025-09-09 07:43:55 --> Could not find the language line "email_us"
ERROR - 2025-09-09 07:43:56 --> Could not find the language line "recommended"
ERROR - 2025-09-09 07:53:00 --> Could not find the language line "email_us"
ERROR - 2025-09-09 07:53:04 --> Could not find the language line "email_us"
ERROR - 2025-09-09 08:52:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-09-09 08:52:38 --> Could not find the language line "recommended"
ERROR - 2025-09-09 08:59:08 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-09 08:59:08 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-09-09 08:59:08 --> Could not find the language line "check_availability"
ERROR - 2025-09-09 08:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-09 08:59:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-09 11:26:19 --> Could not find the language line "check_availability"
ERROR - 2025-09-09 11:28:41 --> Could not find the language line "login_heading"
ERROR - 2025-09-09 11:28:41 --> Could not find the language line "login_password_label"
ERROR - 2025-09-09 11:28:43 --> Could not find the language line "support_chat"
ERROR - 2025-09-09 11:28:43 --> Could not find the language line "label_close"
ERROR - 2025-09-09 11:28:43 --> Could not find the language line "label_search"
ERROR - 2025-09-09 11:28:43 --> Could not find the language line "label_search_result"
ERROR - 2025-09-09 11:29:59 --> Could not find the language line "login_heading"
ERROR - 2025-09-09 11:29:59 --> Could not find the language line "login_password_label"
ERROR - 2025-09-09 11:29:59 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('45.118.156.40', '9910919480', 1757397599)
ERROR - 2025-09-09 11:30:28 --> Could not find the language line "login_heading"
ERROR - 2025-09-09 11:30:28 --> Could not find the language line "login_password_label"
ERROR - 2025-09-09 11:30:30 --> Could not find the language line "support_chat"
ERROR - 2025-09-09 11:30:30 --> Could not find the language line "label_close"
ERROR - 2025-09-09 11:30:30 --> Could not find the language line "label_search"
ERROR - 2025-09-09 11:30:30 --> Could not find the language line "label_search_result"
ERROR - 2025-09-09 11:44:54 --> Could not find the language line "email_us"
ERROR - 2025-09-09 13:30:50 --> Could not find the language line "recommended"
ERROR - 2025-09-09 15:11:02 --> Could not find the language line "recommended"
ERROR - 2025-09-09 15:11:02 --> Could not find the language line "recommended"
ERROR - 2025-09-09 16:34:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/helpers/function_helper.php 3265
ERROR - 2025-09-09 16:34:48 --> Could not find the language line "recommended"
ERROR - 2025-09-09 16:47:05 --> Could not find the language line "recommended"
ERROR - 2025-09-09 18:02:19 --> Could not find the language line "recommended"
ERROR - 2025-09-09 19:12:44 --> Could not find the language line "recommended"
ERROR - 2025-09-09 20:57:32 --> Could not find the language line "check_availability"
ERROR - 2025-09-09 20:57:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-09 20:57:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-09 21:12:13 --> Could not find the language line "recommended"
ERROR - 2025-09-09 22:03:06 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-09 22:03:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-09 22:03:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-09 22:03:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-09 22:03:07 --> Could not find the language line "recommended"
