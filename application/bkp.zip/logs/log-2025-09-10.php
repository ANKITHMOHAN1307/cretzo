<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-10 01:23:53 --> Could not find the language line "recommended"
ERROR - 2025-09-10 03:01:52 --> Could not find the language line "recommended"
ERROR - 2025-09-10 07:00:34 --> Could not find the language line "recommended"
ERROR - 2025-09-10 07:34:05 --> Could not find the language line "recommended"
ERROR - 2025-09-10 11:37:00 --> Could not find the language line "login_heading"
ERROR - 2025-09-10 11:37:00 --> Severity: Warning --> Undefined array key "identity" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 520
ERROR - 2025-09-10 11:37:00 --> Severity: Warning --> Undefined array key "identity" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 525
ERROR - 2025-09-10 11:37:00 --> Severity: Warning --> Undefined array key "type" /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 532
ERROR - 2025-09-10 11:37:00 --> Could not find the language line "login_password_label"
ERROR - 2025-09-10 11:37:00 --> Severity: error --> Exception: Call to undefined method Home::_render_page() /home/u554344800/domains/cretzo.com/public_html/application/controllers/Home.php 637
ERROR - 2025-09-10 11:37:52 --> Could not find the language line "recommended"
ERROR - 2025-09-10 12:21:11 --> Could not find the language line "login_heading"
ERROR - 2025-09-10 12:21:11 --> Could not find the language line "login_password_label"
ERROR - 2025-09-10 12:21:13 --> Could not find the language line "support_chat"
ERROR - 2025-09-10 12:21:13 --> Could not find the language line "label_close"
ERROR - 2025-09-10 12:21:13 --> Could not find the language line "label_search"
ERROR - 2025-09-10 12:21:13 --> Could not find the language line "label_search_result"
ERROR - 2025-09-10 12:21:17 --> Could not find the language line "promocodes"
ERROR - 2025-09-10 12:21:22 --> Could not find the language line "support_chat"
ERROR - 2025-09-10 12:21:22 --> Could not find the language line "label_close"
ERROR - 2025-09-10 12:21:22 --> Could not find the language line "label_search"
ERROR - 2025-09-10 12:21:22 --> Could not find the language line "label_search_result"
ERROR - 2025-09-10 12:22:15 --> Severity: Warning --> Undefined variable $sort /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-09-10 12:22:15 --> Severity: Warning --> Undefined variable $limit /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-09-10 12:22:15 --> Severity: Warning --> Undefined variable $offset /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-09-10 12:22:21 --> Severity: Warning --> Undefined variable $sort /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-09-10 12:22:21 --> Severity: Warning --> Undefined variable $limit /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-09-10 12:22:21 --> Severity: Warning --> Undefined variable $offset /home/u554344800/domains/cretzo.com/public_html/application/models/Media_model.php 117
ERROR - 2025-09-10 12:30:35 --> Could not find the language line "recommended"
ERROR - 2025-09-10 12:44:40 --> Could not find the language line "recommended"
ERROR - 2025-09-10 13:33:40 --> Could not find the language line "recommended"
ERROR - 2025-09-10 15:18:25 --> Could not find the language line "recommended"
ERROR - 2025-09-10 17:14:43 --> Could not find the language line "check_availability"
ERROR - 2025-09-10 17:14:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-10 17:14:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-10 17:34:00 --> Could not find the language line "recommended"
ERROR - 2025-09-10 18:19:47 --> Could not find the language line "check_availability"
ERROR - 2025-09-10 21:52:39 --> Could not find the language line "recommended"
ERROR - 2025-09-10 21:54:59 --> Could not find the language line "check_availability"
ERROR - 2025-09-10 21:54:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-10 21:54:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
