<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-25 00:30:22 --> Could not find the language line "recommended"
ERROR - 2025-10-25 00:43:47 --> Could not find the language line "recommended"
ERROR - 2025-10-25 00:55:46 --> Could not find the language line "recommended"
ERROR - 2025-10-25 01:06:54 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 01:06:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 01:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 01:17:51 --> Could not find the language line "recommended"
ERROR - 2025-10-25 01:26:16 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 01:26:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 01:26:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 01:29:55 --> Could not find the language line "recommended"
ERROR - 2025-10-25 01:41:25 --> Could not find the language line "recommended"
ERROR - 2025-10-25 02:20:37 --> Could not find the language line "recommended"
ERROR - 2025-10-25 02:42:18 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 02:42:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 02:42:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 02:55:15 --> Could not find the language line "recommended"
ERROR - 2025-10-25 02:55:36 --> Could not find the language line "recommended"
ERROR - 2025-10-25 03:04:39 --> Could not find the language line "recommended"
ERROR - 2025-10-25 03:25:31 --> Could not find the language line "recommended"
ERROR - 2025-10-25 03:25:43 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 03:25:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 03:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 03:39:24 --> Could not find the language line "email_us"
ERROR - 2025-10-25 03:50:13 --> Could not find the language line "recommended"
ERROR - 2025-10-25 04:12:15 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 04:12:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 04:12:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 04:27:38 --> Could not find the language line "recommended"
ERROR - 2025-10-25 04:35:13 --> Could not find the language line "email_us"
ERROR - 2025-10-25 04:41:32 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 04:45:54 --> Could not find the language line "recommended"
ERROR - 2025-10-25 04:54:49 --> Could not find the language line "recommended"
ERROR - 2025-10-25 05:35:20 --> Could not find the language line "recommended"
ERROR - 2025-10-25 05:49:11 --> Could not find the language line "recommended"
ERROR - 2025-10-25 06:24:01 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 06:24:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 06:24:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 06:50:14 --> Could not find the language line "recommended"
ERROR - 2025-10-25 06:58:28 --> Could not find the language line "recommended"
ERROR - 2025-10-25 07:05:45 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 07:10:59 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-25 07:10:59 --> Could not find the language line "shipping_policy"
ERROR - 2025-10-25 07:13:40 --> Could not find the language line "section"
ERROR - 2025-10-25 07:13:40 --> Could not find the language line "section"
ERROR - 2025-10-25 07:13:40 --> Could not find the language line "recommended"
ERROR - 2025-10-25 07:17:19 --> Could not find the language line "recommended"
ERROR - 2025-10-25 07:17:54 --> Could not find the language line "recommended"
ERROR - 2025-10-25 07:21:33 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 07:21:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 07:21:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 07:23:18 --> Could not find the language line "recommended"
ERROR - 2025-10-25 07:45:23 --> Could not find the language line "recommended"
ERROR - 2025-10-25 08:08:30 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 08:08:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 08:08:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 08:08:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 08:08:31 --> Could not find the language line "recommended"
ERROR - 2025-10-25 08:18:37 --> Could not find the language line "recommended"
ERROR - 2025-10-25 08:41:01 --> Could not find the language line "recommended"
ERROR - 2025-10-25 08:48:44 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 08:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 08:48:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 09:03:01 --> Could not find the language line "recommended"
ERROR - 2025-10-25 09:23:57 --> Could not find the language line "recommended"
ERROR - 2025-10-25 10:48:53 --> Could not find the language line "email_us"
ERROR - 2025-10-25 11:55:21 --> Could not find the language line "recommended"
ERROR - 2025-10-25 13:27:29 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 13:27:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 13:27:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 13:27:30 --> Could not find the language line "recommended"
ERROR - 2025-10-25 13:34:37 --> Could not find the language line "recommended"
ERROR - 2025-10-25 13:54:19 --> Could not find the language line "recommended"
ERROR - 2025-10-25 16:20:24 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 16:20:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 16:20:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 16:20:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-10-25 16:20:26 --> Could not find the language line "recommended"
ERROR - 2025-10-25 17:20:48 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 17:20:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 19:56:17 --> Could not find the language line "recommended"
ERROR - 2025-10-25 20:26:13 --> Could not find the language line "recommended"
ERROR - 2025-10-25 20:40:09 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 20:40:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 20:40:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 21:06:11 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 21:06:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 21:06:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 21:51:37 --> Could not find the language line "section"
ERROR - 2025-10-25 21:51:37 --> Could not find the language line "section"
ERROR - 2025-10-25 21:51:37 --> Could not find the language line "recommended"
ERROR - 2025-10-25 21:51:55 --> Could not find the language line "recommended"
ERROR - 2025-10-25 22:31:35 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 22:31:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 22:31:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 22:49:30 --> Could not find the language line "recommended"
ERROR - 2025-10-25 23:01:30 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 23:01:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 23:01:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 23:13:15 --> Could not find the language line "compare"
ERROR - 2025-10-25 23:37:58 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 23:37:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 23:37:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 23:41:18 --> Could not find the language line "check_availability"
ERROR - 2025-10-25 23:41:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-25 23:41:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
