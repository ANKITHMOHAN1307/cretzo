<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-26 00:56:52 --> Could not find the language line "recommended"
ERROR - 2025-09-26 01:38:01 --> Could not find the language line "recommended"
ERROR - 2025-09-26 03:03:25 --> Could not find the language line "recommended"
ERROR - 2025-09-26 03:16:55 --> Could not find the language line "recommended"
ERROR - 2025-09-26 07:18:18 --> Could not find the language line "recommended"
ERROR - 2025-09-26 07:59:19 --> Could not find the language line "recommended"
ERROR - 2025-09-26 10:34:59 --> Could not find the language line "recommended"
ERROR - 2025-09-26 12:13:14 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-26 12:13:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-26 12:13:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-26 12:13:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-09-26 12:13:16 --> Could not find the language line "recommended"
ERROR - 2025-09-26 14:23:45 --> Could not find the language line "recommended"
ERROR - 2025-09-26 15:56:05 --> Could not find the language line "recommended"
ERROR - 2025-09-26 16:29:35 --> Could not find the language line "recommended"
ERROR - 2025-09-26 18:10:47 --> Could not find the language line "check_availability"
ERROR - 2025-09-26 18:10:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:10:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:33:09 --> Could not find the language line "check_availability"
ERROR - 2025-09-26 18:33:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:33:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:47:07 --> Could not find the language line "check_availability"
ERROR - 2025-09-26 18:47:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:47:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:59:04 --> Could not find the language line "check_availability"
ERROR - 2025-09-26 18:59:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 18:59:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 19:11:01 --> Could not find the language line "check_availability"
ERROR - 2025-09-26 19:11:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 19:11:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 19:35:36 --> Could not find the language line "check_availability"
ERROR - 2025-09-26 19:35:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 19:35:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-09-26 20:13:16 --> Could not find the language line "recommended"
ERROR - 2025-09-26 20:29:45 --> Could not find the language line "recommended"
ERROR - 2025-09-26 20:44:02 --> Could not find the language line "recommended"
ERROR - 2025-09-26 20:57:48 --> Could not find the language line "recommended"
ERROR - 2025-09-26 21:11:32 --> Could not find the language line "recommended"
ERROR - 2025-09-26 21:22:36 --> Could not find the language line "recommended"
ERROR - 2025-09-26 21:25:22 --> Could not find the language line "recommended"
ERROR - 2025-09-26 21:38:52 --> Could not find the language line "recommended"
ERROR - 2025-09-26 21:52:42 --> Could not find the language line "recommended"
ERROR - 2025-09-26 22:05:44 --> Could not find the language line "recommended"
ERROR - 2025-09-26 22:14:38 --> Could not find the language line "recommended"
ERROR - 2025-09-26 22:30:17 --> Could not find the language line "recommended"
ERROR - 2025-09-26 22:44:31 --> Could not find the language line "recommended"
ERROR - 2025-09-26 22:57:39 --> Could not find the language line "recommended"
ERROR - 2025-09-26 23:10:18 --> Could not find the language line "recommended"
ERROR - 2025-09-26 23:22:19 --> Could not find the language line "recommended"
ERROR - 2025-09-26 23:28:46 --> Could not find the language line "recommended"
ERROR - 2025-09-26 23:34:12 --> Could not find the language line "recommended"
ERROR - 2025-09-26 23:46:13 --> Could not find the language line "recommended"
ERROR - 2025-09-26 23:57:20 --> Could not find the language line "recommended"
