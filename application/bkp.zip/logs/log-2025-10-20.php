<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-20 00:27:05 --> Could not find the language line "recommended"
ERROR - 2025-10-20 00:36:22 --> Could not find the language line "recommended"
ERROR - 2025-10-20 01:08:55 --> Could not find the language line "recommended"
ERROR - 2025-10-20 01:48:18 --> Could not find the language line "recommended"
ERROR - 2025-10-20 02:31:11 --> Could not find the language line "recommended"
ERROR - 2025-10-20 03:09:43 --> Could not find the language line "recommended"
ERROR - 2025-10-20 03:10:29 --> Could not find the language line "section"
ERROR - 2025-10-20 03:10:29 --> Could not find the language line "section"
ERROR - 2025-10-20 03:10:29 --> Could not find the language line "recommended"
ERROR - 2025-10-20 03:10:34 --> Could not find the language line "email_us"
ERROR - 2025-10-20 03:10:56 --> Could not find the language line "email_us"
ERROR - 2025-10-20 03:48:22 --> Could not find the language line "recommended"
ERROR - 2025-10-20 04:27:35 --> Could not find the language line "recommended"
ERROR - 2025-10-20 04:45:00 --> Could not find the language line "recommended"
ERROR - 2025-10-20 04:57:35 --> Could not find the language line "recommended"
ERROR - 2025-10-20 05:02:48 --> Could not find the language line "recommended"
ERROR - 2025-10-20 05:18:57 --> Could not find the language line "recommended"
ERROR - 2025-10-20 06:08:38 --> Could not find the language line "recommended"
ERROR - 2025-10-20 06:13:20 --> Could not find the language line "recommended"
ERROR - 2025-10-20 06:36:44 --> Could not find the language line "email_us"
ERROR - 2025-10-20 07:17:03 --> Could not find the language line "recommended"
ERROR - 2025-10-20 07:58:30 --> Could not find the language line "recommended"
ERROR - 2025-10-20 07:59:03 --> Could not find the language line "recommended"
ERROR - 2025-10-20 08:31:35 --> Could not find the language line "recommended"
ERROR - 2025-10-20 09:56:38 --> Could not find the language line "recommended"
ERROR - 2025-10-20 09:56:38 --> Could not find the language line "recommended"
ERROR - 2025-10-20 10:43:53 --> Could not find the language line "recommended"
ERROR - 2025-10-20 11:18:30 --> Could not find the language line "section"
ERROR - 2025-10-20 11:18:30 --> Could not find the language line "section"
ERROR - 2025-10-20 11:18:30 --> Could not find the language line "recommended"
ERROR - 2025-10-20 11:18:56 --> Could not find the language line "email_us"
ERROR - 2025-10-20 11:19:16 --> Could not find the language line "email_us"
ERROR - 2025-10-20 12:14:52 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 12:40:54 --> Could not find the language line "section"
ERROR - 2025-10-20 12:40:54 --> Could not find the language line "section"
ERROR - 2025-10-20 12:40:54 --> Could not find the language line "recommended"
ERROR - 2025-10-20 13:16:56 --> Could not find the language line "email_us"
ERROR - 2025-10-20 13:21:20 --> Could not find the language line "section"
ERROR - 2025-10-20 13:21:20 --> Could not find the language line "section"
ERROR - 2025-10-20 13:21:20 --> Could not find the language line "recommended"
ERROR - 2025-10-20 14:23:09 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 14:23:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 14:23:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 14:38:39 --> Could not find the language line "recommended"
ERROR - 2025-10-20 15:10:22 --> Could not find the language line "recommended"
ERROR - 2025-10-20 15:42:22 --> Could not find the language line "recommended"
ERROR - 2025-10-20 16:18:21 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 16:18:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 16:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 16:53:21 --> Could not find the language line "section"
ERROR - 2025-10-20 16:53:21 --> Could not find the language line "section"
ERROR - 2025-10-20 16:53:21 --> Could not find the language line "recommended"
ERROR - 2025-10-20 17:28:00 --> Could not find the language line "compare"
ERROR - 2025-10-20 12:34:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home/u554344800/domains/cretzo.com/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-10-20 12:34:28 --> Unable to connect to the database
ERROR - 2025-10-20 18:38:42 --> Could not find the language line "recommended"
ERROR - 2025-10-20 18:40:01 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 18:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 18:40:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 18:57:44 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 18:57:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 18:57:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 19:02:53 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 19:02:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 19:02:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 19:45:38 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-20 19:45:38 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 323
ERROR - 2025-10-20 19:45:38 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 19:45:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 19:45:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 22:46:31 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 22:46:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 22:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 23:02:18 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 23:02:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 23:02:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 23:53:23 --> Could not find the language line "check_availability"
ERROR - 2025-10-20 23:53:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-10-20 23:53:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
