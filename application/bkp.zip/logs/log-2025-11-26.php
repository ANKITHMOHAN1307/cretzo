<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-26 00:37:55 --> Could not find the language line "check_availability"
ERROR - 2025-11-26 00:37:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 00:37:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 00:57:24 --> Could not find the language line "recommended"
ERROR - 2025-11-26 01:21:35 --> Could not find the language line "check_availability"
ERROR - 2025-11-26 01:21:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 01:21:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 03:47:56 --> Could not find the language line "section"
ERROR - 2025-11-26 03:47:56 --> Could not find the language line "section"
ERROR - 2025-11-26 03:47:56 --> Could not find the language line "recommended"
ERROR - 2025-11-26 03:58:57 --> Could not find the language line "email_us"
ERROR - 2025-11-26 04:52:37 --> Could not find the language line "recommended"
ERROR - 2025-11-26 05:44:25 --> Could not find the language line "recommended"
ERROR - 2025-11-26 06:15:27 --> Could not find the language line "email_us"
ERROR - 2025-11-26 07:29:17 --> Could not find the language line "email_us"
ERROR - 2025-11-26 07:29:17 --> Could not find the language line "recommended"
ERROR - 2025-11-26 07:29:18 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-26 07:29:18 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-26 07:29:18 --> Could not find the language line "return_policy"
ERROR - 2025-11-26 07:29:18 --> Could not find the language line "return_policy"
ERROR - 2025-11-26 07:29:18 --> Could not find the language line "compare"
ERROR - 2025-11-26 07:34:56 --> Could not find the language line "recommended"
ERROR - 2025-11-26 07:42:26 --> Could not find the language line "email_us"
ERROR - 2025-11-26 07:42:27 --> Could not find the language line "recommended"
ERROR - 2025-11-26 07:42:27 --> Could not find the language line "return_policy"
ERROR - 2025-11-26 07:42:27 --> Could not find the language line "return_policy"
ERROR - 2025-11-26 07:42:27 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-26 07:42:27 --> Could not find the language line "shipping_policy"
ERROR - 2025-11-26 07:42:28 --> Could not find the language line "compare"
ERROR - 2025-11-26 08:46:26 --> Could not find the language line "recommended"
ERROR - 2025-11-26 09:36:44 --> Could not find the language line "recommended"
ERROR - 2025-11-26 09:50:27 --> Could not find the language line "recommended"
ERROR - 2025-11-26 10:30:47 --> Could not find the language line "recommended"
ERROR - 2025-11-26 11:06:27 --> Could not find the language line "recommended"
ERROR - 2025-11-26 11:36:41 --> Could not find the language line "recommended"
ERROR - 2025-11-26 12:07:39 --> Could not find the language line "recommended"
ERROR - 2025-11-26 12:42:41 --> Could not find the language line "recommended"
ERROR - 2025-11-26 13:21:56 --> Could not find the language line "recommended"
ERROR - 2025-11-26 14:33:06 --> Could not find the language line "recommended"
ERROR - 2025-11-26 15:10:05 --> Could not find the language line "check_availability"
ERROR - 2025-11-26 15:10:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 15:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 15:27:41 --> Could not find the language line "recommended"
ERROR - 2025-11-26 16:19:24 --> Could not find the language line "recommended"
ERROR - 2025-11-26 17:17:50 --> Could not find the language line "recommended"
ERROR - 2025-11-26 18:59:07 --> Could not find the language line "recommended"
ERROR - 2025-11-26 20:02:47 --> Could not find the language line "recommended"
ERROR - 2025-11-26 20:13:21 --> Could not find the language line "recommended"
ERROR - 2025-11-26 20:18:36 --> Could not find the language line "email_us"
ERROR - 2025-11-26 20:28:31 --> Could not find the language line "check_availability"
ERROR - 2025-11-26 20:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 20:28:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 20:32:00 --> Could not find the language line "check_availability"
ERROR - 2025-11-26 20:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 20:32:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 21:03:44 --> Could not find the language line "check_availability"
ERROR - 2025-11-26 21:03:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-11-26 21:03:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
