<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-12 00:20:46 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 00:20:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 00:20:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 02:04:20 --> Could not find the language line "login_heading"
ERROR - 2025-12-12 02:04:20 --> Could not find the language line "login_password_label"
ERROR - 2025-12-12 02:04:21 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `login_attempts` (`ip_address`, `login`, `time`) VALUES ('2401:4900:a075:503f:b5a7:f9d:3afb:c069', '9310703144', 1765485261)
ERROR - 2025-12-12 02:04:56 --> Could not find the language line "login_heading"
ERROR - 2025-12-12 02:04:56 --> Could not find the language line "login_password_label"
ERROR - 2025-12-12 02:04:57 --> Could not find the language line "support_chat"
ERROR - 2025-12-12 02:04:57 --> Could not find the language line "label_close"
ERROR - 2025-12-12 02:04:57 --> Could not find the language line "label_search"
ERROR - 2025-12-12 02:04:57 --> Could not find the language line "label_search_result"
ERROR - 2025-12-12 02:05:03 --> Could not find the language line "promocodes"
ERROR - 2025-12-12 04:19:56 --> Could not find the language line "recommended"
ERROR - 2025-12-12 05:36:18 --> Could not find the language line "recommended"
ERROR - 2025-12-12 06:59:03 --> Could not find the language line "recommended"
ERROR - 2025-12-12 09:08:00 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 09:08:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 09:08:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 09:30:16 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 09:30:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 09:30:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 09:54:29 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 09:54:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 09:54:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 11:54:53 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 11:54:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 11:54:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 12:10:36 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 12:10:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 12:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 17:04:07 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 17:04:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 17:04:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 17:04:13 --> Could not find the language line "recommended"
ERROR - 2025-12-12 17:08:56 --> Could not find the language line "check_availability"
ERROR - 2025-12-12 17:08:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-12 18:40:04 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-12 18:40:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-12 18:40:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-12 18:40:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-12 18:40:06 --> Could not find the language line "recommended"
ERROR - 2025-12-12 21:41:07 --> Could not find the language line "recommended"
ERROR - 2025-12-12 22:17:26 --> Could not find the language line "recommended"
ERROR - 2025-12-12 22:38:56 --> Could not find the language line "login_heading"
ERROR - 2025-12-12 22:38:56 --> Could not find the language line "login_password_label"
ERROR - 2025-12-12 22:38:57 --> Could not find the language line "support_chat"
ERROR - 2025-12-12 22:38:57 --> Could not find the language line "label_close"
ERROR - 2025-12-12 22:38:57 --> Could not find the language line "label_search"
ERROR - 2025-12-12 22:38:57 --> Could not find the language line "label_search_result"
ERROR - 2025-12-12 22:39:04 --> Could not find the language line "promocodes"
ERROR - 2025-12-12 23:37:17 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-12 23:37:17 --> Could not find the language line "shipping_policy"
