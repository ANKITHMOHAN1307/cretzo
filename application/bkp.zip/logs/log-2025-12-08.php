<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-08 00:04:09 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 00:04:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 00:04:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 00:09:39 --> Could not find the language line "recommended"
ERROR - 2025-12-08 00:10:40 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 00:10:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 00:10:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 00:21:17 --> Could not find the language line "recommended"
ERROR - 2025-12-08 00:32:21 --> Could not find the language line "recommended"
ERROR - 2025-12-08 00:44:14 --> Could not find the language line "recommended"
ERROR - 2025-12-08 00:55:39 --> Could not find the language line "recommended"
ERROR - 2025-12-08 01:07:49 --> Could not find the language line "recommended"
ERROR - 2025-12-08 01:30:56 --> Could not find the language line "recommended"
ERROR - 2025-12-08 01:50:27 --> Could not find the language line "recommended"
ERROR - 2025-12-08 02:09:07 --> Could not find the language line "recommended"
ERROR - 2025-12-08 02:43:47 --> Could not find the language line "email_us"
ERROR - 2025-12-08 03:20:41 --> Could not find the language line "recommended"
ERROR - 2025-12-08 04:40:27 --> Could not find the language line "recommended"
ERROR - 2025-12-08 05:05:41 --> Could not find the language line "compare"
ERROR - 2025-12-08 05:15:11 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 05:15:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 05:15:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 06:14:48 --> Could not find the language line "recommended"
ERROR - 2025-12-08 07:30:01 --> Could not find the language line "compare"
ERROR - 2025-12-08 07:35:21 --> Could not find the language line "recommended"
ERROR - 2025-12-08 07:51:21 --> Could not find the language line "recommended"
ERROR - 2025-12-08 08:10:05 --> Could not find the language line "recommended"
ERROR - 2025-12-08 08:27:24 --> Could not find the language line "recommended"
ERROR - 2025-12-08 08:44:25 --> Could not find the language line "recommended"
ERROR - 2025-12-08 09:01:37 --> Could not find the language line "recommended"
ERROR - 2025-12-08 09:22:03 --> Could not find the language line "recommended"
ERROR - 2025-12-08 09:55:36 --> Could not find the language line "recommended"
ERROR - 2025-12-08 09:58:35 --> Could not find the language line "recommended"
ERROR - 2025-12-08 10:11:13 --> Could not find the language line "recommended"
ERROR - 2025-12-08 10:18:59 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 10:18:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 10:18:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 10:26:38 --> Could not find the language line "recommended"
ERROR - 2025-12-08 10:42:11 --> Could not find the language line "recommended"
ERROR - 2025-12-08 10:59:54 --> Could not find the language line "recommended"
ERROR - 2025-12-08 11:04:26 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 11:04:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 11:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 11:24:33 --> Could not find the language line "recommended"
ERROR - 2025-12-08 11:26:20 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 11:26:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 11:26:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 11:46:59 --> Could not find the language line "recommended"
ERROR - 2025-12-08 12:10:56 --> Could not find the language line "recommended"
ERROR - 2025-12-08 12:17:01 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 12:17:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 12:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 12:33:58 --> Could not find the language line "recommended"
ERROR - 2025-12-08 12:56:37 --> Could not find the language line "recommended"
ERROR - 2025-12-08 13:14:36 --> Could not find the language line "recommended"
ERROR - 2025-12-08 13:27:12 --> Could not find the language line "recommended"
ERROR - 2025-12-08 14:03:33 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-08 14:03:33 --> Could not find the language line "shipping_policy"
ERROR - 2025-12-08 14:32:02 --> Could not find the language line "recommended"
ERROR - 2025-12-08 15:21:18 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 15:21:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 15:21:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 15:30:12 --> Could not find the language line "recommended"
ERROR - 2025-12-08 15:38:52 --> Could not find the language line "recommended"
ERROR - 2025-12-08 15:57:58 --> Could not find the language line "email_us"
ERROR - 2025-12-08 17:29:21 --> Could not find the language line "recommended"
ERROR - 2025-12-08 17:38:15 --> Could not find the language line "recommended"
ERROR - 2025-12-08 18:14:27 --> Could not find the language line "recommended"
ERROR - 2025-12-08 18:18:03 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 18:18:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 18:18:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 18:50:46 --> Could not find the language line "recommended"
ERROR - 2025-12-08 19:47:30 --> Could not find the language line "recommended"
ERROR - 2025-12-08 20:01:03 --> Severity: Warning --> Undefined array key 0 /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-08 20:01:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-08 20:01:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-08 20:01:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/controllers/Products.php 487
ERROR - 2025-12-08 20:01:04 --> Could not find the language line "recommended"
ERROR - 2025-12-08 20:52:55 --> Could not find the language line "recommended"
ERROR - 2025-12-08 22:41:07 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 22:41:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 22:41:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 22:49:29 --> Could not find the language line "recommended"
ERROR - 2025-12-08 23:42:02 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 23:42:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 23:42:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 23:46:29 --> Could not find the language line "check_availability"
ERROR - 2025-12-08 23:46:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
ERROR - 2025-12-08 23:46:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/cretzo/pages/product-page.php 1103
