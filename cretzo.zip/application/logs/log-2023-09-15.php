<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-15 11:31:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-09-15 11:36:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-09-15 11:39:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-09-15 11:41:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-09-15 11:51:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-09-15 12:57:01 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-15 12:57:01 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-15 12:58:04 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-15 12:58:04 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-15 12:58:27 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-15 12:58:27 --> Could not find the language line "Text.send_mail"
