<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-01 17:01:57 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-01 17:01:57 --> Could not find the language line "Text.send_mail"
