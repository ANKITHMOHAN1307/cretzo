<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-07 15:27:03 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-07 15:27:03 --> Could not find the language line "Text.send_mail"
