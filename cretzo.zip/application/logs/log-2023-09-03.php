<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-03 11:33:12 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-03 11:33:12 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-03 14:52:54 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-03 14:52:54 --> Could not find the language line "Text.send_mail"
