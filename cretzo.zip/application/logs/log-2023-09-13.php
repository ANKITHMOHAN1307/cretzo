<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-13 12:46:19 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-13 12:46:19 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-13 12:58:35 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:58:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:58:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:58:35 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:58:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:58:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:04 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:04 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:48 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:48 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 12:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:00:02 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:00:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:00:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:00:02 --> Severity: Warning --> Undefined variable $fetched_data /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:00:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:00:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/u554344800/domains/cretzo.com/public_html/application/views/admin/pages/forms/slider.php 63
ERROR - 2023-09-13 13:04:21 --> Severity: error --> Exception: syntax error, unexpected token ";" /home/u554344800/domains/cretzo.com/public_html/application/views/front-end/modern/pages/home.php 17
