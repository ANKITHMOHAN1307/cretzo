<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-04 09:15:40 --> Could not find the language line "Text.send_mail"
ERROR - 2023-09-04 09:15:40 --> Could not find the language line "Text.send_mail"
