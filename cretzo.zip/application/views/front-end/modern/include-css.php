

<!-- Izimodal -->
<!-- <link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/iziModal.min.css' ?>" /> -->
<!-- Favicon -->
<?php

$favicon = get_settings('web_favicon');

$path = ($is_rtl == 1) ? 'rtl/' : "";
?>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.1/font/bootstrap-icons.min.css"  />
    <!-- font -->

    <!-- owl cursor -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <link rel="stylesheet" href="<?= base_url('assets/front_end/cretzo/css/style.css') ?>">

    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<!-- <link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/eshop-bundle.css' ?>" />
<link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/' . $path . 'eshop-bundle-main.css' ?>"> -->

<link rel="icon" href="<?= base_url($favicon) ?>" type="image/gif" sizes="16x16">


<!-- jssocials -->
<!-- <link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/jquery.jssocials-theme-flat.css' ?>">
<link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/jquery.jssocials.css' ?>"> -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- MDB perfect scrollbar -->
<!-- <link href="<?= THEME_ASSETS_URL . 'css/perfect-scrollbar.css' ?>" rel="stylesheet" />

<link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/style.css' ?>">
<link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/custom.css' ?>"> -->


<!-- <?php if (ALLOW_MODIFICATION == 0) { ?>
    <link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/colors/orange.css' ?>" id="color-switcher">
<?php } else { ?>
    <?php
    $settings = get_settings('web_settings', true);
    $modern_theme_color = (isset($settings['modern_theme_color']) && !empty($settings['modern_theme_color'])) ? $settings['modern_theme_color'] : 'orange'; ?>
    <link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/colors/' . $modern_theme_color . '.css' ?>">

<?php } ?> -->

<!--
<link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/plugins.css' ?>">
<link rel="stylesheet" href="<?= THEME_ASSETS_URL . 'css/theme.min.css' ?>"> -->






<!-- Jquery -->
<!-- <script src="<?= THEME_ASSETS_URL . 'js/jquery.min.js' ?>"></script> -->
<!-- Date Range Picker -->
<!-- <script src="<?= THEME_ASSETS_URL . 'js/moment.min.js' ?>"></script>
<script src="<?= THEME_ASSETS_URL . 'js/daterangepicker.js' ?>"></script> -->
<script type="text/javascript">
    base_url = "<?= base_url() ?>";
    currency = "<?= isset($settings['currency'])? $settings['currency'] : '₹' ?>";
    csrfName = "<?= $this->security->get_csrf_token_name() ?>";
    csrfHash = "<?= $this->security->get_csrf_hash() ?>";
</script>