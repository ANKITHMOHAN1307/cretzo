<?php

$chinkariData = array();
$trandingData = array();
$newlyAddedData = array();
$featuredData = array();

foreach ($sections as $section) {

    if ($section['product_type'] == 'custom_products') {
        $chinkariData =  $section['product_details'];
        $ctitle = $section['title'];
        $cshortDescription = $section['short_description'];
    }

    if ($section['product_type'] == 'new_added_products') {
        $newlyAddedData =  $section['product_details'];
        $ntitle = $section['title'];
        $nshortDescription = $section['short_description'];
    }

    if ($section['product_type'] == 'most_selling_products') {
        $trandingData = $section['product_details'];
        $ttitle = $section['title'];
        $tshortDescription = $section['short_description'];
    }

    if ($section['product_type'] == 'top_rated_products') {
        $featuredData = $section['product_details'];
        $ftitle = $section['title'];
        $fshortDescription = $section['short_description'];
    }
}


?>

<?php if (isset($sliders) && !empty($sliders)) {
?>
    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php foreach ($sliders as $key => $row) {
            ?>
                <div class="carousel-item <?php if ($key == 0) echo "active";
                                            else echo ""; ?> ">
                    <a href="<?= $row['link'] ?>">
                        <img src="<?= base_url($row['image']) ?>" class="d-block w-100" alt="...">
                    </a>
                </div>
            <?php } ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
<?php } ?>
<!-- banner end -->

<!-- trending deals -->
<!-- ========================[Tranding Section]============================ -->
<?php if(!empty($trandingData) && is_array($trandingData)) :  ?>
<div class="container-fluid my-3">
    <div class="row">
        <div class="text-center my-2">
            <h3 class="fw-bold"> <?= $ttitle ?> </h3>
            <span style="font-size:small;"> <?= $tshortDescription ?> </span>
            <div class="text-center">
                <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png') ?>" class="img-fluid" alt="">
            </div>
        </div>

        <div id="banner" class="owl-carousel owl-theme my-2">
            <?php foreach($trandingData as $tdata) :   ?>

            <div class="item">
                <div class="rounded-4 border position-relative">
                 <a href="<?= base_url('products/details/' . $product_row['slug']) ?>">   <img src="<?= $tdata['image'] ?>" class="img-fluid rounded-top-4" alt="" style="height: 100px !important;"> </a>
                    <!-- <div class="position-absolute bottom-40 start-0 mx-2">
                        <a href="#"><i class="bi bi-heart-fill"></i></a>
                    </div>
                    <div class="position-absolute bottom-40 end-0 mx-2">
                        <a href="#"><i class="bi bi-handbag-fill"></i></a>
                    </div> -->
                    <div class="p-2 text-center">
                        <div class="text-secondary"><?= $tdata['name'] ?></div>
                        <span> Spl. price : ₹ <?= $tdata['min_max_price']['special_price'] ?> /- &nbsp;  <del class="text-secondary">₹ <?= $tdata['min_max_price']['max_price'] ?></del></span>
                    </div>
                    <div class="position-absolute top-0 start-0 mx-2">

                        <div class="new"><i class="bi bi-star-fill"></i> <?= $tdata['rating'] ?></div>
                    </div>
                </div>
            </div>

        <?php endforeach; ?>
        </div>
    </div>
</div>

<?php endif;  ?>
<!-- ========================[Tranding Section]============================ -->
<!-- category -->
<?php
if (!empty($categories) && is_array($categories)) :
?>
    <div class="container-fluid  rounded-3 border" style="background-color: rgba(250, 244, 183, 0.3);">
        <div class="row justify-content-center">
            <div class="text-center my-2">
                <h3 class="fw-bold">Categories</h3>
                <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png'); ?>" class="img-fluid" alt="">
            </div>
            <?php
            $count = count($categories);
            if ($count == 1) {
                $divCol = "col-lg-12 col-md-12  col-sm-12 col-12";
            }
            if ($count == 2) {
                $divCol = "col-lg-6  col-md-6  col-sm-6 col-6";
            }
            if ($count == 3) {
                $divCol = " col-sm-6 col-6 col-lg-4 col-md-4";
            }
            if ($count >= 4) {
                $divCol = "col-6 col-sm-6 col-md-3 col-lg-3";
            }
            foreach ($categories as $cats) :
            ?>
                <div class="<?= $divCol ?> px-1">
                    <a href="<?= base_url($cats['slug']) ?>">
                        <div class="rounded-3 border my-1" style="position: relative; height: 220px; overflow: hidden;">
                            <div style="background-image: url('<?= $cats['image'] ?>'); background-size: cover; background-position: center; height: 100%;"></div>
                            <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; background-color: rgba(0, 0, 0, 0.5);">
                                <h5 style="color: white; padding: 10px;"><?= $cats['name']; ?></h5>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
<!-- Best Seller -->

<?php if (!empty($sellers) && is_array($sellers)) : ?>
    <div class="container-fluid my-5">
        <div class="row justify-content-around">
            <div class="text-center my-2">
                <h3 class="fw-bold">Best Seller</h3>
                <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png') ?>" class="img-fluid" alt="">
            </div>
            <div id="bestSeller" class="owl-carousel owl-theme my-2">
                <?php foreach ($sellers as $seller) :

                ?>
                    <div class="item my-2">
                        <div class="rounded-3 border">
                            <div class="row">
                                <div class="col-lg-7 col-md-7 col-sm-12  ">
                                    <div class="p-2">
                                        <img src="<?= base_url($seller['logo']) ?>" class="img-fluid rounded-3" style="height: 200px; width: 100%; object-fit: cover; object-position: center;">
                                    </div>
                                </div>

                                <div class="col-lg-5 col-md-5 col-sm-12 d-flex flex-column mt-2">
                                    <div class="p-2  text-center">
                                        <h4 class="fw-bold"><?= strtoupper($seller['store_name']) ?></h4>
                                        <p><?= $seller['store_description'] ?></p>
                                    </div>
                                    <a href="<?= $seller['store_url'] ?>" target="_blank" class="btn btn-warning mt-auto">Shop Now</a>
                                </div>

                            </div>
                        </div>
                    </div>

                <?php endforeach; ?>
            </div>
        </div>
    </div>

<?php endif; ?>
<!-- ======================[Start Second Sliders]=================================== -->
<?php if (isset($centerSlider) && !empty($centerSlider)) {
?>
    <div id="carouselExampleFadeCenter" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php foreach ($centerSlider as $key => $row) {
            ?>
                <div class="carousel-item <?php if ($key == 0) echo "active";
                                            else echo ""; ?> ">
                    <a href="<?= $row['link'] ?>">
                        <img src="<?= base_url($row['image']) ?>" class="d-block w-100" alt="...">
                    </a>
                </div>
            <?php } ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFadeCenter" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFadeCenter" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- banner end -->
<?php } ?>
<!-- ======================[End Second Sliders]===================================== -->
<!-- feature product -->

<!-- ==========================[Featured Section ]=================================== -->
<?php
if (!empty($featuredData) && is_array($featuredData)) :

?>

    <div class="container-fluid my-5">
        <div class="row justify-content-center">
            <div class="text-center my-2">
                <h3 class="fw-bold"> <?= $ftitle ?></h3>
                <span style="font-size:small;"><?= $fshortDescription ?></span>
                <div class="text-center">
                    <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png') ?>" class="img-fluid" alt="">
                </div>
            </div>

            <?php foreach($featuredData as $fdata) : ?>

            <div class="col-lg-2 col-6  my-2">
                <div>
                    <img src="<?= base_url('assets/front_end/cretzo/img/il_300x300.4245808662_a3x4.jpg.png') ?>" class="img-fluid rounded-3" alt="">
                </div>
                <div class="text-center p-3">
                    <span>Mony</span>
                    <h6>Product Name</h6>
                    <span class="active">Rs. 2500 <del class="text-secondary">Rs. 2500</del></span>
                </div>
             </div>

            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
<!-- ==========================[Featured Section ]=================================== -->

<!-- ======================[New Arrival Sections]======================== -->

<?php if(!empty($newlyAddedData) && is_array($newlyAddedData)) :  ?>

<div class="container-fluid my-3 rounded-3 border " style="background-color: rgba(250, 244, 183, 0.3);">
    <div class="row justify-content-center">
    <div class="text-center my-2">
            <h3 class="fw-bold"> <?= $ntitle ?> </h3>
            <span style="font-size:small;"> <?= $nshortDescription ?> </span>
            <div class="text-center">
                <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png') ?>" class="img-fluid" alt="">
            </div>
        </div>

<?php foreach($newlyAddedData as $ndata) : ?>
        <div class="col-lg-4 my-3 col-6 d-flex content-center">
            <div class="row">
                <div class="col-lg-5 col-12 content-center">
                    <img src="<?= $ndata['image'] ?>" class="rounded img-fluid" alt="">
                </div>
                <div class="col-lg-7 col-12">

                    <span class="">
                        <div><?= $ndata['name'] ?></div>
                        <div> <span class="active"> Spl. price : ₹ <?= $ndata['min_max_price']['special_price'] ?> /- &nbsp; <del class="text-secondary">₹ <?= $ndata['min_max_price']['max_price'] ?></del></span>
                        </div>
                    </span>
                </div>
            </div>
        </div>

<?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
<!-- ======================[]======================== -->
<!-- ======================[Start Bottom Sliders]=================================== -->
<?php if (isset($bottomSlider) && !empty($bottomSlider)) {
?>
    <div id="carouselExampleFadeBottom" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php foreach ($bottomSlider as $key => $row) {
            ?>
                <div class="carousel-item <?php if ($key == 0) echo "active";
                                            else echo ""; ?> ">
                    <a href="<?= $row['link'] ?>">
                        <img src="<?= base_url($row['image']) ?>" class="d-block w-100" alt="...">
                    </a>
                </div>
            <?php } ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFadeBottom" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFadeBottom" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- banner end -->
<?php } ?>
<!-- ======================[End Bottom Sliders]===================================== -->
<!-- src collection -->

<?php

if (!empty($chinkariData) && is_array($chinkariData)) : ?>
    <div class="container-fluid my-5">
        <div class="row justify-content-center">
        <div class="text-center my-2">
            <h3 class="fw-bold"> <?= $ctitle ?> </h3>
            <span style="font-size:small;"> <?= $cshortDescription ?> </span>
            <div class="text-center">
                <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png') ?>" class="img-fluid" alt="">
            </div>
        </div>
            <?php //foreach() :
            ?>

            <div class="col-lg-4 my-3 col-6 d-flex content-center">
                <div class="row">
                    <div class="col-lg-5 col-12 content-center">
                        <img src="<?= base_url('assets/front_end/cretzo/img/ring.jpg') ?>" class="rounded img-fluid" alt="">
                    </div>
                    <div class="col-lg-7 col-12">
                        <span class="">
                            <div>Handmade Golden ring</div>
                            <div> <span class="active">Rs. 2500 <del class="text-secondary">Rs. 2500</del></span>
                            </div>
                        </span>
                    </div>
                </div>
            </div>

            <?php //endforeach;
            ?>

        </div>
    </div>
<?php endif; ?>

<!-- instagram -->
<div class="container-fluid my-3" style="background-color: rgba(250, 244, 183, 0.3);">
    <div class="row justify-content-center newRow">
        <div class="text-center py-3">
            <h3>Instagram</h3>
            <div> Get in Touch</div>
            <img src="<?= base_url('assets/front_end/cretzo/img/arrow.png') ?>" class="img-fluid" alt="">
        </div>
        <div loading="lazy" data-mc-src="ae58b567-e45f-45db-95cb-01da2f733b7a#instagram"></div>

        <script src="https://cdn2.woxo.tech/a.js#651a74a979b4b76c4df4765d" async data-usrc>
        </script>
    </div>
</div>