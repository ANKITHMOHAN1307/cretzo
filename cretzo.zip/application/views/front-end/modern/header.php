<?php
$this->load->model('category_model');
$categories = $this->category_model->get_categories(null, 20);
$language = get_languages();
$cookie_lang = $this->input->cookie('language', TRUE);
$language_index = 0;
if (!empty($cookie_lang)) {
    $language_index = array_search($cookie_lang, array_column($language, "language"));
}
?>
<header>
    <div class="container-fluid D-none">
        <div class="row justify-content-center py-1">
            <div class="col-lg-2 col-12 text-center">
                <?php if (ALLOW_MODIFICATION == 0) { ?>
                    <a href="<?= base_url(); ?>"><img src="<?= base_url('assets/front_end/cretzo/img/logo.png') ?>" class="img-fluid" alt=""></a>
                <?php } else { ?>
                    <?php $logo = get_settings('web_logo'); ?>
                    <a href="<?= base_url(); ?>"><img src="<?= base_url($logo) ?>" class="img-fluid" alt=""></a>
                <?php } ?>
            </div>
            <div class="col-lg-8 col-12 text-end">
                <div class="input-group mt-3">
                    <input type="text" class="form-control btn-circle py-2" placeholder="Search" aria-describedby="basic-addon2">
                    <span class="input-group-text search-button" id="basic-addon2"><i class="bi bi-search"></i></span>
                </div>
            </div>
            <div class="col-lg-2 mt-3 fs-4 text-end">
                <span class="">
                    <span class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <a href="dashboard.php" class="mx-2"><i class="bi bi-person-circle fs-3"></i></a>
                    </span>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="dashboard.php">Profile</a></li>
                        <li><a class="dropdown-item" href="order.php">Order</a></li>
                        <li><a class="dropdown-item" href="#">My Booking</a></li>
                        <li><a class="dropdown-item" href="#">Logout</a></li>
                    </ul>
                </span>
                <span class="position-relative mx-2">
                    <a href="wishlist.php" title="wishlist"><i class="bi bi-heart"></i></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle theme-b-color" style="font-size:12px;">9</span>
                </span>
                <span class="position-relative mx-2">
                    <a href="addToCart.php" title="add to cart"><i class="bi bi-handbag"></i></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle theme-b-color" style="font-size:12px;">9</span>
                </span>
                <span class="position-relative mx-2">
                    <a href="addToCart.php" title="Notification"> <i class="bi bi-bell"></i></a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle theme-b-color" style="font-size:12px;">9</span>
                </span>
            </div>
        </div>
    </div>
</header>
<!-- navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <div class="content-center">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <span class=""><a href="<?= base_url(); ?>"><img src="<?= base_url($logo) ?>" class="d-lg-none" width="100" height="auto" style="margin-bottom:8px;" alt=""></a></span>
        </div>
        <span class="navbar-brand d-lg-none">
            <span class="position-relative mx-2 bg-none">
                <i class="bi bi-heart"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle theme-b-color" style="font-size:12px;">9<span class="visually-hidden">unread messages</span></span>
            </span>
            <span class="position-relative mx-2">
                <i class="bi bi-handbag"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle theme-b-color" style="font-size:12px;">9<span class="visually-hidden">unread messages</span></span>
            </span>
            <span class="position-relative mx-2">
                <i class="bi bi-bell"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle theme-b-color" style="font-size:12px;">9<span class="visually-hidden">unread messages</span></span>
            </span>
        </span>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php foreach ($categories as $key => $row) {
                    $subCategory = $row['children'];
                ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="<?= base_url($row['slug']) ?>" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                            <?= $row['name'] ?>
                        </a>
                        <?php if (isset($subCategory) && !empty($subCategory)) : ?>
                            <ul class="dropdown-menu shadow-sm">
                                <?php foreach ($subCategory as $sub) : ?>
                                    <li><a class="dropdown-item" href="<?= base_url($sub['slug']) ?>"><?= $sub['name'] ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php } ?>
            </ul>
        </div>
        <div class="input-group d-lg-none my-1">
            <input type="text" class="form-control btn-circle bg-white" placeholder="Search" aria-describedby="basic-addon2">
            <span class="input-group-text search-button bg-white" id="basic-addon2"><i class="bi bi-search"></i></span>
        </div>
    </div>
</nav>
