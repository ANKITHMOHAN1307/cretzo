<?php $web_settings = get_settings('web_settings', true);
$system_settings = get_settings('system_settings', true); ?>
<div class="container-fluid py-3 footer-bg rounded-3 border text-center">
    <div class="row d-flex justify-content-around">
        <div class="col-lg-4 col-md-4 py-2">
            <?php $logo = get_settings('web_logo'); ?>
            <img src="<?= base_url($logo) ?>" width="200px" height="auto" alt="">
            <p class="my-3" style="text-align: justify;"><?= $web_settings['app_short_description'] ?></p>
            <div>

                <?php if (isset($web_settings['twitter_link']) && !empty($web_settings['twitter_link'])) { ?>
                    <a href="<?= $web_settings['twitter_link'] ?>" target="_blank" aria-label="twitter-link" class="rounded-circle mx-1"><i class="bi bi-twitter h2" style="color:rgb(29, 155, 240);font-size:xx-large !important;"></i></a>
                <?php } ?>
                <?php if (isset($web_settings['facebook_link']) &&  !empty($web_settings['facebook_link'])) { ?>
                    <a href="<?= $web_settings['facebook_link'] ?>" target="_blank" aria-label="facebook link" class="rounded-circle mx-1"><i class="bi bi-facebook h2" style="color:rgb(66 103 178);font-size:xx-large !important;"></i></a>
                <?php } ?>
                <?php if (isset($web_settings['instagram_link']) &&  !empty($web_settings['instagram_link'])) { ?>
                    <a href="<?= $web_settings['instagram_link'] ?>" target="_blank" aria-label="instragram link" class="rounded-circle mx-1"><i class="bi bi-instagram h2" style="color:rgb(64, 93, 230); font-size:xx-large !important"></i></a>
                <?php } ?>
                <?php if (isset($web_settings['youtube_link']) &&  !empty($web_settings['youtube_link'])) { ?>
                    <a href="<?= $web_settings['youtube_link'] ?>" target="_blank" aria-label="youtube-link" class="rounded-circle mx-1"><i class="bi bi-youtube h1" style="color:red;font-size:xx-large !important;"></i></a>
                <?php } ?>
            </div>
        </div>
        <div class="col-lg-2 col-md-2 py-2">
            <h5 class="fw-bold">Information</h5>
            <div><a href="<?= base_url('seller/auth/sign_up') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('become_a_seller')) ? $this->lang->line('become_a_seller') : 'Become a Seller' ?></a></div>
            <div><a href="<?= base_url('home/return-policy') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('return_policy')) ? $this->lang->line('return_policy') : 'Return Policy' ?></a></div>
            <div><a href="<?= base_url('home/contact-us') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('contact_us')) ? $this->lang->line('contact_us') : 'Contact Us' ?></a></div>
            <div><a href="<?= base_url('home/about-us') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('about_us')) ? $this->lang->line('about_us') : 'About Us' ?></a></div>
            <div><a href="<?= base_url('blogs/') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('blogs')) ? $this->lang->line('blogs') : 'Blogs' ?></a></div>

            <div><a href="<?= base_url('home/faq') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('faq')) ? $this->lang->line('faq') : 'FAQs' ?></a></div>
        </div>
        <div class="col-lg-2 col-md-2 py-2">
            <h5 class="fw-bold">Quick links</h5>
            <div><a href="<?= base_url('home/privacy-policy') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('privacy_policy')) ? $this->lang->line('privacy_policy') : 'Privacy Policy' ?></a></div>
            <div><a href="<?= base_url('home/terms-and-conditions') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('terms_and_condition')) ? $this->lang->line('terms_and_condition') : 'Terms & Conditions' ?></a></div>
            <div><a href="<?= base_url('products') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('products')) ? $this->lang->line('products') : 'Products' ?></div>
            <div><a href="<?= base_url('home/return-policy') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('return_policy')) ? $this->lang->line('return_policy') : 'Return Policy' ?></a></div>
            <div><a href="<?= base_url('home/shipping-policy') ?>" class="text-decoration-none hover"><?= !empty($this->lang->line('shipping_policy')) ? $this->lang->line('shipping_policy') : 'Shipping Policy' ?></a></div>
        </div>
        <div class="col-lg-3 col-md-3 py-2">
            <h5 class="fw-bold">Contact Us</h5>
            <?php if (isset($web_settings['address']) && !empty($web_settings['address'])) { ?>
                <div class=""><i class="bi bi-geo-alt"></i> <a href="" class="aTag"><?= output_escaping(str_replace('\r\n', '</br>', $web_settings['address'])) ?></a></d>
                    <div class=""><i class="bi bi-telephone"></i> <a href="tel:<?= $web_settings['support_number'] ?>" class="aTag"><?= $web_settings['support_number'] ?></a></div>
                    <div class=""><i class="bi bi-envelope"></i> <a href="mailto:<?= $web_settings['support_email'] ?>" class="aTag"><?= $web_settings['support_email'] ?></a></div>
                    <div>
                        <img src="<?= base_url('assets/front_end/cretzo/img/icons/pay.png') ?>" class="img-fluid" alt="">
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<div class="col-md-12 text-center">
    <?php $company_name = get_settings('web_settings', true);
    if (isset($company_name['copyright_details']) && !empty($company_name['copyright_details'])) {
    ?>
        <span> <?= (isset($company_name['copyright_details']) && !empty($company_name['copyright_details'])) ? output_escaping(str_replace('\r\n', '&#13;&#10;', $company_name['copyright_details'])) : " " ?> </span>
    <?php } else { ?>
        <p>Copyright &copy; <?= date('Y') ?>, All Right Reserved <a target="_blank" href="https://www.rukesh.net/">rukesh.net</a></p>
    <?php } ?>
</div>